package swarm.random;

/**
 * <strong> Prime Modulus Multiplicative Linear Congruential Generator 1</strong>.

 With parameters a = 16,807 and m = 2,147,483,647, this generator has a single full cycle of length (m-1).
 */
public interface PMMLCG1genS extends PMMLCGgenS {
}
