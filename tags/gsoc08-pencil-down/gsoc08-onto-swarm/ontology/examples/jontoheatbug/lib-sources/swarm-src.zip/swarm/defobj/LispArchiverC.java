package swarm.defobj;

/**
 * <strong> Protocol for creating Lisp instances of the Archiver</strong>.

 Protocol for creating Lisp instances of the Archiver Default system path is ~/.swarmArchiver.scm. Default application path is <swarmdatadir>/<appname>/<appname>.scm or the current directory.
 */
public interface LispArchiverC extends ArchiverC, ArchiverS {

/**
 *  Convenience method to create LispArchiver from a specified path
 */
Object create$setPath (Zone aZone, java.lang.String path);
}
