package swarm.activity;

/**
 * <strong> Time-based map usable for concurrent group.</strong>.

 Time-based map usable for concurrent group.
 */
public interface ConcurrentScheduleC extends ConcurrentGroupC, ConcurrentGroupS, ScheduleC, ScheduleS {
}
