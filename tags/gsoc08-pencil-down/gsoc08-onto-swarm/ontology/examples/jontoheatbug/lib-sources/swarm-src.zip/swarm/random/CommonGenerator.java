package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface CommonGenerator  {

/**
 *  The getAntithetic method returns the current values of the parameter.
 */
boolean getAntithetic ();

/**
 *  The getMaxSeedValue method returns the upper limit on the seed value that can be supplied.
 */
int getMaxSeedValue ();

/**
 *  The getInitialSeed method returns the value of the generator's  starting seed.
 */
int getInitialSeed ();

/**
 *  The lengthOfSeedVector method returns the number of seeds required if you wish to set the state directly.
 */
int lengthOfSeedVector ();

/**
 *  The -reset method sets the generator back to the state it had at start or at the last use of -setStateFromSeed(s). CurrentCount is zeroed.
 */
Object reset ();

/**
 *  The getUnsignedMax method returns the highest value that will ever  be returned by -getUnsignedSample (the lowest is 0).
 */
int getUnsignedMax ();
}
