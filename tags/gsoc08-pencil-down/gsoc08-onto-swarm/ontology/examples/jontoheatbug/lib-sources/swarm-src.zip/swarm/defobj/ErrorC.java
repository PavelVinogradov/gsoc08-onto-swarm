package swarm.defobj;

/**
 * <strong> A condition which prevents further execution.</strong>.

 A condition which prevents further execution.
 */
public interface ErrorC extends WarningC, WarningS {
}
