package swarm.activity;

/**
 * <strong> Like ActionForEach, except that the collection must be homogeneous.</strong>.

 Like ActionForEach, except that the collection must be homogeneous.
 */
public interface ActionForEachHomogeneousC extends ActionC, ActionS, ActionTargetC, ActionTargetS, ActionSelectorC, ActionSelectorS, DefaultOrderC, DefaultOrderS {
}
