package swarm.objectbase;

/**
 * <strong> A class that allows the user to call a given message on any candidate that is an instance of, or inherits from, a given class.</strong>.

 This is a specialized subclass of the abstract class Probe. It completes the specification of a probe that refers to a message element of an object. 
 */
public interface MessageProbeC extends ProbeC, ProbeS {

/**
 *  The setProbedSelector: method sets the message to be probed given the selector. 
 */
Object setProbedSelector (swarm.Selector aSel);

/**
 *  The setProbedMessage: method sets the message to be probed given the message name.  In dynamically-typed languages like JavaScript selectors don't make sense, since method argument types aren't fixed.
 */
Object setProbedMethodName (java.lang.String methodName);

/**
 *  Convenience factory method for common case.
 */
Object create$setProbedSelector (swarm.defobj.Zone aZone, swarm.Selector aSel);
}
