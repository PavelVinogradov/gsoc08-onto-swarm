package swarm.random;

/**
 * <strong> Exponential distribuiton </strong>.

 A well-known continuous probability distribution returning doubles.
 */
public interface ExponentialDistS extends DoubleDistributionS {

/**
 *  The setMean: method sets the mean of the distribution.
 */
Object setMean (double mean);
}
