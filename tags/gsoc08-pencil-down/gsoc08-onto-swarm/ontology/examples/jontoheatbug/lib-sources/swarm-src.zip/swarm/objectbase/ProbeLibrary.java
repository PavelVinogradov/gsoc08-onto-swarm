package swarm.objectbase;

/**
 * <strong> A (singleton) Class, whose instance is used as a container for a global mapping between classnames and their 'default' ProbeMaps. These defaults can be changed by the user, thus allowing him/her to customize the default contents of the ProbeDisplays generated when probing objects.</strong>.

 The normal Swarm simulation will probably only ever contain one instance  of this class, namely the probeLibrary object. This object is used for Library Generation of Probes and ProbeMaps: its role is to cache one  unique "official" ProbeMap for every Class ever probed during a run of Swarm. These ProbeMaps are generated as they are requested. 
 */
public interface ProbeLibrary extends swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.Drop, swarm.defobj.DropS, ProbeConfig, ProbeConfigS {

/**
 *  The setDisplayPrecision: method sets the number of significant digits for  floating point and double floating point numbers displayed on GUI widgets. This method is currently only implemented for VarProbes. It has not been  implemented for MessageProbes yet.  The setDisplayPrecision method allows all probes checked out from the  global ProbeLibrary instance to access this displayed precision. However,  individual probes can vary from this global default, by using the  setFloatFormat method on a exisiting probe. 
 */
Object setDisplayPrecision (int nSigDisplay);

/**
 *  The getDisplayPrecision method gets the current display precision set in  the ProbeLibrary instance.
 */
int getDisplayPrecision ();

/**
 *  The setSavedPrecision: method sets the number of significant digits saved  for floating-point and double floating-point numbers through ObjectSaver.  This function sets the global default precision for all floating point  numbers, including double floating point numbers. This floating point  precision affects all numbers saved via the ObjectSaver class. There is  currently no way to override this global default for an individual probe. 
 */
Object setSavedPrecision (int nSigSaved);

/**
 *  The getSavedPrecision method gets the current saved precision set in the  ProbeLibrary instance.
 */
int getSavedPrecision ();

/**
 *  The isProbeMapDefinedFor: method returns True if there is a non-nil value  in the ProbeLibrary for that class and False otherwise.
 */
boolean isProbeMapDefinedFor (Class aClass);

/**
 * 
 */
boolean isProbeMapDefinedForObject (Object anObject);

/**
 *  The getProbeMapFor: method returns a ProbeMap for the aClass class. If a  specific ProbeMap has been designed and installed in the ProbeLibrary for  that class, then that specific ProbeMap is returned. If a custom ProbeMap  was not designed and installed, then a CompleteProbeMap is created and  returned.
 */
ProbeMap getProbeMapFor (Class aClass);

/**
 * 
 */
ProbeMap getProbeMapForObject (Object anObject);

/**
 *  The getCompleteProbeMapFor: method returns a ProbeMap containing Probes  for all the instance variables and messages of the given Class (including  inherited variables and messages). The current implementation of  ProbeLibrary does not cache CompleteProbeMaps. 
 */
ProbeMap getCompleteProbeMapFor (Class aClass);

/**
 * 
 */
ProbeMap getCompleteProbeMapForObject (Object anObject);

/**
 *  The getCompleteVarMapFor: method returns a ProbeMap containing Probes for  all the instance variables of the given Class (including inherited  variables) but does not include any MessageProbes. 
 */
ProbeMap getCompleteVarMapFor (Class aClass);

/**
 * 
 */
ProbeMap getCompleteVarMapForObject (Object anObject);

/**
 *  The getProbeForVariable:inClass: method returns a probe that has been  "checked out" from the appropriate Probes in the probe library.  Note: The returned probe will be cached so to avoid affecting the results        of future requests for the same probes, clone the probe prior to        making modifications to the probe.
 */
VarProbe getProbeForVariable$inClass (java.lang.String aVar, Class aClass);

/**
 * 
 */
VarProbe getProbeForVariable$inObject (java.lang.String aVar, Object anObject);

/**
 *  The getProbeForMessage:inClass: method returns a probe that has been  "checked out" from the appropriate Probes in the probe library.  Note: The returned probe will be cached so to avoid affecting the results        of future requests for the same probes, clone the probe prior to        making modifications to the probe.
 */
MessageProbe getProbeForMessage$inClass (java.lang.String aMessage, Class aClass);

/**
 * 
 */
MessageProbe getProbeForMessage$inObject (java.lang.String aMessage, Object anObject);

/**
 *  The setProbeMap:For: method sets the standard probe map as the probe map. The returned Probe will be cached as though it was produced by the library itself.
 */
Object setProbeMap$For (ProbeMap aMap, Class aClass);

/**
 * 
 */
Object setProbeMap$ForObject (ProbeMap aMap, Object anObject);
}
