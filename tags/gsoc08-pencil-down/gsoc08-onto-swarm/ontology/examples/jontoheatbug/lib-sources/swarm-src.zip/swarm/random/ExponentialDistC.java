package swarm.random;

/**
 * <strong> Exponential distribuiton </strong>.

 A well-known continuous probability distribution returning doubles.
 */
public interface ExponentialDistC extends DoubleDistributionC, DoubleDistributionS {

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
Object create$setGenerator$setMean (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double mean);

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
Object create$setGenerator$setVirtualGenerator$setMean (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double mean);
}
