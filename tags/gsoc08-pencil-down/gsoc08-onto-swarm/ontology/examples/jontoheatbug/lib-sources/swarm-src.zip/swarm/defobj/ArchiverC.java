package swarm.defobj;

/**
 * <strong> High level abstract serialization interface.</strong>.

 High level abstract serialization interface.
 */
public interface ArchiverC extends CreateC, CreateS, DropC, DropS {

/**
 *  Make the Archiver ignore any file found in the specified path
 */
Object setInhibitLoadFlag (boolean inhibitLoadFlag);

/**
 *  Set the physical path for the Archiver to read/write
 */
Object setPath (java.lang.String path);

/**
 *  Make the Archiver expect application metadata, such as `mode' information 
 */
Object setSystemArchiverFlag (boolean systemArchiverFlag);

/**
 *  Specify that the Archiver instance use the default system path
 */
Object setDefaultPath ();

/**
 *  Specify that the Archiver to use the default application path
 */
Object setDefaultAppPath ();
}
