package swarm.objectbase;

/**
 * <strong> An abstract superclass of both VarProbe and MessageProbe.</strong>.

 A Probe is simply an object that contains pointers to an element  (instance variable or message description) of another object. The Probe contains instance variables that describe the referent's class and type.  It's actually an abstract class that is further subdivided into VarProbe and MessageProbe, which represent the two basic types of  elements of any object. The Probes are collected into a ProbeMap and subsequently installed in the ProbeLibrary. 
 */
public interface Probe extends SwarmObject, SwarmObjectS, ProbeConfig, ProbeConfigS {

/**
 *  The clone: method returns a clone of the probe.  If the initial probe was created by Library Generation or by the default version of Object generation, the probe should be cloned prior to making changes to it to avoid having the changes affect the other potential users of the probe.
 */
Object clone (swarm.defobj.Zone aZone);

/**
 *  The getProbedClass method returns the class of the object the probe points at as a Class pointer.
 */
Class getProbedClass ();

/**
 *  The getProbedType method returns the typing of the probed variable or message. The typing is represented using the string-format provided by the Objective-C runtime system.
 */
java.lang.String getProbedType ();
}
