package swarm.activity;

/**
 * <strong> Protocol shared by ActionGroup and Schedule.</strong>.

 ActionCreating defines the createAction messages for ActionGroup just so that this protocol may be shared with Schedule, where they provide a convenience interface for the creation of actions in the schedule at time zero.  The createAction messages declare all arguments of the message to be of object id type, but you are free to cast other pointers and values up to the limits defined by the global portability assumptions.  These is not portable across all machine architectures, but is expected to be portable across the 32-bit and 64-bit architectures on which Swarm will be supported.  The message you send must still be declared to receive the type of argument you actually pass, before you cast it to the id type. (.. Alternative approaches to argument typing are currently in development, but these will supplement rather than replace the current forms of createAction messages.) Each of the createAction messages returns the action object which it creates.  Each different kind of createAction message returns a different type of Action object with a matching name.  These Action objects provide access to all the information with which the Action was initialized.  The complete set of Action object types is defined below together with the messages that may be used to access their contents.  (.. The implementation of the Action objects is currently undergoing change as the responsibility for parameter and return value typing gets taken over by ActionType in defobj.)
 */
public interface ActionCreatingS extends FActionCreatingS, ActionCreatingCallS, ActionCreatingToS, ActionCreatingForEachS, FActionCreatingForEachHeterogeneousS, FActionCreatingForEachHomogeneousS {
}
