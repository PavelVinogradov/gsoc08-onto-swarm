package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A collection of actions under total or partial order constraints.</strong>.

 An action group is an action plan whose basic representation is a sequence of actions that have been created within it.  An action group inherits its underlying representation from the OrderedSet type of the collections library.  All the members of the ordered set must consist only of actions that are created by one of the createAction messages defined on ActionGroup itself.  Once the actions are created, they may be accessed or traversed using standard messages of the OrderedSet type.  The action objects are an integral, controlled component of the action plan in which they are created.  If they are removed from the action plan collection using a remove message, the only collection in which they may be reinserted is the same collection from which they came. It is permissible, however, to modify the base representation sequence by removing from one position and reinserting at another.
 */
public class ActionGroupImpl extends swarm.BaseImpl implements CompoundAction, CompoundActionS, ActionCreating, ActionCreatingS, DefaultOrder, DefaultOrderS, ActionGroupS, ActionGroup {


/**
 *  The createAction: message specifies that processing of another action type is to be performed by the action.  The referenced action type is performed in its entirety, from start to finish, as the effect of the single created action.
 */
public native Object createAction (Object anActionType);

/**
 * 
 */
public native FActionForEachHomogeneous createFActionForEachHomogeneous$call (Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native FActionForEachHeterogeneous createFActionForEachHeterogeneous$call (Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native ActionForEachHomogeneous createActionForEachHomogeneous$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native FAction createFAction (swarm.defobj.FCall call);

/**
 * 
 */
public native swarm.defobj.Symbol getDefaultOrder ();

/**
 * 
 */
public native boolean getAutoDrop ();

/**
 * 
 */
public native swarm.collections.PermutedIndex beginPermuted (swarm.defobj.Zone aZone);

/**
 *  The begin: message is the standard method for creating a new index for traversing the elements of a collection.  All further information about indexes is documented under the Index type.
 */
public native swarm.collections.Index begin (swarm.defobj.Zone aZone);

/**
 *  Returns YES if all members are of the same class.
 */
public native boolean allSameClass ();

/**
 *  Like removeAll:, but drops the member(s) as well.
 */
public native void deleteAll ();

/**
 *  The removeAll message removes all existing members of a collection and sets its member count to zero.  The collection then remains valid for further members to be added.  This message has no effect on the objects which might be referenced by any removed member values.  If resources consumed by these objects also need to be released, such release operations (such as drop messages) can be performed prior to removing the member values.
 */
public native void removeAll ();

/**
 *  The remove: message removes the first member in the collection with a value matching the value passed as its argument.  If there is no such member, a nil value is returned.  As with the contains: message, the speed of this operation may vary from very low to linear in the number of members, depending on the collection subtype.
 */
public native Object remove (Object aMember);

/**
 *  The contains: message returns true if the collection contains any member value which matches the value passed as its argument. Depending on the collection subtype, this may require traversing sequentially through all members of the collection until a matching member is found.  For other subtypes, some form of direct indexing from the member value may be supported.  The message is supported regardless of its speed.
 */
public native boolean contains (Object aMember);

/**
 *  getCount returns the integer number of members currently contained in the collection.  All collections maintain their count internally so that no traversal of collection members is required simply to return this value.
 */
public native int getCount ();

/**
 * 
 */
public native boolean getReplaceOnly ();

/**
 *  The activateIn: message is used to initialize a process for executing the actions of an ActionType.  This process is controlled by an object called an Activity.  The activateIn message initializes an activity to run under the execution context passed as the swarmContext argument, and return the activity object just created.  If the execution context is nil, an activity is returned that allows complete execution control by the caller.  Otherwise, the execution context must be either an instance of SwarmProcess or SwarmActivity.  (These objects are always maintained in one-to-one association with each other, either one of the pair is equivalent to the other as a swarmContext argument.) If a top-level activity is created (swarmContext is nil), the created activity may be processed using activity processing commands such as run, step, etc.  If an activity is created to run under a swarm context, the swarm itself has responsibility for advancing the subactivity according to its requirements for synchronization and control among all its activities.  Activating a plan for execution under a swarm turns over control to the swarm to execute the subactivity as a more-or-less autonomous activity.
 */
public native Activity activateIn (swarm.objectbase.Swarm swarmContext);

/**
 * 
 */
public native void describeForEachID (Object outputCharStream);

/**
 * 
 */
public native void describeForEach (Object outputCharStream);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1, Object arg2);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1, Object arg2, Object arg3);

/**
 *  Equivalent to [aCollection atOffset: [aCollection getCount] - 1].
 */
public native Object getLast ();

/**
 *  Equivalent to [aCollection atOffset: 0].
 */
public native Object getFirst ();

/**
 *  Returns the member at a particular member offset.
 */
public native Object atOffset (int offset);

/**
 *  The atOffset: put: message replaces the member at a particular offset with a new value, and returns the previous member value at this offset.
 */
public native Object atOffset$put (int offset, Object anObject);

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The copy message creates a new object that has the same contents and resulting behavior as a starting object, except that an independent copy of the contents of the starting object is created so that further changes to one object do not affect the other.  The zone argument specifies the source of storage for the new object.  The message returns the id of the new object created.
 */
public native Object copy (swarm.defobj.Zone aZone);

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();

/**
 * 
 */
public native Object setDefaultOrder (swarm.defobj.Symbol aSymbol);
public ActionGroupImpl () {
  super ();
}

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public ActionGroupImpl (swarm.defobj.Zone aZone) { super (); new ActionGroupCImpl (this).create (aZone); }
}
