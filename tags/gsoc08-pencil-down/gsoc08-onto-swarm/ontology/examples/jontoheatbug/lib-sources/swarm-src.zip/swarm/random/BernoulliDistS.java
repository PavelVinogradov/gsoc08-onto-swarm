package swarm.random;

/**
 * <strong> Bernoulli Distribution </strong>.

 A distribution returning YES with a given probability.
 */
public interface BernoulliDistS extends BooleanDistributionS {

/**
 *  The setProbability: method sets the probability of returning YES.
 */
Object setProbability (double p);
}
