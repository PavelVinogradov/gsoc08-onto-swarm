package swarm.collections;

/**
 * <strong> A generic collection interface.</strong>.

 A collection is a grouping of object references or other data values which are assigned explicitly as members of the collection.  Depending on the subtype, collection members may also be maintained in various associations with each other, such as an ordering of members or an association of members with identifying key values.  Major Collection subtypes include Array, List, Set and Map.  The Collection supertype establishes common conventions (and associated messages) supported by all types of collections. All collections support traversal over their members using a separate object called an Index.  All collections also follow common rules regarding the types of data values which may be added as members.  The next two subsections summarize these basic features of all collections. An index is a special type of object that references a current position in an enumeration sequence over a collection.  An enumeration sequence contains every member of a collection exactly once.  Every collection defines an associated type of object for its index.  The index type of a collection defines additional ways in which the members of a collection may be processed beyond any messages available directly on the collection.  Often the operations of an index provide the most basic and flexible means for manipulating individual members of a collection. An index object into a collection may be created at any time.  An index is the basic means to traverse through all members of a collection.  Multiple indexes on the same collection may all exist at the same time and may reference the same or different positions. Depending on the collection type, it may be possible to modify a collection through its indexes. Once an index is created, the sequence of members in its enumeration sequence is guaranteed to remain the same, provided that no new members are added to the underlying collection, or existing members removed.  If a member is located once at a particular position, it is guaranteed to remain at that position as long as the index itself remains. Many collection types define an explicit ordering over their members. For such collections, the sequence of members referred to by an index will always be consistent with this ordering.  An explicit, total ordering also guarantees that all indexes of the same collection have the same member sequence. If no such ordering is defined, however, some particular sequence of all the collection still becomes associated with each created index. All collection members are guaranteed to be contained somewhere in the enumeration sequence for any particular index, but two indexes on the same collection are not guaranteed to have the same sequence. The Index type corresponds to the iterator types defined as part of many other object-oriented libraries.  The name Index is shorter and emphasizes the more abstract and multi-function role of these basic support objects for any collection.  For more background on design of indexes and iterators, see the Interface Design Notes for the collections library.
 */
public interface Collection extends swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.SetInitialValue, swarm.defobj.SetInitialValueS, swarm.defobj.Copy, swarm.defobj.CopyS, swarm.defobj.Drop, swarm.defobj.DropS, Offsets, OffsetsS, ForEach, ForEachS {

/**
 *  Note: copies are shallow; members inside the collection are not copied.
 */
Object copy (swarm.defobj.Zone aZone);

/**
 * 
 */
boolean getReplaceOnly ();

/**
 *  getCount returns the integer number of members currently contained in the collection.  All collections maintain their count internally so that no traversal of collection members is required simply to return this value.
 */
int getCount ();

/**
 *  The contains: message returns true if the collection contains any member value which matches the value passed as its argument. Depending on the collection subtype, this may require traversing sequentially through all members of the collection until a matching member is found.  For other subtypes, some form of direct indexing from the member value may be supported.  The message is supported regardless of its speed.
 */
boolean contains (Object aMember);

/**
 *  The remove: message removes the first member in the collection with a value matching the value passed as its argument.  If there is no such member, a nil value is returned.  As with the contains: message, the speed of this operation may vary from very low to linear in the number of members, depending on the collection subtype.
 */
Object remove (Object aMember);

/**
 *  The removeAll message removes all existing members of a collection and sets its member count to zero.  The collection then remains valid for further members to be added.  This message has no effect on the objects which might be referenced by any removed member values.  If resources consumed by these objects also need to be released, such release operations (such as drop messages) can be performed prior to removing the member values.
 */
void removeAll ();

/**
 *  Like removeAll:, but drops the member(s) as well.
 */
void deleteAll ();

/**
 *  Returns YES if all members are of the same class.
 */
boolean allSameClass ();

/**
 *  The begin: message is the standard method for creating a new index for traversing the elements of a collection.  All further information about indexes is documented under the Index type.
 */
Index begin (swarm.defobj.Zone aZone);

/**
 * 
 */
PermutedIndex beginPermuted (swarm.defobj.Zone aZone);
}
