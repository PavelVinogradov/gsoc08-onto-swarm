package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface CommonGeneratorC  {

/**
 * 
 */
Object createWithDefaults (swarm.defobj.Zone aZone);
}
