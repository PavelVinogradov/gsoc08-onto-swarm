package swarm.collections;

/**
 * <strong> The index behavior for a Map.</strong>.

 The index behavior for a Map.
 */
public interface MapIndex extends KeyedCollectionIndex, KeyedCollectionIndexS {

/**
 *  The setKey: messages repositions the index to an entry having a key value that matches its argument.  If there is more than one entry matching this key value, the index is positioned to the first entry that matches.
 */
Object setKey (Object aKey);

/**
 *  The getKey message returns the key value associated with the current location of the index.  It returns nil if the index is not currently positioned at a member. 
 */
Object getKey ();

/**
 *  The getKeyValue message returns the integer value associated with the current location of the index.  It is exactly like getKey, except the value is returned as an integer.  (A common application of this method is to get a Schedule time value associated with an Action in Java.)
 */
int getKeyValue ();
}
