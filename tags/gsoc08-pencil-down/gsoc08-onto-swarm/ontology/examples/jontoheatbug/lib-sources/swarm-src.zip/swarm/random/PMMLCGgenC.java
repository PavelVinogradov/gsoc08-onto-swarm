package swarm.random;

/**
 * <strong> Prime Modulus Multiplicative Linear Congruential Generator</strong>.

 These generator have single full cycle of length (m-1).
 */
public interface PMMLCGgenC extends SimpleRandomGeneratorC, SimpleRandomGeneratorS {
}
