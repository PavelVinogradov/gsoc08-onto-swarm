package swarm.activity;

/**
 * <strong> An action defined by applying a FAction to every member of a collection All members of the collection must be of the same type.</strong>.

 An action defined by applying a FAction to every member of a collection. All members of the collection must be of the same type.
 */
public interface FActionForEachHomogeneous extends FActionForEach, FActionForEachS {
}
