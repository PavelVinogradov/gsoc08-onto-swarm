package swarm.random;

/**
 * <strong> Integer Distribution </strong>.

 A probability distribution that returns integer sample values.
 */
public interface IntegerDistributionC extends ProbabilityDistributionC, ProbabilityDistributionS {
}
