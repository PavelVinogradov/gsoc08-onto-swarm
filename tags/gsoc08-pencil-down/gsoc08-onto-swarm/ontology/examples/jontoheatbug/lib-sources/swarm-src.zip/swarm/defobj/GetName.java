package swarm.defobj;

/**
 * <strong> Get name which identifies object in its context of use.</strong>.

 Get name which identifies object in its context of use.
 */
public interface GetName  {

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
java.lang.String getName ();
}
