package swarm.objectbase;

/**
 * <strong> A class that provides an object interface to an activity.</strong>.

 The ActivityControl class specifies an object that can be attached to  an activity (regardless of how or where that activity is created) for the purpose of explicitly controlling the execution of actions on that  activity's action plan. There is nothing that available through this  class that is not already available through the variables or messages  available via the activity itself. However, it packages up the main  control messages and makes them available to other objects that may need  control over an activity, thereby shielding the activity from directly receiving messages from outside objects and saving the user from having  to parse the more complex interface to the activity. 
 */
public interface ActivityControl extends SwarmObject, SwarmObjectS {

/**
 *  The attachToActivity: method sets an instance variable inside the  ActivityControl object that points to the Activity to be controlled.  It then creates a Schedule upon which it places a message to itself to update its own variables.
 */
void attachToActivity (swarm.activity.ScheduleActivity anActivity);

/**
 *  The run method sends a run message to the activity if the conditions are appropriate.  This message causes the activity to continue executing the actions on its schedule until either no other actions are waiting, or  until the execution of actions is stopped by a subactivity or stopped by a stop message to the activity.  If the activity completes executing all  the actions on its schedule, the run method returns Completed.
 */
swarm.defobj.Symbol runActivity ();

/**
 *  The stop method sends a stop message to the activity if the conditions  are appropriate. This message causes the control to move back up the  run-stack and resume at the place in the code where the run was first  executed. The next action on the super-activity will begin without   finishing the rest of the current activity's actions. 
 */
swarm.defobj.Symbol stopActivity ();

/**
 *  The next method sends a next message to the activity if the conditions  are appropriate. It runs an activity forward through as many actions as  necessary until it hits a breakFunction, at which point it walks back up  the tree of activities and returns Stopped. In most cases, this means that an entire action or action group on the activity under control  will be executed, including completion of all subactivities. 
 */
swarm.defobj.Symbol nextAction ();

/**
 *  The step method sends a step message to the activity if the conditions are appropriate. It causes the execution of a single action. 
 */
swarm.defobj.Symbol stepAction ();

/**
 *  The stepUntil: method sends a stepUntil: message to the activity if  conditions are appropriate. This causes all actions on the activity's  schedule, including any actions on subactivities' schedules, to be  executed until the activity's relative time is equal to stopTime - 1. 
 */
swarm.defobj.Symbol stepUntil (int stopTime);

/**
 *  The updateStateVar method updates the ActivityControl instance variables and tests for the continued existence of the activity that is being  controlled. This message is sent on each cycle of the schedule for the  activity being controlled.
 */
void updateStateVar ();

/**
 *  The getStatus method returns the status of the activity.
 */
swarm.defobj.Symbol getStatus ();

/**
 *  Recursively removes all subactivities.
 */
void terminate ();

/**
 *  Return the controlled activity.
 */
swarm.activity.ScheduleActivity getActivity ();
}
