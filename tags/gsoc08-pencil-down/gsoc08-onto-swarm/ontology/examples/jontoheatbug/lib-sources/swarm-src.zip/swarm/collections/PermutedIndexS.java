package swarm.collections;

/**
 * <strong> General PermutedIndex class. </strong>.

 PermutedIndex class may be used for randomized traversals of a  collection.  Methods implemented offer the same functionality as  Index class does, except that traversal is randomized. 
 */
public interface PermutedIndexS extends IndexS {
}
