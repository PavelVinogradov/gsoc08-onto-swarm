package swarm.collections;

/**
 * <strong> Collection of associations from key objects to member objects.</strong>.

 Map is a subtype of KeyedCollection in which the key value associated with each member is independent of the member itself.  Whenever a new member is added to the collection, a key value to be associated with the member must be supplied also.  A Map defines a mapping from key values to member values. For the Map type, key values are independent of the member values with which they are associated.  Map defines two additional options to document information about its key values.  Map also defines its own messages to distinguish the key value from member value in any operation which involves both.
 */
public interface Map extends KeyedCollection, KeyedCollectionS, CompareFunction, CompareFunctionS, swarm.defobj.Serialization, swarm.defobj.SerializationS {

/**
 *  at:insert: inserts an entry into a Map containing the key and member values given as its arguments.  It returns true if the key was not previously contained in the collection.  An attempt to insert a duplicate key is simply rejected and false is returned.
 */
boolean at$insert (Object aKey, Object anObject);

/**
 *  Replaces an existing member value associated with a key value by a new value given as its final argument.  The message returns the member value which was formerly associated with the key value.
 */
Object at$replace (Object aKey, Object anObject);

/**
 *  Returns a MapIndex, the special index for the Map type
 */
MapIndex mapBegin (swarm.defobj.Zone aZone);
}
