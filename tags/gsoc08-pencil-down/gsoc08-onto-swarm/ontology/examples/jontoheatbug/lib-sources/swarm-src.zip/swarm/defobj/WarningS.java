package swarm.defobj;

/**
 * <strong> A condition of possible concern to a program developer.</strong>.

 A condition of possible concern to a program developer.
 */
public interface WarningS extends EventTypeS {
}
