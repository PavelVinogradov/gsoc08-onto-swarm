package swarm;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Container object for Swarm globals</strong>.

 Container object for Swarm globals
 */
public class SwarmEnvironmentImpl extends swarm.BaseImpl implements SwarmEnvironmentS, SwarmEnvironment {
public swarm.defobj.Symbol LanguageObjc;
public swarm.defobj.Symbol LanguageJava;
public swarm.defobj.Symbol LanguageCOM;
public boolean guiFlag;
public swarm.defobj.Archiver lispAppArchiver;
public swarm.defobj.Archiver hdf5AppArchiver;
public swarm.defobj.Archiver lispArchiver;
public swarm.defobj.Archiver hdf5Archiver;
public swarm.simtoolsgui.ProbeDisplayManager probeDisplayManager;
public swarm.objectbase.ProbeLibrary probeLibrary;
public swarm.random.UniformDoubleDist uniformDblRand;
public swarm.random.UniformIntegerDist uniformIntRand;
public swarm.random.MT19937gen randomGenerator;
public swarm.defobj.Zone globalZone;
public swarm.defobj.Zone scratchZone;
public swarm.defobj.Symbol ControlStateNextTime;
public swarm.defobj.Symbol ControlStateQuit;
public swarm.defobj.Symbol ControlStateStepping;
public swarm.defobj.Symbol ControlStateStopped;
public swarm.defobj.Symbol ControlStateRunning;
public swarm.defobj.Symbol Sequential;
public swarm.defobj.Symbol Randomized;
public swarm.defobj.Symbol Completed;
public swarm.defobj.Symbol Terminated;
public swarm.defobj.Symbol Released;
public swarm.defobj.Symbol Holding;
public swarm.defobj.Symbol Stopped;
public swarm.defobj.Symbol Running;
public swarm.defobj.Symbol Initialized;
public swarm.defobj.Symbol End;
public swarm.defobj.Symbol Member;
public swarm.defobj.Symbol Start;
public swarm.defobj.Arguments arguments;


/**
 * 
 */
public native void updateDisplay ();

/**
 * 
 */
public native void verboseMessage (java.lang.String message);

/**
 * 
 */
public native java.lang.String typeModule (java.lang.String typeName);

/**
 * 
 */
public native void dumpDirectory ();

/**
 * 
 */
public native void xfprint (Object obj);

/**
 * 
 */
public native void xprint (Object obj);

/**
 * 
 */
public native void setComponentWindowGeometryRecordName$name (Object widget, Object name);

/**
 * 
 */
public native void setComponentWindowGeometryRecordNameFor$widget$name (Object obj, Object widget, Object name);

/**
 * 
 */
public native void setWindowGeometryRecordName (Object obj, java.lang.String name);

/**
 * 
 */
public native void createArchivedCompleteProbeDisplay$name (Object obj, java.lang.String name);

/**
 * 
 */
public native void createArchivedProbeDisplay (Object obj, java.lang.String name);

/**
 * 
 */
public native void createCompleteProbeDisplay (Object obj);

/**
 * 
 */
public native void createProbeDisplay (Object obj);

/**
 * 
 */
public native swarm.activity.SwarmActivity getCurrentSwarmActivity ();

/**
 * 
 */
public native int getCurrentTime ();

/**
 * 
 */
public native void initSwarm (java.lang.String appName, java.lang.String version, java.lang.String bugAddress, java.lang.String[] args);

/**
 * 
 */
public native swarm.defobj.Symbol getLanguageObjc ();

/**
 * 
 */
public native swarm.defobj.Symbol getLanguageJava ();

/**
 * 
 */
public native swarm.defobj.Symbol getLanguageCOM ();

/**
 * 
 */
public native boolean getGuiFlag ();

/**
 * 
 */
public native swarm.defobj.Archiver getLispAppArchiver ();

/**
 * 
 */
public native swarm.defobj.Archiver getHdf5AppArchiver ();

/**
 * 
 */
public native swarm.defobj.Archiver getLispArchiver ();

/**
 * 
 */
public native swarm.defobj.Archiver getHdf5Archiver ();

/**
 * 
 */
public native swarm.simtoolsgui.ProbeDisplayManager getProbeDisplayManager ();

/**
 * 
 */
public native swarm.objectbase.ProbeLibrary getProbeLibrary ();

/**
 * 
 */
public native swarm.random.UniformDoubleDist getUniformDblRand ();

/**
 * 
 */
public native swarm.random.UniformIntegerDist getUniformIntRand ();

/**
 * 
 */
public native swarm.random.MT19937gen getRandomGenerator ();

/**
 * 
 */
public native swarm.defobj.Zone getGlobalZone ();

/**
 * 
 */
public native swarm.defobj.Zone getScratchZone ();

/**
 * 
 */
public native swarm.defobj.Symbol getControlStateNextTime ();

/**
 * 
 */
public native swarm.defobj.Symbol getControlStateQuit ();

/**
 * 
 */
public native swarm.defobj.Symbol getControlStateStepping ();

/**
 * 
 */
public native swarm.defobj.Symbol getControlStateStopped ();

/**
 * 
 */
public native swarm.defobj.Symbol getControlStateRunning ();

/**
 * 
 */
public native swarm.defobj.Symbol getSequential ();

/**
 * 
 */
public native swarm.defobj.Symbol getRandomized ();

/**
 * 
 */
public native swarm.defobj.Symbol getCompleted ();

/**
 * 
 */
public native swarm.defobj.Symbol getTerminated ();

/**
 * 
 */
public native swarm.defobj.Symbol getReleased ();

/**
 * 
 */
public native swarm.defobj.Symbol getHolding ();

/**
 * 
 */
public native swarm.defobj.Symbol getStopped ();

/**
 * 
 */
public native swarm.defobj.Symbol getRunning ();

/**
 * 
 */
public native swarm.defobj.Symbol getInitialized ();

/**
 * 
 */
public native swarm.defobj.Symbol getEnd ();

/**
 * 
 */
public native swarm.defobj.Symbol getMember ();

/**
 * 
 */
public native swarm.defobj.Symbol getStart ();

/**
 * 
 */
public native swarm.defobj.Arguments getArguments ();
public SwarmEnvironmentImpl () {
  super ();
LanguageObjc = new swarm.defobj.SymbolImpl ();
LanguageJava = new swarm.defobj.SymbolImpl ();
LanguageCOM = new swarm.defobj.SymbolImpl ();
lispAppArchiver = new swarm.defobj.ArchiverImpl ();
hdf5AppArchiver = new swarm.defobj.ArchiverImpl ();
lispArchiver = new swarm.defobj.ArchiverImpl ();
hdf5Archiver = new swarm.defobj.ArchiverImpl ();
probeDisplayManager = new swarm.simtoolsgui.ProbeDisplayManagerImpl ();
probeLibrary = new swarm.objectbase.ProbeLibraryImpl ();
uniformDblRand = new swarm.random.UniformDoubleDistImpl ();
uniformIntRand = new swarm.random.UniformIntegerDistImpl ();
randomGenerator = new swarm.random.MT19937genImpl ();
globalZone = new swarm.defobj.ZoneImpl ();
scratchZone = new swarm.defobj.ZoneImpl ();
ControlStateNextTime = new swarm.defobj.SymbolImpl ();
ControlStateQuit = new swarm.defobj.SymbolImpl ();
ControlStateStepping = new swarm.defobj.SymbolImpl ();
ControlStateStopped = new swarm.defobj.SymbolImpl ();
ControlStateRunning = new swarm.defobj.SymbolImpl ();
Sequential = new swarm.defobj.SymbolImpl ();
Randomized = new swarm.defobj.SymbolImpl ();
Completed = new swarm.defobj.SymbolImpl ();
Terminated = new swarm.defobj.SymbolImpl ();
Released = new swarm.defobj.SymbolImpl ();
Holding = new swarm.defobj.SymbolImpl ();
Stopped = new swarm.defobj.SymbolImpl ();
Running = new swarm.defobj.SymbolImpl ();
Initialized = new swarm.defobj.SymbolImpl ();
End = new swarm.defobj.SymbolImpl ();
Member = new swarm.defobj.SymbolImpl ();
Start = new swarm.defobj.SymbolImpl ();
arguments = new swarm.defobj.ArgumentsImpl ();
}

/**
 * 
 */
public SwarmEnvironmentImpl (java.lang.String appName, java.lang.String version, java.lang.String bugAddress, int count, java.lang.String[] args) { super (); new SwarmEnvironmentCImpl (this).initSwarm$version$bugAddress$argCount$args (appName, version, bugAddress, count, args); }
}
