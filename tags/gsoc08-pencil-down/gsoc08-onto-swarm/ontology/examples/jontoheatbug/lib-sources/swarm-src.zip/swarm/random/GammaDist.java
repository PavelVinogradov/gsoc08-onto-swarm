package swarm.random;

/**
 * <strong> Gamma distribution</strong>.

 A well-known continuous probability distribution returning doubles
 */
public interface GammaDist extends DoubleDistribution, DoubleDistributionS {

/**
 *  The getAlpha method returns the alpha value.
 */
double getAlpha ();

/**
 *  The getBeta method returns the beta value.
 */
double getBeta ();

/**
 *  The getSampleWithAlpha:withBeta: method returns a sample value from a Gamma distribution with the specified alpha and beta values.
 */
double getSampleWithAlpha$withBeta (double alpha, double beta);
}
