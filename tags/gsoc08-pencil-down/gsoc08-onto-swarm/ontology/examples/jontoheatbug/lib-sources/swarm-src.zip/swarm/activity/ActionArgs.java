package swarm.activity;

/**
 * <strong> Supertype of ActionCall, ActionTo, and ActionForEach.</strong>.

 The ActionArgs subtypes all implement a specific, hard-coded method for binding an action type to a fixed number of arguments.  All the arguments must have types compatible with id type.  Eventually, more generic methods for binding an action type to any number and types of arguments and return values will also be provided.
 */
public interface ActionArgs  {

/**
 * 
 */
int getNArgs ();

/**
 * 
 */
Object getArg1 ();

/**
 * 
 */
Object getArg2 ();

/**
 * 
 */
Object getArg3 ();
}
