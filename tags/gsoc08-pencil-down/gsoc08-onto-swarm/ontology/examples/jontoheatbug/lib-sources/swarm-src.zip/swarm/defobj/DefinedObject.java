package swarm.defobj;

/**
 * <strong> Object with defined type and implementation.</strong>.

 DefinedObject is the top-level supertype for all objects that follow the object programming conventions of the defobj library.  The messages defined by this type are the only messages which should be assumed to be automatically available on objects that follow these conventions.  In particular, use of messages defined by the Object superclass of the GNU Objective C runtime should not generally be assumed because future implementations of some objects might not give continued access to them. The DefinedObject type defines a minimum of standard messages, and leaves to other types the definition of message that might or might not apply in any general way to particular objects.
 */
public interface DefinedObject extends GetName, GetNameS {

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
boolean respondsTo (swarm.Selector aSel);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
java.lang.String getTypeName ();

/**
 *  A local implementation of an Object method.
 */
int compare (Object anObject);

/**
 *  A local implementation of an Object method.
 */
Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
void setDisplayName (java.lang.String displayName);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
java.lang.String getDisplayName ();

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
void describe (Object outputCharStream);

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
void describeID (Object outputCharStream);

/**
 *  Like describe:, but output goes to standard output.
 */
void xprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
void xprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
void xfprint ();

/**
 *  print id for each member of a collection on debug output stream
 */
void xfprintid ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
Zone getZone ();
}
