package swarm.collections;
import swarm.defobj.ZoneImpl;
/**
 * <strong> General PermutedIndex class. </strong>.

 PermutedIndex class may be used for randomized traversals of a  collection.  Methods implemented offer the same functionality as  Index class does, except that traversal is randomized. 
 * @hide
 */
public class PermutedIndexCImpl extends swarm.PhaseCImpl implements IndexC, IndexS, PermutedIndexS, PermutedIndexC {

/**
 * 
 */
public native Object setUniformRandom (Object rnd);

/**
 * 
 */
public native Object setCollection (Object aCollection);
}
