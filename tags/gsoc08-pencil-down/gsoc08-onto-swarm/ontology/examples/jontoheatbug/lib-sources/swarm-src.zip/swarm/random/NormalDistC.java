package swarm.random;

/**
 * <strong>  Normal (Gaussian) distribution</strong>.

  A well-known continuous probability distribution returning doubles.
 */
public interface NormalDistC extends NormalC, NormalS {
}
