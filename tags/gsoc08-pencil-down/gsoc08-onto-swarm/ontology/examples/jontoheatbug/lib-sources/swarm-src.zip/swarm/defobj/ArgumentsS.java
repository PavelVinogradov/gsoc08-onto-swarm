package swarm.defobj;

/**
 * <strong> A class that provides customizable command line argument parsing support</strong>.

 A class that provides customizable command line argument parsing support
 */
public interface ArgumentsS extends CreateS, DropS {

/**
 * 
 */
Object setInhibitArchiverLoadFlag (boolean inhibitArchiverLoadFlag);

/**
 * 
 */
Object setInhibitExecutableSearchFlag (boolean theInhibitExecutableSearchFlag);

/**
 * 
 */
Object setBatchModeFlag (boolean batchModeFlag);

/**
 * 
 */
Object setVarySeedFlag (boolean varySeedFlag);

/**
 * 
 */
Object setVerboseFlag (boolean verboseFlag);

/**
 *  Specify a default path to use for configuration files when installed location of Swarm cannot be determined.  Defaults to current directory.
 */
Object setDefaultAppConfigPath (java.lang.String path);

/**
 *  Specify a default path to use for data files when installed location of Swarm cannot be determined.  Defaults to current directory.
 */
Object setDefaultAppDataPath (java.lang.String path);

/**
 * 
 */
Object setFixedSeed (int seed);
}
