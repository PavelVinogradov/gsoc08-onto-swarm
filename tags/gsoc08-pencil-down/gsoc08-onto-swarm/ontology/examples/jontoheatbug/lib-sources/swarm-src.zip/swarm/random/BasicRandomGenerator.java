package swarm.random;

/**
 * <strong> The common functionality of simple and split generators.</strong>.

 This protocol covers methods common to simple and split generators.
 */
public interface BasicRandomGenerator extends swarm.objectbase.SwarmObject, swarm.objectbase.SwarmObjectS, InternalState, InternalStateS, CommonGenerator, CommonGeneratorS {
}
