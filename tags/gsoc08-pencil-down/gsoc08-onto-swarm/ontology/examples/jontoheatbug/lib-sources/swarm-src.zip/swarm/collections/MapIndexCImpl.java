package swarm.collections;
import swarm.defobj.ZoneImpl;
/**
 * <strong> The index behavior for a Map.</strong>.

 The index behavior for a Map.
 * @hide
 */
public class MapIndexCImpl extends swarm.PhaseCImpl implements KeyedCollectionIndexC, KeyedCollectionIndexS, MapIndexS, MapIndexC {
}
