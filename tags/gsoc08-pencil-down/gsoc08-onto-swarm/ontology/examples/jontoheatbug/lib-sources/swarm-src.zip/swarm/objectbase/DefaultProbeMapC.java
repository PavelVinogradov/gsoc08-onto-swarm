package swarm.objectbase;

/**
 * <strong> A subclass of ProbeMap, whose initial state contains all the VarProbes  of the requested target class and also those of all its superclasses.</strong>.

 A subclass of ProbeMap, whose initial state contains all the VarProbes  of the requested target class and also those of all its superclasses.
 */
public interface DefaultProbeMapC extends ProbeMapC, ProbeMapS {
}
