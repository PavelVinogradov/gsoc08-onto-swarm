package swarm.activity;

/**
 * <strong> A collection of actions ordered by time values.</strong>.

 A schedule is compound action whose basic representation is a sorted Map of actions that have been created within it.  The key value associated with each of these actions is an unsigned integer value for which the typedef timeval_t is supplied. A schedule inherits its underlying representation from the Map type of the collections library.  All the members of the ordered set must consist only of actions that are created by one of the createAction messages defined on Schedule itself.  Once the actions are created, they may be accessed or traversed using standard messages of the Map type.  The key values of this collection, however, must be cast to and from the id type defined for key values by the Map type.  The messages to create actions within a schedule are essentially the same as those for ActionGroup, except for the presence of an initial at: argument indicating the time at which an action is to be performed.  Except for the time associated with each action, meaning of the createAction messages is the same as for ActionGroup. When multiple actions are all scheduled at the same time, they are all inserted into a concurrent action group created for that time value. The ConcurrentGroupType option may be used to override the default action group for these concurrent actions by a custom user-defined subclass.  (.. Details of doing this are not yet documented, but there are examples.)
 */
public interface ScheduleC extends swarm.collections.MapC, swarm.collections.MapS, CompoundActionC, CompoundActionS, ActionCreatingC, ActionCreatingS, RelativeTimeC, RelativeTimeS, RepeatIntervalC, RepeatIntervalS, ConcurrentGroupTypeC, ConcurrentGroupTypeS, SingletonGroupsC, SingletonGroupsS {

/**
 *  Convenience method for creating a repeating Schedule
 */
Object create$setRepeatInterval (swarm.defobj.Zone aZone, int rptInterval);

/**
 *  Convenience method for creating an AutoDrop Schedule
 */
Object create$setAutoDrop (swarm.defobj.Zone aZone, boolean autoDrop);

/**
 *  Indicate whether an empty schedule should be dropped and ignored or or kept and attended to (default is YES).
 */
Object setKeepEmptyFlag (boolean keepEmptyFlag);
}
