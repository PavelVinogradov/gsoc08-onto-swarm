package swarm.defobj;

/**
 * <strong> Create using initial value from an existing object.</strong>.

 The SetInitialValue type defines a variety of messages relating to an initial or unmodifiable value established as part of an object.  This message is typically provided when creation of a new object might be more easily accomplished by copying the value of an existing object rather than establishing a new value from scratch.  As with the copy message, precisely what is considered the value of an existing object to copy is defined only by the particular object type that supplies these messages. If an object has a value which can be established at create time, it is often useful (and can also enable significant optimization) to declare that no further modification will occur to this value during further use of the object.  A restriction against modifying a value is referred to as a "read-only" restriction.  This type supplies messages to declare a read-only restriction along with any initial value.  For some object types, a read-only restriction can also be added or removed after an object has already been created.
 */
public interface SetInitialValue  {
}
