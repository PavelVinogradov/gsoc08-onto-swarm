package swarm.defobj;

/**
 * <strong> Get name which identifies object in its context of use.</strong>.

 Get name which identifies object in its context of use.
 */
public interface GetNameS  {
}
