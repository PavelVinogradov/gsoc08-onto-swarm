package swarm.activity;

/**
 * <strong> Default type used as concurrent group of a swarm.</strong>.

 Concurrent group to order merge by activation order within swarm.
 */
public interface ActivationOrderC extends ActionGroupC, ActionGroupS {
}
