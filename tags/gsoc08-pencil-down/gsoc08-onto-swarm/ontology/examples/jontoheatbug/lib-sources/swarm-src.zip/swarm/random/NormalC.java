package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface NormalC extends DoubleDistributionC, DoubleDistributionS {

/**
 *  Use this create message if the generator to be attached is a Simple one and you wish to specify the variance:
 */
Object create$setGenerator$setMean$setVariance (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double mean, double variance);

/**
 *  Use this create message if the generator to be attached is a Simple one and you wish to specify the standard deviation:
 */
Object create$setGenerator$setMean$setStdDev (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double mean, double sdev);

/**
 *  Use this create message if the generator to be attached is a Split one and you wish to specify the variance:
 */
Object create$setGenerator$setVirtualGenerator$setMean$setVariance (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double mean, double variance);

/**
 *  Use this create message if the generator to be attached is a Split one and you wish to specify the standard deviation:
 */
Object create$setGenerator$setVirtualGenerator$setMean$setStdDev (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double mean, double sdev);
}
