package swarm.activity;

/**
 * <strong> An action that calls a C function.</strong>.

 The createActionCall: messages are similar to the createActionTo messages, except they specify the action to be performed as a binding of a C function to a list of argument values.  The correct number of arguments for the function pointer passed as the initial argument must be supplied.
 */
public interface ActionCreatingCallS  {
}
