package swarm.activity;

/**
 * <strong> Time-based map usable for concurrent group.</strong>.

 Time-based map usable for concurrent group.
 */
public interface ConcurrentSchedule extends ConcurrentGroup, ConcurrentGroupS, Schedule, ScheduleS {
}
