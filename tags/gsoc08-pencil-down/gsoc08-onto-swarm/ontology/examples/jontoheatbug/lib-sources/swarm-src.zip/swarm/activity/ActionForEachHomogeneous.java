package swarm.activity;

/**
 * <strong> Like ActionForEach, except that the collection must be homogeneous.</strong>.

 Like ActionForEach, except that the collection must be homogeneous.
 */
public interface ActionForEachHomogeneous extends Action, ActionS, ActionTarget, ActionTargetS, ActionSelector, ActionSelectorS, DefaultOrder, DefaultOrderS {
}
