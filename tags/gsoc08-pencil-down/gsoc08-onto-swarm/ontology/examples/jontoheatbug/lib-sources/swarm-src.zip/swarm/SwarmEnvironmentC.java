package swarm;

/**
 * <strong> Container object for Swarm globals</strong>.

 Container object for Swarm globals
 */
public interface SwarmEnvironmentC  {

/**
 * 
 */
Object createBegin ();

/**
 * 
 */
Object setArguments (swarm.defobj.Arguments arguments);

/**
 * 
 */
Object setBatchMode (boolean batchMode);

/**
 * 
 */
Object createEnd ();

/**
 * 
 */
Object initSwarm$version$bugAddress$argCount$args (java.lang.String appName, java.lang.String version, java.lang.String bugAddress, int count, java.lang.String[] args);
}
