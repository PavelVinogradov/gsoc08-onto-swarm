package swarm.collections;

/**
 * <strong> An element of a Permutation</strong>.

 An element of a Permutation
 */
public interface PermutationItem extends swarm.defobj.Create, swarm.defobj.CreateS {

/**
 * 
 */
Object getItem ();

/**
 * 
 */
int getPosition ();
}
