package swarm.collections;

/**
 * <strong> Index behavior shared by Set and Map types.</strong>.

 An index to a keyed collection traverses all members of the collection, regardless of whether these members belong to collections of members entered under duplicate key values.  Internally, however, an index keeps track of any specific subcollection it is currently processing.
 */
public interface KeyedCollectionIndexS extends IndexS {
}
