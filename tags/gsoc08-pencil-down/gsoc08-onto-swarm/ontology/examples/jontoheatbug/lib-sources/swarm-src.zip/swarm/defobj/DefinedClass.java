package swarm.defobj;

/**
 * <strong> Class which implements an interface of a type.</strong>.

 Class which implements an interface of a type.
 */
public interface DefinedClass extends DefinedObject, DefinedObjectS {

/**
 * 
 */
Object getSuperclass ();

/**
 * 
 */
boolean isSubclass (Object aClass);

/**
 * 
 */
void setTypeImplemented (Object aType);

/**
 * 
 */
Object getTypeImplemented ();
}
