package swarm.random;

/**
 * <strong> Combined Tausworthe generator 2</strong>.

 Component 1 parameters: P = 31, S = 21, Q =  3 Component 2 parameters: P = 29, S = 17, Q =  2 With these parameters, this generator has a single full cycle of  length ~ 2^60.
 */
public interface C2TAUS2genC extends C2TAUSgenC, C2TAUSgenS {
}
