package swarm.random;

/**
 * <strong> Binomial distribution</strong>.

 The binomial distribution gives the discrete probability  of obtaining exactly n successes out of N Bernoulli trials
 */
public interface BinomialDistC extends UnsignedDistributionC, UnsignedDistributionS {

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
Object create$setGenerator (swarm.defobj.Zone aZone, SimpleRandomGenerator generator);

/**
 *  Use this create message if the generator to be attached is a Simple one: and both the number of trials and the probability are to be set at create time:
 */
Object create$setGenerator$setNumTrials$setProbability (swarm.defobj.Zone aZone, SimpleRandomGenerator generator, int aNumTrials, double aProbability);

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
Object create$setGenerator$setVirtualGenerator (swarm.defobj.Zone aZone, SplitRandomGenerator generator, int vGen);

/**
 *  Use this create message if the generator to be attached is a Split one and both the number of trials and the probability are to be set at create time:
 */
Object create$setGenerator$setVirtualGenerator$setNumTrials$setProbability (swarm.defobj.Zone aZone, SplitRandomGenerator generator, int vGen, int aNumTrials, double aProbability);
}
