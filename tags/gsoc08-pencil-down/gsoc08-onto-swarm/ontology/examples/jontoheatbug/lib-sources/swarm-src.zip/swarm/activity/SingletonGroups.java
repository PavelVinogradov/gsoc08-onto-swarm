package swarm.activity;

/**
 * <strong> Indicates that an action group should be created for every time value which is present.</strong>.

 The SingletonGroups option indicates that an action group should be created for every time value which is present, even when only a single action is present at the time value. Ordinarily, a concurrent action group is created to process actions at the same timestep only if more than one action is scheduled at that timestep.  The overhead of these action groups is relatively low, because it just creates a single new object to which actions are directly linked, but it is still faster to avoid creating them if only one action is present at a timestep.  If a custom subclass is being provided however, it may need to examine the actions at a timestep even if there is only one.
 */
public interface SingletonGroups  {

/**
 * 
 */
boolean getSingletonGroups ();
}
