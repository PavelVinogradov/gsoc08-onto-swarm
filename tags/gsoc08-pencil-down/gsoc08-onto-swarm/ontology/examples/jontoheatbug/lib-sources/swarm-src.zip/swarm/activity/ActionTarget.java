package swarm.activity;

/**
 * <strong> Messages common to actions that are sent to an object.</strong>.

 Messages common to actions that are sent to an object.
 */
public interface ActionTarget  {

/**
 * 
 */
Object getTarget ();
}
