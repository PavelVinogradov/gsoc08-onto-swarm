package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> State of execution within a ForEach action.</strong>.

 State of execution within a ForEach action.
 * @hide
 */
public class ForEachActivityCImpl extends swarm.PhaseCImpl implements ActivityC, ActivityS, ForEachActivityS, ForEachActivityC {
}
