package swarm.activity;

/**
 * <strong> An action defined by applying a FAction to every member of a collection.</strong>.

 An action defined by applying a FAction to every member of a collection.
 */
public interface FActionForEachHeterogeneousS extends FActionForEachS {
}
