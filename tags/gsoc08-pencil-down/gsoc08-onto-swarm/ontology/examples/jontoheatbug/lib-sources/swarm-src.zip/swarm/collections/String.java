package swarm.collections;

/**
 * <strong> Character string object (later to support collection behavior).</strong>.

 The String object type packages a null-terminated, C-format character string into an object.  All memory allocation needed to hold the string value is handled by the object.  This type currently defines only the most rudimentary operations for initializing and appending C-format character strings.  These are sufficient for its current limited roles in places that need a uniformity between character strings and other kinds of allocated objects.
 */
public interface String extends swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.Drop, swarm.defobj.DropS, swarm.defobj.Copy, swarm.defobj.CopyS {

/**
 * 
 */
java.lang.String getC ();

/**
 * 
 */
void catC (java.lang.String cstring);

/**
 * 
 */
int getCount ();
}
