package swarm.defobj;

/**
 * <strong> Created class which implements a phase of object behavior.</strong>.

 Created class which implements a phase of object behavior.
 */
public interface BehaviorPhase extends CreatedClass, CreatedClassS {

/**
 * 
 */
Object getNextPhase ();
}
