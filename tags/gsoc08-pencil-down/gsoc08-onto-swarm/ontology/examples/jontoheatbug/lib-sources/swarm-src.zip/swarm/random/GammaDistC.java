package swarm.random;

/**
 * <strong> Gamma distribution</strong>.

 A well-known continuous probability distribution returning doubles
 */
public interface GammaDistC extends DoubleDistributionC, DoubleDistributionS {

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
Object create$setGenerator$setAlpha$setBeta (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double alpha, double beta);

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
Object create$setGenerator$setVirtualGenerator$setAlpha$setBeta (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double alpha, double beta);
}
