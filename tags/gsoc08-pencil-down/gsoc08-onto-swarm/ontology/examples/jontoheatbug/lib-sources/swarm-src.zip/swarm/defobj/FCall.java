package swarm.defobj;

/**
 * <strong> A language independent interface to dynamic calls.</strong>.

 A language independent interface to dynamic calls.
 */
public interface FCall extends Create, CreateS, Drop, DropS {

/**
 * 
 */
Object getArguments ();

/**
 * 
 */
void performCall ();
}
