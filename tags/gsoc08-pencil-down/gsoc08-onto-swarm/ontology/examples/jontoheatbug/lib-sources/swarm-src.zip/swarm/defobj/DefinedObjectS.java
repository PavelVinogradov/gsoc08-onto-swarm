package swarm.defobj;

/**
 * <strong> Object with defined type and implementation.</strong>.

 DefinedObject is the top-level supertype for all objects that follow the object programming conventions of the defobj library.  The messages defined by this type are the only messages which should be assumed to be automatically available on objects that follow these conventions.  In particular, use of messages defined by the Object superclass of the GNU Objective C runtime should not generally be assumed because future implementations of some objects might not give continued access to them. The DefinedObject type defines a minimum of standard messages, and leaves to other types the definition of message that might or might not apply in any general way to particular objects.
 */
public interface DefinedObjectS extends GetNameS {
}
