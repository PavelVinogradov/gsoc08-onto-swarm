package swarm.defobj;

/**
 * <strong> Deallocate an object allocated within a zone.</strong>.

 The Drop supertype defines the drop message, which is a standard message for indicating that an object no longer exists and will never again be referenced.  Any future attempt to reference a dropped object is an error.  This error may or not produce predictable effects depending on the level of debug checking and other factors.
 */
public interface DropC  {
}
