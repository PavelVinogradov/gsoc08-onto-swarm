package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A collection of actions ordered by time values.</strong>.

 A schedule is compound action whose basic representation is a sorted Map of actions that have been created within it.  The key value associated with each of these actions is an unsigned integer value for which the typedef timeval_t is supplied. A schedule inherits its underlying representation from the Map type of the collections library.  All the members of the ordered set must consist only of actions that are created by one of the createAction messages defined on Schedule itself.  Once the actions are created, they may be accessed or traversed using standard messages of the Map type.  The key values of this collection, however, must be cast to and from the id type defined for key values by the Map type.  The messages to create actions within a schedule are essentially the same as those for ActionGroup, except for the presence of an initial at: argument indicating the time at which an action is to be performed.  Except for the time associated with each action, meaning of the createAction messages is the same as for ActionGroup. When multiple actions are all scheduled at the same time, they are all inserted into a concurrent action group created for that time value. The ConcurrentGroupType option may be used to override the default action group for these concurrent actions by a custom user-defined subclass.  (.. Details of doing this are not yet documented, but there are examples.)
 */
public class ScheduleImpl extends swarm.BaseImpl implements swarm.collections.Map, swarm.collections.MapS, CompoundAction, CompoundActionS, ActionCreating, ActionCreatingS, RelativeTime, RelativeTimeS, RepeatInterval, RepeatIntervalS, ConcurrentGroupType, ConcurrentGroupTypeS, SingletonGroups, SingletonGroupsS, ScheduleS, Schedule {


/**
 * 
 */
public native ActionGroup insertGroup (int tVal);

/**
 * 
 */
public native FActionForEachHomogeneous at$createFActionForEachHomogeneous$call (int tVal, Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native FActionForEachHeterogeneous at$createFActionForEachHeterogeneous$call (int tVal, Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native ActionForEach at$createActionForEach$message (int tVal, Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionForEach at$createActionForEach$message (int tVal, Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionForEach at$createActionForEach$message (int tVal, Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionForEach at$createActionForEach$message (int tVal, Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native ActionForEachHomogeneous at$createActionForEachHomogeneous$message (int tVal, Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo at$createActionTo$message (int tVal, Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo at$createActionTo$message (int tVal, Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionTo at$createActionTo$message (int tVal, Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionTo at$createActionTo$message (int tVal, Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native FAction at$createFAction (int tVal, swarm.defobj.FCall call);

/**
 * 
 */
public native Object at$createAction (int tVal, Object anActionType);

/**
 * 
 */
public native boolean getSingletonGroups ();

/**
 * 
 */
public native Object getConcurrentGroupType ();

/**
 * 
 */
public native int getRepeatInterval ();

/**
 * 
 */
public native boolean getRelativeTime ();

/**
 *  The createAction: message specifies that processing of another action type is to be performed by the action.  The referenced action type is performed in its entirety, from start to finish, as the effect of the single created action.
 */
public native Object createAction (Object anActionType);

/**
 *  Returns a MapIndex, the special index for the Map type
 */
public native swarm.collections.MapIndex mapBegin (swarm.defobj.Zone aZone);

/**
 *  Replaces an existing member value associated with a key value by a new value given as its final argument.  The message returns the member value which was formerly associated with the key value.
 */
public native Object at$replace (Object aKey, Object anObject);

/**
 *  at:insert: inserts an entry into a Map containing the key and member values given as its arguments.  It returns true if the key was not previously contained in the collection.  An attempt to insert a duplicate key is simply rejected and false is returned.
 */
public native boolean at$insert (Object aKey, Object anObject);

/**
 * 
 */
public native FActionForEachHomogeneous createFActionForEachHomogeneous$call (Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native FActionForEachHeterogeneous createFActionForEachHeterogeneous$call (Object target, swarm.defobj.FCall call);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionForEach createActionForEach$message (Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native ActionForEachHomogeneous createActionForEachHomogeneous$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1, Object arg2);

/**
 * 
 */
public native ActionTo createActionTo$message (Object target, swarm.Selector aSel, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native FAction createFAction (swarm.defobj.FCall call);

/**
 * 
 */
public native swarm.defobj.Symbol getDefaultOrder ();

/**
 * 
 */
public native boolean getAutoDrop ();

/**
 *  The activateIn: message is used to initialize a process for executing the actions of an ActionType.  This process is controlled by an object called an Activity.  The activateIn message initializes an activity to run under the execution context passed as the swarmContext argument, and return the activity object just created.  If the execution context is nil, an activity is returned that allows complete execution control by the caller.  Otherwise, the execution context must be either an instance of SwarmProcess or SwarmActivity.  (These objects are always maintained in one-to-one association with each other, either one of the pair is equivalent to the other as a swarmContext argument.) If a top-level activity is created (swarmContext is nil), the created activity may be processed using activity processing commands such as run, step, etc.  If an activity is created to run under a swarm context, the swarm itself has responsibility for advancing the subactivity according to its requirements for synchronization and control among all its activities.  Activating a plan for execution under a swarm turns over control to the swarm to execute the subactivity as a more-or-less autonomous activity.
 */
public native Activity activateIn (swarm.objectbase.Swarm swarmContext);

/**
 * 
 */
public native void updateArchiver (swarm.defobj.Archiver archiver);

/**
 *  Output a deep HDF5 representation of object state to a stream.
 */
public native void hdf5OutDeep (swarm.defobj.HDF5 hdf5obj);

/**
 *  Output a shallow HDF5 representation of object state to a stream.
 */
public native void hdf5OutShallow (swarm.defobj.HDF5 hdf5obj);

/**
 *  On the given stream, save a double valued variable called "aName" which has value "val".
 */
public native void lispSaveStream$Double$Value (Object stream, java.lang.String aName, double val);

/**
 *  On the given stream, save a float valued variable called "aName" which has value "val".
 */
public native void lispSaveStream$Float$Value (Object stream, java.lang.String aName, double val);

/**
 *  On the given stream, save an unsigned long long variable called "aName" which has value "val".
 */
public native void lispSaveStream$UnsignedLongLong$Value (Object stream, java.lang.String aName, long val);

/**
 *  On the given stream, save a long long variable called "aName" which has value "val".
 */
public native void lispSaveStream$LongLong$Value (Object stream, java.lang.String aName, long val);

/**
 *  On the given stream, save an unsigned long variable called "aName" which has value "val".
 */
public native void lispSaveStream$UnsignedLong$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save a long variables called "aName" which has value "val".
 */
public native void lispSaveStream$Long$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save an unsigned integer variable called "aName" which has value "val".
 */
public native void lispSaveStream$Unsigned$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save an integer variable called "aName" which has value "val".
 */
public native void lispSaveStream$Integer$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save an unsigned short integer variable called "aName" which has value "val".
 */
public native void lispSaveStream$UnsignedShort$Value (Object stream, java.lang.String aName, short val);

/**
 *  On the given stream, save a short integer variable called "aName" which has value "val".
 */
public native void lispSaveStream$Short$Value (Object stream, java.lang.String aName, short val);

/**
 *  On the given stream, save a character variable called "aName" which has value "val".
 */
public native void lispSaveStream$Char$Value (Object stream, java.lang.String aName, char val);

/**
 *  On the given stream, save a Boolean variable called "aName"  which has value "val". Explanation:  The Swarm lisp serialization approach assumes that objects have lispOutDeep: and lispOutShallow: methods which indicate which variables are supposed to be saved.  If an object is  subclassed from SwarmObject, there are default lispOutDeep:  and lispOutShallow: methods. Those methods employ on the method, lispOutVars:deep:, which is the "default" approach to try to save all variables, either deep or shallow.  Sometimes one needs to selectively list particular instance variables to be saved. This is necessary, for example, if one wants to save a Swarm itself, because the usage of lispOutVars: will result in  a variable "activity" being saved as nil, and so when the saved values are read back in, the "activity" variable will be erased and nil will appear in its place.   Here is an example of how a subclass called "BFagent"  might override lispOutDeep: to customize  the selection of variables to be saved.  Note that the same could be used to override lispOutShallow:.  The key thing to remember is that when one tries to do a deep save on a high level object, such as a Swarm, then the Swarm libraries will try to track from top to bottom, finding all collections and objects, and all objects and collections inside them, and so forth, and each will be told to execute its lispOutDeep: method.  So all objects you want to save need a lispOutDeep: method, or else the default will try to save all variables.  If you omit some objects or variables from your lispOutDeep: method, then they will not appear in the saved file, which is what you want if you want to be sure that pre-existing interited values of variables are not obliterated  by bogus saved values.
 */
public native void lispSaveStream$Boolean$Value (Object stream, java.lang.String aName, int val);

/**
 *  Output just key/variable pairs, where variables are serialized  deep or shallow per deepFlag.
 */
public native void lispOutVars$deep (Object stream, boolean deepFlag);

/**
 *  Output a deep Lisp representation of object state to a stream.
 */
public native void lispOutDeep (Object stream);

/**
 *  Output a shallow Lisp representation of object state to a stream.
 */
public native void lispOutShallow (Object stream);

/**
 *  The containsKey: message returns true if the key value passed as its argument is contained in the collection, and false otherwise. 
 */
public native boolean containsKey (Object aKey);

/**
 *  The removeKey: message removes a member matching a key value from the collection, and returns the member just removed.  It returns nil if there is no key value in the collection which matches.  If more than one entry was present for the key value, it removes and returns the first member in the internal collection created for duplicate members.
 */
public native Object removeKey (Object aKey);

/**
 *  The at: message returns the existing member of the collection which matches the key value passed as its argument, or nil if there is no key value in the collection which matches.  If duplicate entries for this key exist, the entire collection of duplicate members created for the key value is returned instead.
 */
public native Object at (Object aKey);

/**
 * 
 */
public native Object createIndex$fromMember (swarm.defobj.Zone aZone, Object anObject);

/**
 * 
 */
public native void forEachKey (swarm.Selector aSelector);

/**
 * 
 */
public native void forEachKey (swarm.Selector aSelector, Object arg1);

/**
 * 
 */
public native void forEachKey (swarm.Selector aSelector, Object arg1, Object arg2);

/**
 * 
 */
public native void forEachKey (swarm.Selector aSelector, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
public native swarm.collections.PermutedIndex beginPermuted (swarm.defobj.Zone aZone);

/**
 *  The begin: message is the standard method for creating a new index for traversing the elements of a collection.  All further information about indexes is documented under the Index type.
 */
public native swarm.collections.Index begin (swarm.defobj.Zone aZone);

/**
 *  Returns YES if all members are of the same class.
 */
public native boolean allSameClass ();

/**
 *  Like removeAll:, but drops the member(s) as well.
 */
public native void deleteAll ();

/**
 *  The removeAll message removes all existing members of a collection and sets its member count to zero.  The collection then remains valid for further members to be added.  This message has no effect on the objects which might be referenced by any removed member values.  If resources consumed by these objects also need to be released, such release operations (such as drop messages) can be performed prior to removing the member values.
 */
public native void removeAll ();

/**
 *  The contains: message returns true if the collection contains any member value which matches the value passed as its argument. Depending on the collection subtype, this may require traversing sequentially through all members of the collection until a matching member is found.  For other subtypes, some form of direct indexing from the member value may be supported.  The message is supported regardless of its speed.
 */
public native boolean contains (Object aMember);

/**
 *  getCount returns the integer number of members currently contained in the collection.  All collections maintain their count internally so that no traversal of collection members is required simply to return this value.
 */
public native int getCount ();

/**
 * 
 */
public native boolean getReplaceOnly ();

/**
 *  The remove: message removes the first member in the collection with a value matching the value passed as its argument.  If there is no such member, a nil value is returned.  As with the contains: message, the speed of this operation may vary from very low to linear in the number of members, depending on the collection subtype.
 */
public native Object remove (Object aMember);

/**
 * 
 */
public native void describeForEachID (Object outputCharStream);

/**
 * 
 */
public native void describeForEach (Object outputCharStream);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1, Object arg2);

/**
 * 
 */
public native void forEach (swarm.Selector aSelector, Object arg1, Object arg2, Object arg3);

/**
 *  Equivalent to [aCollection atOffset: [aCollection getCount] - 1].
 */
public native Object getLast ();

/**
 *  Equivalent to [aCollection atOffset: 0].
 */
public native Object getFirst ();

/**
 *  Returns the member at a particular member offset.
 */
public native Object atOffset (int offset);

/**
 *  The atOffset: put: message replaces the member at a particular offset with a new value, and returns the previous member value at this offset.
 */
public native Object atOffset$put (int offset, Object anObject);

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The copy message creates a new object that has the same contents and resulting behavior as a starting object, except that an independent copy of the contents of the starting object is created so that further changes to one object do not affect the other.  The zone argument specifies the source of storage for the new object.  The message returns the id of the new object created.
 */
public native Object copy (swarm.defobj.Zone aZone);

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();

/**
 * 
 */
public native void setSingletonGroups (boolean singletonGroups);

/**
 * 
 */
public native void setConcurrentGroupType (Object groupType);

/**
 * 
 */
public native Object setRepeatInterval (int repeatInterval);

/**
 * 
 */
public native Object setRelativeTime (boolean relativeTime);

/**
 * 
 */
public native Object setDefaultOrder (swarm.defobj.Symbol aSymbol);

/**
 *  Load instance variables from an HDF5 object.
 */
public native Object hdf5In (swarm.defobj.HDF5 hdf5Obj);

/**
 *  Process an archived Lisp representation of object state from a list of instance variable name / value pairs.
 */
public native Object lispIn (Object expr);
public ScheduleImpl () {
  super ();
}

/**
 *  Convenience method for creating an AutoDrop Schedule
 */
public ScheduleImpl (swarm.defobj.Zone aZone, boolean autoDrop) { super (); new ScheduleCImpl (this).create$setAutoDrop (aZone, autoDrop); }

/**
 *  Convenience method for creating a repeating Schedule
 */
public ScheduleImpl (swarm.defobj.Zone aZone, int rptInterval) { super (); new ScheduleCImpl (this).create$setRepeatInterval (aZone, rptInterval); }

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public ScheduleImpl (swarm.defobj.Zone aZone) { super (); new ScheduleCImpl (this).create (aZone); }
}
