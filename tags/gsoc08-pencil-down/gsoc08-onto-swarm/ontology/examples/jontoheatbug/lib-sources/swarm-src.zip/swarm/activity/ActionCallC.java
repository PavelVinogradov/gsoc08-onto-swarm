package swarm.activity;

/**
 * <strong> An action defined by calling a C function.</strong>.

 An action defined by calling a C function.
 */
public interface ActionCallC extends ActionC, ActionS, ActionArgsC, ActionArgsS {
}
