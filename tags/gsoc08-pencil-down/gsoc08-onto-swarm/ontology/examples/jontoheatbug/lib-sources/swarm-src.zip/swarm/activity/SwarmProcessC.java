package swarm.activity;

/**
 * <strong> An object that holds a collection of concurrent subprocesses.</strong>.

 SwarmProcess inherits the messages of both ActionType and Zone. Inheritance of zone behavior means that a swarm can be used as the argument of a create: or createBegin: message, for creation of an object within the internal zone of a swarm. Unlike other action types, swarms and swarm activities always exist in a one-to-one relationship, provided that the swarm has been activated. This restriction to a single activity enables the swarm to do double-duty as a custom object that provides its own interface to the activities running within the swarm.
 */
public interface SwarmProcessC extends ActionTypeC, ActionTypeS, swarm.defobj.ZoneC, swarm.defobj.ZoneS, SynchronizationTypeC, SynchronizationTypeS {

/**
 *  The InternalZoneType option sets the type of zone which is created by the swarm to hold objects created within the swarm.  If set to nil, no internal zone is created within the swarm, and all use of the swarm as if it were a zone raises an error.  The default of this option is standard Zone type.  (.. Since there is no other Zone type yet, there's no reason to set this option yet except to turn off the internal zone. ..)
 */
Object setInternalZoneType (Object aZoneType);
}
