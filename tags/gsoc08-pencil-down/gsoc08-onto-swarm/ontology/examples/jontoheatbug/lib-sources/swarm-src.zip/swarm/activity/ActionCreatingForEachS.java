package swarm.activity;

/**
 * <strong> Send a message to every item in target, which is assumed to be a collection.</strong>.

 The createActionForEach: messages define a message to be sent in the same way as the createActionTo messages, but they assume that the object passed as the target argument is a collection object.  They specify that each object available from that collection, using the standard messages of the Collection type in the collections library, is to receive the specified message.
 */
public interface ActionCreatingForEachS  {
}
