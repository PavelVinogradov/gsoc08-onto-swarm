package swarm.objectbase;

/**
 * <strong> Protocol for configuration of Probes, ProbeMaps, and the ProbeLibrary.</strong>.

 Protocol for configuration of Probes, ProbeMaps, and the ProbeLibrary.
 */
public interface ProbeConfigC  {
}
