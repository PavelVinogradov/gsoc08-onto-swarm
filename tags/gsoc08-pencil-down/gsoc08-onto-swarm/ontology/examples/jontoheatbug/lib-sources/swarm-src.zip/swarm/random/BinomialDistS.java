package swarm.random;

/**
 * <strong> Binomial distribution</strong>.

 The binomial distribution gives the discrete probability  of obtaining exactly n successes out of N Bernoulli trials
 */
public interface BinomialDistS extends UnsignedDistributionS {

/**
 *  The setNumTrials only sets the numTrials parameter; the probability parameter is left unchanged from its previous or initialized value 
 */
Object setNumTrials (int aNumTrials);

/**
 *  The setNumTrials:setProbability sets both the number of trials rate  and the probability parameters.
 */
Object setNumTrials$setProbability (int aNumTrials, double aProbability);
}
