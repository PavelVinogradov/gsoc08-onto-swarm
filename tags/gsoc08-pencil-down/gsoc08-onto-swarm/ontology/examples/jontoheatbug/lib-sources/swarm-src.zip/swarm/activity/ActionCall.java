package swarm.activity;

/**
 * <strong> An action defined by calling a C function.</strong>.

 An action defined by calling a C function.
 */
public interface ActionCall extends Action, ActionS, ActionArgs, ActionArgsS {
}
