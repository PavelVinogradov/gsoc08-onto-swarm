package swarm.defobj;

/**
 * <strong> Protocol for creating HDF5 instances of the Archiver</strong>.

 Protocol for creating HDF5 instances of the Archiver Default system path is ~/swarmArchiver.hdf Default application path is <swarmdatadir>/<appname>/<appname>.hdf  or the current directory.
 */
public interface HDF5ArchiverC extends ArchiverC, ArchiverS {

/**
 *  Convenience method to create an HDF5Archiver from a specified path
 */
Object create$setPath (Zone aZone, java.lang.String path);
}
