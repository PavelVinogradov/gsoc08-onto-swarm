package swarm.defobj;

/**
 * <strong> Modular unit of storage allocation.</strong>.

 A zone is a source of storage for objects or other allocated data. Whenever a new object is created, a zone must be identified from which the storage for its instance variables, or other internal data, is obtained.  A program may establish multiple zones to ensure that objects with similar lifetime or storage needs are allocated together, and in general to optimize allocation and reuse of storage. Zones also maintain a collection of all objects allocated within the zone.  This collection, referred to as the "population" of a zone, is a set of all objects which have been created but not yet dropped within the zone.  Collections maintained automatically by zones can eliminate a need for other, separately maintained collections in applications that need to keep track of entire populations of objects. Collections of allocated objects can provide support for object query, external object storage, and automatic storage reclamation. A zone may be used to obtain storage not only for objects, but also for raw storage blocks like those provided by the C malloc function. All objects and storage blocks allocated in a zone remain local to that zone.  This means that allocation of storage in other zones does not affect the efficiency of storage allocation within a particular zone.  For most zone types, individual allocations may still be freed within a zone, and total storage of a zone may grow and shrink according to aggregate needs.  In addition to freeing individual allocations, an entire zone may also dropped.  Dropping a zone automatically frees all object allocations made within it, including final drop processing on any allocated objects that need it.  Release of an entire zone can be much faster than individual release of each object within it. The Zone type is a fully implemented type that provides default storage management support for objects and other allocated storage. It is also a supertype for other zones that implement alternative policies for use in specialized situations. A zone is created using standard create messages just like other objects.  This means that a zone must identify another zone from which it obtains its storage.  Storage is typically obtained from this other zone in large units called pages, which are then managed by the local zone to support internal allocations.  The getZone message of the DefinedObject type returns the zone which provides these base pages. Since a new zone always requires that an existing zone be identified, no new zones could be created unless there were some zones that already existed.  Two such zones are predefined as part of the defobj library: globalZone and scratchZone.
 */
public interface Zone extends Create, CreateS, Drop, DropS {

/**
 * 
 */
int getPageSize ();

/**
 *  allocIVars: allocates the instance variable structure for a new object.  The initial word of this structure is set to class id passed as its argument.  The class also determines the size of the structure allocated.  All remaining contents of this structure are initialized to binary zeroes.
 */
Object allocIVars (Class aClass);

/**
 *  copyIVars: creates copies an existing instance variable structure into a new allocation made within the local zone.  The existing instance variable structure may be in any zone, but must contain a class pointer in its first word that correctly describes the size of the structure.
 */
Object copyIVars (Object anObject);

/**
 *  freeIVars: releases storage that was previously allocated to hold the instance variable structure of an object.  The first word of the object must be a class pointer that correctly describes the size of the structure.  Storage allocated by allocIVars: or copyIVars: may be freed only by freeIVars:, and freeIVars: may be used only to free storage allocated by one of these messages.
 */
void freeIVars (Object anObject);

/**
 *  These messages allocate, copy, and free This message allocates the storage that holds the instance variables for an object.  It allocates the object as an internal component of the zone that is not included in the zone population.  It is used by classes that allocate additional objects as part of the implementation of another object, and that control the mapping of this storage separately from the zone level objects.
 */
Object allocIVarsComponent (Class aClass);

/**
 *  Like allocateIVarsComponent, except it copies the storage that holds the instances variables for an object.
 */
Object copyIVarsComponent (Object anObject);

/**
 *  Frees the instance variable storage for an object.
 */
void freeIVarsComponent (Object anObject);

/**
 *  Returns a specially qualified version of the zone that automatically allocates all its objects with the internal component qualification, even if allocated with allocIVars: or copyIVars:.  This qualified zone may be passed as an argument to a create: or createBegin: message so that it will create the new object as an internal component object.
 */
Object getComponentZone ();

/**
 *  getPopulation returns a collection all objects allocated in a zone using either allocIVars: or copyIVars: and not yet freed using freeIVars:.  getObjects returns nil if the ObjectCollection option is false.  The collection returned has the type OrderedSet as defined in the collections library, with the ReadOnly option set true and the IndexSafety option set to SafeAlways.  The members of this collection may change as objects are allocated and freed, but may not added or removed directly within the collection.
 */
swarm.collections.List getPopulation ();

/**
 *  Generate debug description for each member of the zone population.
 */
void describeForEach (Object outputCharStream);

/**
 *  Generate debug id description for each member of the zone population.
 */
void describeForEachID (Object outputCharStream);
}
