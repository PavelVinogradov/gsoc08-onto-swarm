package swarm.activity;

/**
 * <strong> The DefaultOrder option indicates the ordering to be assumed among actions of the plan when no other explicit ordering has been assigned.</strong>.

 The DefaultOrder option indicates the ordering to be assumed among actions of the plan when no other explicit ordering has been assigned. Beyond this initial ordering, additional ordering constraints can be added selectively using partial order specifications on individual actions.  (.. Partial order order constraints are not yet implemented.) The value for DefaultOrder is a symbol that may have one of the following values: Concurrent, Sequential, Randomized; The Concurrent value of the DefaultOrder option indicates that can actions be run in any order (including at the same time, if hardware and software to do this is available) without no impact on the net outcome of the actions.  The claim that action results are independent of their execution order gives the processing machinery explicit leeway to execute them in any order it chooses.  In the current implementation on a single, serial processor, actions are always processed sequentially even if marked concurrent, because that is the only way they can be.  In future versions, however, special runtime processing modes may be defined even for a serial processor, which would mix up execution order just to confirm the independence of model results. The Sequential value for the DefaultOrder option is the default.  It specifies that the actions must always be executed in the same order as they occur in the plan.  This order is ordinarily the same order in which actions are first created in the plan, unless actions are explicitly added elsewhere the collection that underlies a plan.  This option is always the safest to assure predictability of results, but it excludes the ability to run the actions in parallel.  To better understand and document a model design, it is worth annotating action plans with an explicit indication as to whether they do or do not depend on a Sequential order. The Randomized value for the DefaultOrder option specifies that the model results do depend on execution order, but that the order in which the actions were created or added has no special significance. Instead, the method of dealing with order dependence is to generate a random order each time a collection of same-time actions is processed. The random order will be generated from an random number generator internal to the processing machinery.
 */
public interface DefaultOrder  {

/**
 * 
 */
swarm.defobj.Symbol getDefaultOrder ();
}
