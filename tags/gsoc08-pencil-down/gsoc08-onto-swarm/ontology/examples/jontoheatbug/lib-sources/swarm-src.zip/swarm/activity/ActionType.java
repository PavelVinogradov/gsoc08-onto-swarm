package swarm.activity;

/**
 * <strong> Specification of an executable process.</strong>.

 An action type is a type of process that may be initiated as a unit of execution by an external request.  A typical action has a well-defined duration determined by a fixed set of actions that execute within it. Externally initiated interaction typically occurs only at the start or end of the overall process.  A typical action is executed in its entirety once an external request that initiates it has occurred. Some actions may also have internal events that cannot begin or complete until other actions from a containing environment have also begun or completed their execution.  Such ordering constraints can be defined either within an action type or as part of a dynamic context of execution. Executable actions include both actions compiled in a host language (such as C functions or Objective C messages) and compound actions built at runtime for interpretation by the Swarm abstract machine. (.. For now, the only subtype of ActionType is CompoundAction.  Types for compiled actions such as functions and messages have not been defined yet. ..)
 */
public interface ActionType  {

/**
 *  The activateIn: message is used to initialize a process for executing the actions of an ActionType.  This process is controlled by an object called an Activity.  The activateIn message initializes an activity to run under the execution context passed as the swarmContext argument, and return the activity object just created.  If the execution context is nil, an activity is returned that allows complete execution control by the caller.  Otherwise, the execution context must be either an instance of SwarmProcess or SwarmActivity.  (These objects are always maintained in one-to-one association with each other, either one of the pair is equivalent to the other as a swarmContext argument.) If a top-level activity is created (swarmContext is nil), the created activity may be processed using activity processing commands such as run, step, etc.  If an activity is created to run under a swarm context, the swarm itself has responsibility for advancing the subactivity according to its requirements for synchronization and control among all its activities.  Activating a plan for execution under a swarm turns over control to the swarm to execute the subactivity as a more-or-less autonomous activity.
 */
Activity activateIn (swarm.objectbase.Swarm swarmContext);
}
