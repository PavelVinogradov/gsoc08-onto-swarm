package swarm.collections;

/**
 * <strong> A class that represents a permutation of elements of a collection</strong>.

 Permutation is used to generate a permutation of elements of a a collection and store them in an array for fast access.  Permutation only mirrors the original collection. Updates of contents of Permutation will not reflect on the original collection.
 */
public interface Permutation extends Collection, CollectionS, swarm.defobj.Create, swarm.defobj.CreateS, Array, ArrayS {
}
