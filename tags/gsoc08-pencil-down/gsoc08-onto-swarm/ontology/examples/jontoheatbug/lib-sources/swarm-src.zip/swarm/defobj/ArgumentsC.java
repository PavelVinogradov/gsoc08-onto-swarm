package swarm.defobj;

/**
 * <strong> A class that provides customizable command line argument parsing support</strong>.

 A class that provides customizable command line argument parsing support
 */
public interface ArgumentsC extends CreateC, CreateS, DropC, DropS {

/**
 * 
 */
Object setArgc$Argv (int count, java.lang.String[] theArgv);

/**
 * 
 */
Object setAppName (java.lang.String appName);

/**
 * 
 */
Object setAppModeString (java.lang.String appModeString);

/**
 * 
 */
Object setBugAddress (java.lang.String bugAddress);

/**
 * 
 */
Object setVersion (java.lang.String version);

/**
 *  Takes an option specification that includes the following information: - The name of the option specification - The key of the option.  This an integer that, if printiable, is   the single-character use of the option.  For example, `-p'    vs. `--protocol' are the different versions of the same thing.   One is intended to be mnemonic, the other convenient. - If non-NULL, an argument label that says that the option   requires an argument (in this case, the protocol name). - Flags that change the visibility and parsing of the option  - Documentation for the option - A sorting integer; relative placement of the option in the help   screen.
 */
void addOption$key$arg$flags$doc$group (java.lang.String name, int key, java.lang.String arg, int flags, java.lang.String doc, int group);

/**
 *  This method is called for each option that occurs.
 */
int parseKey$arg (int key, java.lang.String arg);
}
