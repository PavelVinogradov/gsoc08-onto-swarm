package swarm.objectbase;

/**
 * <strong> A class that allows the user to inspect a given variable in any candidate that is an instance of, or inherits from, a given class.</strong>.

 This is a specialized subclass of the abstract class Probe. It completes the specification of a probe that refers to an instance variable element of an object. 
 */
public interface VarProbeC extends ProbeC, ProbeS {

/**
 *  The setProbedVariable: sets the variable being probed. The aVariable identifier is simply a character string consisting of the identifier of the variable referent. This method must be called during the create phase. 
 */
Object setProbedVariable (java.lang.String aVariable);
}
