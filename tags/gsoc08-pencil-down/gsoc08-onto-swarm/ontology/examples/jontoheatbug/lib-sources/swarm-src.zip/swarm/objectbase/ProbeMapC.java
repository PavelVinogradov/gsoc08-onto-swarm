package swarm.objectbase;

/**
 * <strong> A container class for Probes used to specify the contents of a  ProbeDisplay.</strong>.

 A ProbeMap is a Map-type collection of Probes. They are used to gather  several Probes, who usually have a common referent, into a single bundle. For example, all the instance variables of a ModelSwarm might be  gathered into a single ProbeMap. Each ProbeMap is then installed into the global ProbeLibrary. 
 */
public interface ProbeMapC extends SwarmObjectC, SwarmObjectS, ProbeConfigC, ProbeConfigS {

/**
 *  The setProbedClass: method sets the class of the object that the set of  probes that constitute the probe map points at. This message must be sent  before createEnd. 
 */
Object setProbedClass (Class class_);

/**
 * 
 */
Object setProbedObject (Object object);
}
