package swarm.collections;

/**
 * <strong> Character string object (later to support collection behavior).</strong>.

 The String object type packages a null-terminated, C-format character string into an object.  All memory allocation needed to hold the string value is handled by the object.  This type currently defines only the most rudimentary operations for initializing and appending C-format character strings.  These are sufficient for its current limited roles in places that need a uniformity between character strings and other kinds of allocated objects.
 */
public interface StringC extends swarm.defobj.CreateC, swarm.defobj.CreateS, swarm.defobj.DropC, swarm.defobj.DropS, swarm.defobj.CopyC, swarm.defobj.CopyS {

/**
 * 
 */
Object create$setC (swarm.defobj.Zone aZone, java.lang.String cstring);
}
