package swarm.activity;

/**
 * <strong> Specifies that time is relative to when the schedule started.</strong>.

 The RelativeTime option specifies that all the times in the schedule are relative to the time when processing of the entire schedule begins.  Otherwise, the times are assumed to be absolute times, with their base in the starting time of the entire model.
 */
public interface RelativeTime  {

/**
 * 
 */
boolean getRelativeTime ();
}
