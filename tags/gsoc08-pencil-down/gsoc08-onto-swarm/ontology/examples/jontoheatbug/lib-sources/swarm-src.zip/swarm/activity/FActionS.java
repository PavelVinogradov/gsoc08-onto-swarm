package swarm.activity;

/**
 * <strong> An action defined by sending a FCall.</strong>.

 An action defined by sending a FCall.
 */
public interface FActionS extends ActionS {

/**
 * 
 */
Object setAutoDrop (boolean autoDrop);
}
