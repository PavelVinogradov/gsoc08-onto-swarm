package swarm.activity;

/**
 * <strong> State of execution within a Schedule.</strong>.

 State of execution within a Schedule.
 */
public interface ScheduleActivity extends Activity, ActivityS {

/**
 *  Get current time of activity (pending time if holding).
 */
int getCurrentTime ();

/**
 *  Advance activity until requested time has been reached.
 */
Object stepUntil (int tVal);
}
