package swarm.defobj;

/**
 * <strong> Object serialization protocol.</strong>.

 Object serialization protocol.
 */
public interface SerializationS  {

/**
 *  Process an archived Lisp representation of object state from a list of instance variable name / value pairs.
 */
Object lispIn (Object expr);

/**
 *  Load instance variables from an HDF5 object.
 */
Object hdf5In (HDF5 hdf5Obj);
}
