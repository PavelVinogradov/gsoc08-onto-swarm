package swarm.defobj;

/**
 * <strong> Class with variables and/or methods defined at runtime.</strong>.

 Class with variables and/or methods defined at runtime.
 */
public interface CreatedClass extends Create, CreateS, DefinedClass, DefinedClassS {

/**
 * 
 */
Object getDefiningClass ();
}
