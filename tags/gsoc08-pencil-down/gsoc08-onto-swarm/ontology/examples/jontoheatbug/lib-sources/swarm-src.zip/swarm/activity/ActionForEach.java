package swarm.activity;

/**
 * <strong> An action defined by sending a message to every member of a collection.</strong>.

 An action defined by sending a message to every member of a collection.
 */
public interface ActionForEach extends ActionTo, ActionToS, DefaultOrder, DefaultOrderS {
}
