package swarm.activity;

/**
 * <strong> An action defined by sending an Objective C message.</strong>.

 An action defined by sending an Objective C message.
 */
public interface ActionToS extends ActionS, ActionTargetS, ActionSelectorS, ActionArgsS {
}
