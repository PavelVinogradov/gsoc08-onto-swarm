package swarm.collections;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Collection supporting access only by relative position.</strong>.

 An array is a collection of members that are all created as members of the collection at the same time.  Existing member values may be replaced with new values, but the members themselves are fixed at constant offsets within the collection.  The fixed structure of an array permits very fast access to members by integer offset positions, since the location of each member may be directly calculated. The Array type is one of the simplest collection types in the collections library, and the closest to a data structure directly supported in C.  Unlike C arrays, the group of members belonging to the array is not necessarily fixed for the lifetime of the array, but may be dynamically resized to contain a different number of members. When an array is dynamically resized, existing member values are preserved as much as possible. The Array type adds few messages to the generic messages inherited from Collection.  This type is provided partly so that a fixed-structure array can be accessed with the same uniform set of basic messages as any other kind of object collection.  It also handles all required memory allocation within the collection.  As an option, however, the Array type can be used to wrap an existing C array for external access as an object collection.  It can also provide access to an internal C array for direct manipulation using C expressions.  These forms of low-level access support hybrid modes of use in which advantages of both low-level manipulation and external object access can be combined. The Array type is directly creatable, and supports all standard messages of Collection except removal of individual members.  The messages based on an integer offset, either on the collection (atOffset:, atOffset:put:), or an index (setOffset:) all execute in fast constant time.  Members of an array are fully ordered according to these integer offsets.  Sequential access to members through its members is also fully supported.  The Array type disables the remove message inherited from Collection; the message is defined, but any attempt to remove a member will raise an error that the operation is not supported. The default value of the ReplaceOnly option is true, and cannot be overridden. The type of index returned by begin: on an array is simply Index. There is no special index type for Array because there are no additional messages beyond those already defined by Index. All the Array create-time options can also be set after the array is already created, subject to restrictions noted below.
 */
public class ArrayCImpl extends swarm.PhaseCImpl implements CollectionC, CollectionS, DefaultMemberC, DefaultMemberS, MemberBlockC, MemberBlockS, swarm.defobj.SerializationC, swarm.defobj.SerializationS, ArrayS, ArrayC {

/**
 * 
 */
public native Object create$setCount (swarm.defobj.Zone aZone, int count);

/**
 *  Process HDF5 object to set create-time parameters.
 */
public native Object hdf5InCreate (swarm.defobj.HDF5 hdf5Obj);

/**
 *  Process keyword parameters in expression in order to get  create-time parameters.
 */
public native Object lispInCreate (Object expr);

/**
 * 
 */
public native void setIndexFromMemberLoc (int byteOffset);

/**
 *  This boolean-valued option restricts valid usage of a collection by excluding all operations which add or remove members.  For some collection subtypes, a replace-only restriction can obtain many of the same performance advantages as a read-only collection, but without disabling replace operations as well.  Just like the ReadOnly option, the ReplaceOnly option may be reset after a collection is created, provided it was not originally set to true.
 */
public native void setReplaceOnly (boolean replaceOnly);

/**
 *  The setInitialValue: message requires another object as its argument, from which the value of a newly created object is to be taken.  Unlike a copy message, the object used as the source of the new value need not have the identical type as the new object to be created.  A particular object type defines the types of initial value objects which it can accept, along with any special conversion or interpretation it might apply to such a value.
 */
public native void setInitialValue (Object initialValue);

/**
 *  The createEnd message completes the process of specifying available options for an object being created.  Typically it validates that requested options are valid and consistent with one another, and raises an error if they are not.  The standard, predefined error InvalidCombination may be raised by createEnd to indicate an invalid combination of requests, or other, more specific forms of error handling may be used. If all requests received since the initial createBegin: are valid, both individually and in combination with each other, then createEnd determines a finalized form of object that satisfies all requests received and then returns this object.  Any additional storage required for the finalized object is taken from the same zone originally passed to createBegin.  The object may have whatever implementation is selected to best satisfy a particular request. Different requests may result in entirely different implementations being returned.  The only guarantee is that a returned object supports the messages defined for further use of the finalized object.  If a type was defined by a @protocol declaration, these messages are those appearing in either the SETTING or USING sections. On return from createEnd, the id of the interim object returned by createBegin: is no longer guaranteed to be valid for further use, and should no longer be referenced.  A variable which holds this such an id can be reassigned the new id returned by createEnd, so that the same variable holds successive versions of the object being created.
 */
public native Object createEnd ();

/**
 *  createBegin: returns an interim object intended only for receiving create-time messages.  If a type was defined by a @protocol declaration, these messages are those appearing in either the CREATING or SETTING sections.  Otherwise, the messages valid as create-time messages are defined by the type without any specific syntactic marker.
 */
public native Object createBegin (swarm.defobj.Zone aZone);

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public native Object create (swarm.defobj.Zone aZone);

/**
 *  The customizeCopy: message creates a new copy of the interim object returned by customizeBegin: which may be used for further customizations that do not affect the customization already in progress.  It may be used to branch off a path of a customization in progress to create an alternate final customization.  customizeCopy may be used only on an interim object returned by customizeBegin: and not yet finalized by customizeEnd.  The new version of the interim object being customized may be allocated in the same or different zone as the original version, using the zone argument required by customizeCopy:
 */
public native Object customizeCopy (Object aZone);

/**
 *  Returns the new, customized version of the original type.
 */
public native Object customizeEnd ();

/**
 *  Returns an interim value for receiving create-time messages much like createBegin:. The zone passed to customizeBegin: is the same zone from which storage for the new, finalized type object will be taken.  This zone need not be the same as any instance later created from that type, since a new zone argument is still passed in any subsequent create message on that type.
 */
public native Object customizeBegin (Object aZone);

/**
 *  The Count option sets the number of members which belong to the collection.  Any non-negative value including zero is valid.  If the array already exists, the any existing members up to the new count will preserve their existing values.  If the new count is greater than the existing count, or a new array is being created, all members will be assigned an initial default value of either nil, or a value previously specified for DefaultMember.
 */
public native Object setCount (int count);

/**
 *  Load instance variables from an HDF5 object.
 */
public native Object hdf5In (swarm.defobj.HDF5 hdf5Obj);

/**
 *  Process an archived Lisp representation of object state from a list of instance variable name / value pairs.
 */
public native Object lispIn (Object expr);

/**
 * 
 */
public native void setDefaultMember (Object memberValue);
public ArrayCImpl (Array nextPhase) { super (); this.nextPhase = nextPhase; }
public ArrayCImpl () {super ();}
}
