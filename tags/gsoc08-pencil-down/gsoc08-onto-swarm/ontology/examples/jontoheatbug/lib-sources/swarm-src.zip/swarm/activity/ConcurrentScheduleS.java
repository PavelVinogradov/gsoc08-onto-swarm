package swarm.activity;

/**
 * <strong> Time-based map usable for concurrent group.</strong>.

 Time-based map usable for concurrent group.
 */
public interface ConcurrentScheduleS extends ConcurrentGroupS, ScheduleS {
}
