package swarm.activity;

/**
 * <strong> A collection of actions under total or partial order constraints.</strong>.

 An action group is an action plan whose basic representation is a sequence of actions that have been created within it.  An action group inherits its underlying representation from the OrderedSet type of the collections library.  All the members of the ordered set must consist only of actions that are created by one of the createAction messages defined on ActionGroup itself.  Once the actions are created, they may be accessed or traversed using standard messages of the OrderedSet type.  The action objects are an integral, controlled component of the action plan in which they are created.  If they are removed from the action plan collection using a remove message, the only collection in which they may be reinserted is the same collection from which they came. It is permissible, however, to modify the base representation sequence by removing from one position and reinserting at another.
 */
public interface ActionGroupC extends CompoundActionC, CompoundActionS, ActionCreatingC, ActionCreatingS, DefaultOrderC, DefaultOrderS {
}
