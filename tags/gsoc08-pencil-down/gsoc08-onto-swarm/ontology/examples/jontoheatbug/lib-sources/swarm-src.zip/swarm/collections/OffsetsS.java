package swarm.collections;

/**
 * <strong> Methods for accessing collection members by position.</strong>.

 An offset is an integer value that gives relative position of a member in the enumeration sequence of a collection.  Offsets start the count of the first member at zero, just like C array indexing. Offsets provide an alternate means to access the members of a collection, without creating a separate index object.  Some collection subtypes (such as Array) support fast, direct access by integer member offset, while others support member offsets only as a shorthand for sequential access through every preceding member.  Access by offsets is supported on all collections regardless of whether its speed on a particular collection type. atOffset: and atOffset:put: raise the error OffsetOutOfRange if the offset is greater than or equal to the count of members in the collection.
 */
public interface OffsetsS  {
}
