package swarm.activity;

/**
 * <strong> Specify that an action is dropped after being processed.</strong>.

 The AutoDrop option specifies that as soon as any action been processed by a running activity, the action is removed from the plan and dropped so that it will never appear again.  This option is useful for plans that are created for a one-time use, never to be used again. This option is especially useful for a dynamic schedule that continually receives new actions to be executed at future times, but will never repeat actions that were previously scheduled.  Depending on the underlying implementation of the schedule, making sure the old actions get dropped using AutoDrop can considerably improve the performance of the schedule. When an option like AutoDrop is used, or whenever the contents of an action plan undergo a significant amount of dynamic update, the action plan would ordinarily be intended only for a single point of use.  If AutoDrop is specified, a restriction against multiple active references is enforced.  An error will be raised if two activities ever attempt to process a plan with AutoDrop enabled at the same time.
 */
public interface AutoDropS  {
}
