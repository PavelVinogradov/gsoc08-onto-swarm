package swarm.random;

/**
 * <strong> Bernoulli Distribution </strong>.

 A distribution returning YES with a given probability.
 */
public interface BernoulliDist extends BooleanDistribution, BooleanDistributionS {

/**
 *  The getProbability method returns the probability of returning YES.
 */
double getProbability ();

/**
 *  The getSampleWithProbability: returns a sample YES or NO value.
 */
boolean getSampleWithProbability (double p);
}
