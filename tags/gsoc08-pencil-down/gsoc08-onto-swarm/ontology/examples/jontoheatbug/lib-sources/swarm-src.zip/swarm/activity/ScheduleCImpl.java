package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A collection of actions ordered by time values.</strong>.

 A schedule is compound action whose basic representation is a sorted Map of actions that have been created within it.  The key value associated with each of these actions is an unsigned integer value for which the typedef timeval_t is supplied. A schedule inherits its underlying representation from the Map type of the collections library.  All the members of the ordered set must consist only of actions that are created by one of the createAction messages defined on Schedule itself.  Once the actions are created, they may be accessed or traversed using standard messages of the Map type.  The key values of this collection, however, must be cast to and from the id type defined for key values by the Map type.  The messages to create actions within a schedule are essentially the same as those for ActionGroup, except for the presence of an initial at: argument indicating the time at which an action is to be performed.  Except for the time associated with each action, meaning of the createAction messages is the same as for ActionGroup. When multiple actions are all scheduled at the same time, they are all inserted into a concurrent action group created for that time value. The ConcurrentGroupType option may be used to override the default action group for these concurrent actions by a custom user-defined subclass.  (.. Details of doing this are not yet documented, but there are examples.)
 */
public class ScheduleCImpl extends swarm.PhaseCImpl implements swarm.collections.MapC, swarm.collections.MapS, CompoundActionC, CompoundActionS, ActionCreatingC, ActionCreatingS, RelativeTimeC, RelativeTimeS, RepeatIntervalC, RepeatIntervalS, ConcurrentGroupTypeC, ConcurrentGroupTypeS, SingletonGroupsC, SingletonGroupsS, ScheduleS, ScheduleC {

/**
 *  Indicate whether an empty schedule should be dropped and ignored or or kept and attended to (default is YES).
 */
public native Object setKeepEmptyFlag (boolean keepEmptyFlag);

/**
 *  Convenience method for creating an AutoDrop Schedule
 */
public native Object create$setAutoDrop (swarm.defobj.Zone aZone, boolean autoDrop);

/**
 *  Convenience method for creating a repeating Schedule
 */
public native Object create$setRepeatInterval (swarm.defobj.Zone aZone, int rptInterval);

/**
 * 
 */
public native Object setAutoDrop (boolean autoDrop);

/**
 *  Process HDF5 object to set create-time parameters.
 */
public native Object hdf5InCreate (swarm.defobj.HDF5 hdf5Obj);

/**
 *  Process keyword parameters in expression in order to get  create-time parameters.
 */
public native Object lispInCreate (Object expr);

/**
 * 
 */
public native Object setCompareUnsignedIntegers ();

/**
 * 
 */
public native Object setCompareIntegers ();

/**
 * 
 */
public native Object setCompareIDs ();

/**
 * 
 */
public native Object setCompareCStrings ();

/**
 * 
 */
public native void setIndexFromMemberLoc (int byteOffset);

/**
 *  This boolean-valued option restricts valid usage of a collection by excluding all operations which add or remove members.  For some collection subtypes, a replace-only restriction can obtain many of the same performance advantages as a read-only collection, but without disabling replace operations as well.  Just like the ReadOnly option, the ReplaceOnly option may be reset after a collection is created, provided it was not originally set to true.
 */
public native void setReplaceOnly (boolean replaceOnly);

/**
 *  The setInitialValue: message requires another object as its argument, from which the value of a newly created object is to be taken.  Unlike a copy message, the object used as the source of the new value need not have the identical type as the new object to be created.  A particular object type defines the types of initial value objects which it can accept, along with any special conversion or interpretation it might apply to such a value.
 */
public native void setInitialValue (Object initialValue);

/**
 *  The createEnd message completes the process of specifying available options for an object being created.  Typically it validates that requested options are valid and consistent with one another, and raises an error if they are not.  The standard, predefined error InvalidCombination may be raised by createEnd to indicate an invalid combination of requests, or other, more specific forms of error handling may be used. If all requests received since the initial createBegin: are valid, both individually and in combination with each other, then createEnd determines a finalized form of object that satisfies all requests received and then returns this object.  Any additional storage required for the finalized object is taken from the same zone originally passed to createBegin.  The object may have whatever implementation is selected to best satisfy a particular request. Different requests may result in entirely different implementations being returned.  The only guarantee is that a returned object supports the messages defined for further use of the finalized object.  If a type was defined by a @protocol declaration, these messages are those appearing in either the SETTING or USING sections. On return from createEnd, the id of the interim object returned by createBegin: is no longer guaranteed to be valid for further use, and should no longer be referenced.  A variable which holds this such an id can be reassigned the new id returned by createEnd, so that the same variable holds successive versions of the object being created.
 */
public native Object createEnd ();

/**
 *  createBegin: returns an interim object intended only for receiving create-time messages.  If a type was defined by a @protocol declaration, these messages are those appearing in either the CREATING or SETTING sections.  Otherwise, the messages valid as create-time messages are defined by the type without any specific syntactic marker.
 */
public native Object createBegin (swarm.defobj.Zone aZone);

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public native Object create (swarm.defobj.Zone aZone);

/**
 *  The customizeCopy: message creates a new copy of the interim object returned by customizeBegin: which may be used for further customizations that do not affect the customization already in progress.  It may be used to branch off a path of a customization in progress to create an alternate final customization.  customizeCopy may be used only on an interim object returned by customizeBegin: and not yet finalized by customizeEnd.  The new version of the interim object being customized may be allocated in the same or different zone as the original version, using the zone argument required by customizeCopy:
 */
public native Object customizeCopy (Object aZone);

/**
 *  Returns the new, customized version of the original type.
 */
public native Object customizeEnd ();

/**
 *  Returns an interim value for receiving create-time messages much like createBegin:. The zone passed to customizeBegin: is the same zone from which storage for the new, finalized type object will be taken.  This zone need not be the same as any instance later created from that type, since a new zone argument is still passed in any subsequent create message on that type.
 */
public native Object customizeBegin (Object aZone);

/**
 * 
 */
public native void setSingletonGroups (boolean singletonGroups);

/**
 * 
 */
public native void setConcurrentGroupType (Object groupType);

/**
 * 
 */
public native Object setRepeatInterval (int repeatInterval);

/**
 * 
 */
public native Object setRelativeTime (boolean relativeTime);

/**
 * 
 */
public native Object setDefaultOrder (swarm.defobj.Symbol aSymbol);

/**
 *  Load instance variables from an HDF5 object.
 */
public native Object hdf5In (swarm.defobj.HDF5 hdf5Obj);

/**
 *  Process an archived Lisp representation of object state from a list of instance variable name / value pairs.
 */
public native Object lispIn (Object expr);
public ScheduleCImpl (Schedule nextPhase) { super (); this.nextPhase = nextPhase; }
public ScheduleCImpl () {super ();}
}
