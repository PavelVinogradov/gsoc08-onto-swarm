package swarm.collections;

/**
 * <strong> Allocation in member/key for fast setMember:/setKey:</strong>.

 The MemberSlot option indicates that space has been reserved within each member that allows it to contain a link directly to its position in the enumeration for a collection.  If such space has been reserved, special messages can be used that rapidly position an index directly to the member.  Operations to remove members are also much faster. The value of MemberSlot specifies the offset in bytes from the start of each member where the space for its position link has been reserved.   The offset of the position link from the start of a member may be either positive or negative, in the range of -2048 to +2047.  The default value of MemberSlot is UnknownOffset (a large negative value), which specifies that no slot for an internal position link is available within each member.
 */
public interface MemberSlotS  {
}
