package swarm.activity;

/**
 * <strong> A collection of actions to be performed in any order consistent with a set of ordering constraints.</strong>.

 An compound action is the supertype of ActionGroup and Schedule.  A compound action defines an executable process that is composed from the execution of a set of actions in some defined order. CompoundAction is not directly creatable.  One of its subtypes must be created instead.  ActionPlan inherits the basic ability to be activated for execution from ActionType.
 */
public interface CompoundActionC extends ActionTypeC, ActionTypeS, swarm.collections.CollectionC, swarm.collections.CollectionS, AutoDropC, AutoDropS, DefaultOrderC, DefaultOrderS {
}
