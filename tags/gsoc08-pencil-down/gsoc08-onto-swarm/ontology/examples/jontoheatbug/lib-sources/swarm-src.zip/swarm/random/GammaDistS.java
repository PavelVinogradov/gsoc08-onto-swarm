package swarm.random;

/**
 * <strong> Gamma distribution</strong>.

 A well-known continuous probability distribution returning doubles
 */
public interface GammaDistS extends DoubleDistributionS {

/**
 *  The setAlpha:setBeta: method sets the alpha and beta values for the gamma distribution.
 */
Object setAlpha$setBeta (double alpha, double beta);
}
