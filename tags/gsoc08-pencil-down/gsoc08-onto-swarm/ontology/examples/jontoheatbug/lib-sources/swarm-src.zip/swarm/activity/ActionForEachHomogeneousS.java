package swarm.activity;

/**
 * <strong> Like ActionForEach, except that the collection must be homogeneous.</strong>.

 Like ActionForEach, except that the collection must be homogeneous.
 */
public interface ActionForEachHomogeneousS extends ActionS, ActionTargetS, ActionSelectorS, DefaultOrderS {
}
