package swarm.defobj;

/**
 * <strong> HDF5 interface</strong>.

 HDF5 interface
 */
public interface HDF5C extends CreateC, CreateS, DropC, DropS {

/**
 * 
 */
Object setWriteFlag (boolean writeFlag);

/**
 * 
 */
Object setDatasetFlag (boolean datasetFlag);

/**
 * 
 */
Object setExtensibleDoubleVector ();

/**
 * 
 */
Object setParent (Object parent);

/**
 * 
 */
Object setCompoundType (Object compoundType);

/**
 * 
 */
Object setCount (int count);
}
