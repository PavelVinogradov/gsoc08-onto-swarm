package swarm.objectbase;

/**
 * <strong> A subclass of ProbeMap, whose initial state is empty unlike the default probeMap initial state which contains all the VarProbes of the requested target class.</strong>.

 This subclass of the ProbeMap is used to create probe maps which are  initialised in an emtpy state or with the VarProbes and MessageProbes  intended. In other words, the probed class is set, as is the case with  the normal ProbeMap class but upon createEnd no VarProbes or  MessageProbes will be present within it. This feature is useful when  creating a probe map from scratch (e.g. to be used in conjunction with  the setProbeMap:For: message of the ProbeLibrary). 
 */
public interface CustomProbeMapS extends ProbeMapS {
}
