package swarm.random;

/**
 * <strong> Log-Normal distribution</strong>.

  A well-known continuous probability distribution returning doubles.
 */
public interface LogNormalDistC extends NormalC, NormalS {
}
