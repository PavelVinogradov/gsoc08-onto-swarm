package swarm;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Container object for Swarm globals</strong>.

 Container object for Swarm globals
 */
public class SwarmEnvironmentCImpl extends swarm.PhaseCImpl implements SwarmEnvironmentS, SwarmEnvironmentC {

/**
 * 
 */
public native Object initSwarm$version$bugAddress$argCount$args (java.lang.String appName, java.lang.String version, java.lang.String bugAddress, int count, java.lang.String[] args);

/**
 * 
 */
public native Object createEnd ();

/**
 * 
 */
public native Object setBatchMode (boolean batchMode);

/**
 * 
 */
public native Object setArguments (swarm.defobj.Arguments arguments);

/**
 * 
 */
public native Object createBegin ();
public SwarmEnvironmentCImpl (SwarmEnvironment nextPhase) { super (); this.nextPhase = nextPhase; }
public SwarmEnvironmentCImpl () {super ();}
}
