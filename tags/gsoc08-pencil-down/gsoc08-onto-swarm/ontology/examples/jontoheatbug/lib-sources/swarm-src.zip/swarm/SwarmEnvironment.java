package swarm;

/**
 * <strong> Container object for Swarm globals</strong>.

 Container object for Swarm globals
 */
public interface SwarmEnvironment  {

/**
 * 
 */
void initSwarm (java.lang.String appName, java.lang.String version, java.lang.String bugAddress, java.lang.String[] args);

/**
 * 
 */
int getCurrentTime ();

/**
 * 
 */
swarm.activity.SwarmActivity getCurrentSwarmActivity ();

/**
 * 
 */
void createProbeDisplay (Object obj);

/**
 * 
 */
void createCompleteProbeDisplay (Object obj);

/**
 * 
 */
void createArchivedProbeDisplay (Object obj, java.lang.String name);

/**
 * 
 */
void createArchivedCompleteProbeDisplay$name (Object obj, java.lang.String name);

/**
 * 
 */
void setWindowGeometryRecordName (Object obj, java.lang.String name);

/**
 * 
 */
void setComponentWindowGeometryRecordNameFor$widget$name (Object obj, Object widget, Object name);

/**
 * 
 */
void setComponentWindowGeometryRecordName$name (Object widget, Object name);

/**
 * 
 */
void xprint (Object obj);

/**
 * 
 */
void xfprint (Object obj);

/**
 * 
 */
void dumpDirectory ();

/**
 * 
 */
java.lang.String typeModule (java.lang.String typeName);

/**
 * 
 */
void verboseMessage (java.lang.String message);

/**
 * 
 */
void updateDisplay ();

/**
 * 
 */
swarm.defobj.Arguments getArguments ();

/**
 * 
 */
swarm.defobj.Symbol getStart ();

/**
 * 
 */
swarm.defobj.Symbol getMember ();

/**
 * 
 */
swarm.defobj.Symbol getEnd ();

/**
 * 
 */
swarm.defobj.Symbol getInitialized ();

/**
 * 
 */
swarm.defobj.Symbol getRunning ();

/**
 * 
 */
swarm.defobj.Symbol getStopped ();

/**
 * 
 */
swarm.defobj.Symbol getHolding ();

/**
 * 
 */
swarm.defobj.Symbol getReleased ();

/**
 * 
 */
swarm.defobj.Symbol getTerminated ();

/**
 * 
 */
swarm.defobj.Symbol getCompleted ();

/**
 * 
 */
swarm.defobj.Symbol getRandomized ();

/**
 * 
 */
swarm.defobj.Symbol getSequential ();

/**
 * 
 */
swarm.defobj.Symbol getControlStateRunning ();

/**
 * 
 */
swarm.defobj.Symbol getControlStateStopped ();

/**
 * 
 */
swarm.defobj.Symbol getControlStateStepping ();

/**
 * 
 */
swarm.defobj.Symbol getControlStateQuit ();

/**
 * 
 */
swarm.defobj.Symbol getControlStateNextTime ();

/**
 * 
 */
swarm.defobj.Zone getScratchZone ();

/**
 * 
 */
swarm.defobj.Zone getGlobalZone ();

/**
 * 
 */
swarm.random.MT19937gen getRandomGenerator ();

/**
 * 
 */
swarm.random.UniformIntegerDist getUniformIntRand ();

/**
 * 
 */
swarm.random.UniformDoubleDist getUniformDblRand ();

/**
 * 
 */
swarm.objectbase.ProbeLibrary getProbeLibrary ();

/**
 * 
 */
swarm.simtoolsgui.ProbeDisplayManager getProbeDisplayManager ();

/**
 * 
 */
swarm.defobj.Archiver getHdf5Archiver ();

/**
 * 
 */
swarm.defobj.Archiver getLispArchiver ();

/**
 * 
 */
swarm.defobj.Archiver getHdf5AppArchiver ();

/**
 * 
 */
swarm.defobj.Archiver getLispAppArchiver ();

/**
 * 
 */
boolean getGuiFlag ();

/**
 * 
 */
swarm.defobj.Symbol getLanguageCOM ();

/**
 * 
 */
swarm.defobj.Symbol getLanguageJava ();

/**
 * 
 */
swarm.defobj.Symbol getLanguageObjc ();
}
