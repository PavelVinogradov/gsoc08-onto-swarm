package swarm.objectbase;

/**
 * <strong> A class that allows the user to inspect a given variable in any candidate that is an instance of, or inherits from, a given class.</strong>.

 This is a specialized subclass of the abstract class Probe. It completes the specification of a probe that refers to an instance variable element of an object. 
 */
public interface VarProbe extends Probe, ProbeS {

/**
 *  The getProbedVariable method returns a string matching the identifier of variable being probed.
 */
java.lang.String getProbedVariable ();

/**
 *  The getInteractiveFlag method returns the interactivity state of the VarProbe.
 */
boolean getInteractiveFlag ();

/**
 *  A field probed with probeAsObject: must be an object.
 */
Object probeObject (Object anObject);

/**
 *  The probeAsInt: method returns a pointer to the probed variable as an integer.
 */
int probeAsInt (Object anObject);

/**
 *  The probeAsDouble: method returns a pointer to the probed variable as a double.
 */
double probeAsDouble (Object anObject);

/**
 *  The probeAsString: method prints the value of the variable into a new String object. 
 */
swarm.collections.String probeAsString (Object anObject);

/**
 *  Returns rank of array, or 0 for scalar objects.
 */
int getRank ();

/**
 *  In the case of arrays, returns the base type.
 */
java.lang.String getBaseType ();

/**
 *  The setData:ToString: sets the probedVariable using a string which the probe reads and converts appropriately. When setting the value of an  unsigned char or a char using this method, the expected format of the string is always "%i" unless CharString was chosen (in which case the format should be "'%c'").
 */
boolean setData$ToString (Object anObject, java.lang.String s);

/**
 *  Sets the probeVariable value using a double.  This requires that the value is numeric.
 */
void setData$ToDouble (Object anObject, double val);
}
