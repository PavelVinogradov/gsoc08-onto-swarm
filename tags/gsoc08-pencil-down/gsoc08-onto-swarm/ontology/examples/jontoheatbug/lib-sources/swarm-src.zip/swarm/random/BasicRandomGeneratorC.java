package swarm.random;

/**
 * <strong> The common functionality of simple and split generators.</strong>.

 This protocol covers methods common to simple and split generators.
 */
public interface BasicRandomGeneratorC extends swarm.objectbase.SwarmObjectC, swarm.objectbase.SwarmObjectS, InternalStateC, InternalStateS, CommonGeneratorC, CommonGeneratorS {
}
