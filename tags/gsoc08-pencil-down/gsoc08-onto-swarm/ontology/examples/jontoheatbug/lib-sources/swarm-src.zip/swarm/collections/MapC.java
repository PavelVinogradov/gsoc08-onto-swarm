package swarm.collections;

/**
 * <strong> Collection of associations from key objects to member objects.</strong>.

 Map is a subtype of KeyedCollection in which the key value associated with each member is independent of the member itself.  Whenever a new member is added to the collection, a key value to be associated with the member must be supplied also.  A Map defines a mapping from key values to member values. For the Map type, key values are independent of the member values with which they are associated.  Map defines two additional options to document information about its key values.  Map also defines its own messages to distinguish the key value from member value in any operation which involves both.
 */
public interface MapC extends KeyedCollectionC, KeyedCollectionS, CompareFunctionC, CompareFunctionS, swarm.defobj.SerializationC, swarm.defobj.SerializationS {
}
