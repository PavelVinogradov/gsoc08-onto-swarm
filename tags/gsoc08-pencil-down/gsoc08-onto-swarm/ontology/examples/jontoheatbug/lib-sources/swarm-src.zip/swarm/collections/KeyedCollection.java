package swarm.collections;

/**
 * <strong> Member identity definition shared by Set and Map types.</strong>.

 A keyed collection is a collection in which each member can be compared with some other value that identifies the member.  This value is referred to as the member key.  The key value may be determined either by the member value itself, which defines a Set, or by external association with the member when the member is first added, which defines a Map. The KeyedCollection type inherits all standard behavior of Collection. The KeyedCollection type is not itself creatable; it only serves as a common supertype for Set and Map collection types. The keyed collection type establishes the common behavior shared by both Set and Map.  Standard options are provided to declare ordering of members in the collection. 
 */
public interface KeyedCollection extends Collection, CollectionS, ForEachKey, ForEachKeyS {

/**
 * 
 */
Object createIndex$fromMember (swarm.defobj.Zone aZone, Object anObject);

/**
 *  The at: message returns the existing member of the collection which matches the key value passed as its argument, or nil if there is no key value in the collection which matches.  If duplicate entries for this key exist, the entire collection of duplicate members created for the key value is returned instead.
 */
Object at (Object aKey);

/**
 *  The removeKey: message removes a member matching a key value from the collection, and returns the member just removed.  It returns nil if there is no key value in the collection which matches.  If more than one entry was present for the key value, it removes and returns the first member in the internal collection created for duplicate members.
 */
Object removeKey (Object aKey);

/**
 *  The containsKey: message returns true if the key value passed as its argument is contained in the collection, and false otherwise. 
 */
boolean containsKey (Object aKey);
}
