package swarm.objectbase;

/**
 * <strong> Protocol for configuration of Probes, ProbeMaps, and the ProbeLibrary.</strong>.

 Protocol for configuration of Probes, ProbeMaps, and the ProbeLibrary.
 */
public interface ProbeConfig  {

/**
 * 
 */
Object setObjectToNotify (Object anObject);

/**
 * 
 */
Object getObjectToNotify ();
}
