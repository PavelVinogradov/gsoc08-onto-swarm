package swarm.objectbase;

/**
 * <strong> A temporal container.</strong>.

 A Swarm is a community of agents sharing a common timescale as well as common memory pool.
 */
public interface Swarm extends swarm.activity.SwarmProcess, swarm.activity.SwarmProcessS {

/**
 *  Override this to let your Swarm create the objects that it  contains. 
 */
Object buildObjects ();

/**
 *  Override this to let your Swarm build its actions.
 */
Object buildActions ();

/**
 *  Override this to activate any actions you built in buildActions. Note, you must activate yourself first before you can activate actions inside you. 
 */
swarm.activity.Activity activateIn (Swarm swarmContext);

/**
 *  Needed to support probing of Swarms.
 */
ProbeMap getProbeMap ();

/**
 *  Needed to support probing of Swarms.
 */
ProbeMap getCompleteProbeMap ();

/**
 *  Needed to support probing of Swarms.
 */
VarProbe getProbeForVariable (java.lang.String aVariable);
}
