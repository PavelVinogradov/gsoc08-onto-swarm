package swarm.objectbase;

/**
 * <strong> A CustomProbeMap to be used for building up ProbeMaps from scratch.</strong>.

 A CustomProbeMap to be used for building up ProbeMaps from scratch.
 */
public interface EmptyProbeMapC extends CustomProbeMapC, CustomProbeMapS {

/**
 *  Convenience method for creating an EmptyProbeMap 
 */
Object create$forClass (swarm.defobj.Zone aZone, Class aClass);
}
