package swarm.activity;

/**
 * <strong> A level of processing by the interpreter of an action type.</strong>.

 A object of type Activity implements the processing of actions within an action plan.  Each subtype of action plan has a corresponding subtype of Activity that implements processing of its respective type of plan. The Activity types are part of the virtual processing machinery of an action plan interpreter.  All the important elements of this machinery, including their current state of processing, are exposed to aid in development of general-purpose tools such as debuggers.  Except for applications that need to create and run their own reflective activities, direct use of activity types by a modeling application should be rare. A new activity object is created by each activateIn: message sent to an action type.  activateIn: initializes a new activity object and prepares it for processing, but does not itself execute any actions. Subsequent messages, such as run, must be used to initiate processing within an activity.  If an activity is activated to run under a swarm context, the owning swarm itself controls all processing within the subactivity. An Activity type holds a tree of currently running, or a potentially runnable, subactivities.  Each activity object represents a state of processing within a single action plan.  The structure is a tree because multiple activities could be running or eligible to run at the same time.  This occurs whenever two activities are specified as concurrent, either because are being performed by concurrent actions in some other plan, or because they were started for autonomous execution under the same swarm.  When parallel processing machinery is present, each activity could also be advancing its own state independent of those of any other activity. The current implementation supports only a single serial processor. Under serial execution, only one activity may be active at one time. This means that the current state of processing may be represented by a single stack of current activities that traces a path to a single leaf of the runnable activity tree.  When running in serial mode, messages are available to obtain the currently running leaf activity or useful context information such as the current time available from it.
 */
public interface Activity extends swarm.defobj.DefinedObject, swarm.defobj.DefinedObjectS, swarm.defobj.Drop, swarm.defobj.DropS {

/**
 *  The run message continue processing of an activity from any state in which its execution has been suspended.  An error is raised if the activity is already running.  run returns either a Stopped or Completed status that the activity has when it is no longer eligible to be run further.
 */
swarm.defobj.Symbol run ();

/**
 *  The stop message causes the a currently running tree of activities to stop further processing and return a Stopped status.  
 */
void stop ();

/**
 *  Terminate also stops a running tree of activities, but sets all activities within the tree to a status of Completed whenever the tree is next run. terminate may be used on either a running or stopped tree of activities.  It is the standard way to terminate schedule that is endlessly repeating under the RepeatInterval option.
 */
void terminate ();

/**
 *  The next executes actions within a single compound action while skipping over all processing of any complete action plans executed by those actions.
 */
swarm.defobj.Symbol nextAction ();

/**
 *  The step message executes a single action within a tree of activities. 
 */
swarm.defobj.Symbol stepAction ();

/**
 *  The getStatus message returns one of the following codes for the current run status of a particular activity: Initialized, Running, Stopped, Holding, Released, Terminated, Completed.
 */
swarm.defobj.Symbol getStatus ();

/**
 *  The getHoldType returns a code for the particular hold constraint under which an activity is currently holding (HoldStart or HoldEnd). It returns nil if the basic status of the activity is not Holding.  (.. Currently no hold constraints other than merging within a swarm are supported, and this message always returns nil.)
 */
swarm.defobj.Symbol getHoldType ();

/**
 *  Get action containing parameter bindings for the local activity.
 */
Action getAction ();

/**
 *  Get action type of action being performed by activity.
 */
Object getActionType ();

/**
 *  Change owner from one swarm activity to another.
 */
void setOwnerActivity (Object ownerActivity);

/**
 *  Return activity under which this activity is running.
 */
Activity getOwnerActivity ();

/**
 *  Return set of subactivities pending to be run.
 */
Object getSubactivities ();

/**
 *  Return activity that issued current run request on top-level activity.
 */
Activity getControllingActivity ();

/**
 *  Return top of activity tree running the local activity.
 */
Activity getTopLevelActivity ();

/**
 *  Return most immediately containing Swarm activity.
 */
SwarmActivity getSwarmActivity ();

/**
 *  Return most immediately containing Schedule activity.
 */
ScheduleActivity getScheduleActivity ();

/**
 *  Set serial execution mode.
 */
Object setSerialMode (boolean serialMode);

/**
 *  Return indicator for serial execution mode.
 */
boolean getSerialMode ();

/**
 *  Get running subactivity or next subactivity to run.
 */
Activity getCurrentSubactivity ();
}
