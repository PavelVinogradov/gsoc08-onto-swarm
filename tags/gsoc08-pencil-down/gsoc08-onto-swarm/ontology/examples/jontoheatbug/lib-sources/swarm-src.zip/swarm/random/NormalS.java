package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface NormalS extends DoubleDistributionS {

/**
 *  The setMean:setVariance: method  sets the mean and the variance of the distribution.
 */
Object setMean$setVariance (double mean, double variance);

/**
 *  The setMean:setStdDev: method  sets the mean and the standard deviation of the distribution.
 */
Object setMean$setStdDev (double mean, double sdev);
}
