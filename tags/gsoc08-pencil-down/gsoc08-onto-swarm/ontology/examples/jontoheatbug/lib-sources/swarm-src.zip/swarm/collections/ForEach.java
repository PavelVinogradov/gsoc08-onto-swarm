package swarm.collections;

/**
 * <strong> Messages for performing the same message on objects in a collection.</strong>.

 The forEach messages supply a convenient shorthand for repeatedly performing the same message on all objects contained as members in a collection.  The message to be sent is identified by the argument aSelector.  This selector must define the same number of arguments as contained in any remaining argument slots of the forEach message.  The argument types of the message to be sent must be either the id type, or some other type that will fit in the same number of bits as the id type.  By global portability assumptions, the argument type could be as large as an int (signed or unsigned), but not necessarily as large as a long.  To use the message, any non-id value must be cast to the id type as part of the call expression. The forEach: messages are implemented by a simple loop through all members of a collection, using an internal, temporary index.  If any operation more complex than a simple message send is required, this operation should just be coded directly using a loop that traverses its own index.
 */
public interface ForEach  {

/**
 * 
 */
void forEach (swarm.Selector aSelector);

/**
 * 
 */
void forEach (swarm.Selector aSelector, Object arg1);

/**
 * 
 */
void forEach (swarm.Selector aSelector, Object arg1, Object arg2);

/**
 * 
 */
void forEach (swarm.Selector aSelector, Object arg1, Object arg2, Object arg3);

/**
 * 
 */
void describeForEach (Object outputCharStream);

/**
 * 
 */
void describeForEachID (Object outputCharStream);
}
