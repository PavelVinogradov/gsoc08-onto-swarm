package swarm.defobj;

/**
 * <strong> A language independent interface to dynamic calls.</strong>.

 A language independent interface to dynamic calls.
 */
public interface FCallC extends CreateC, CreateS, DropC, DropS {

/**
 * 
 */
Object create$target$selector$arguments (Zone aZone, Object obj, swarm.Selector sel, FArguments fa);

/**
 * 
 */
Object create$target$methodName$arguments (Zone aZone, Object obj, java.lang.String methodName, FArguments fa);

/**
 * 
 */
Object setArguments (Object args);

/**
 * 
 */
Object setMethodFromSelector$inObject (swarm.Selector method, Object object);

/**
 * 
 */
Object setMethodFromName$inObject (java.lang.String methodName, Object object);

/**
 * 
 */
Object setJavaMethodFromName$inObject (java.lang.String methodName, Object jObj);

/**
 * 
 */
Object setJavaMethodFromName$inClass (java.lang.String methodName, java.lang.String className);
}
