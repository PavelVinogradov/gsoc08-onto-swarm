package swarm.activity;

/**
 * <strong> Synchronization type sets the type of schedule which is used internally by the swarm to synchronize subschedules. </strong>.

 Synchronization type sets the type of schedule which is used internally by the swarm to synchronize subschedules.  Its default is a schedule with a concurrent group of ActivationOrder. The default value for the SynchronizationType option is not a generic action group, but a special predefined subtype of ActionGroup called ActivationOrder.  This concurrent group type guarantees that actions scheduled to occur at the same time from different action plans running in the same swarm are executed in the same order in which the action plans were first activated.
 */
public interface SynchronizationType  {

/**
 * 
 */
Object getSynchronizationType ();
}
