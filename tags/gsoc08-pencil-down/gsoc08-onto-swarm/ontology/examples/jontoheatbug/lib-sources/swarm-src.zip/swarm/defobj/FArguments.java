package swarm.defobj;

/**
 * <strong> A language independent interface to dynamic call argument construction.</strong>.

 A language independent interface to dynamic call argument construction.
 */
public interface FArguments extends Create, CreateS, Drop, DropS {

/**
 * 
 */
Symbol getLanguage ();
}
