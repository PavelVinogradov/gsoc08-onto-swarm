package swarm.defobj;

/**
 * <strong> A report of some condition detected during program execution.</strong>.

 A report of some condition detected during program execution.
 */
public interface EventTypeC extends SymbolC, SymbolS {
}
