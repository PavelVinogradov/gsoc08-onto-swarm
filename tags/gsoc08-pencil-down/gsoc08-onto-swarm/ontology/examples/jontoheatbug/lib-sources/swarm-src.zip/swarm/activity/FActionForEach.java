package swarm.activity;

/**
 * <strong> Base protocol for FActionForEach{Homogeneous,Heterogeneous}.</strong>.

 Base protocol for FActionForEach{Homogeneous,Heterogeneous}.
 */
public interface FActionForEach extends FAction, FActionS, ActionTarget, ActionTargetS, DefaultOrder, DefaultOrderS {
}
