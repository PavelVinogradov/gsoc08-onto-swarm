package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface Normal extends DoubleDistribution, DoubleDistributionS {

/**
 *  The getMean method returns the mean of the distribution.
 */
double getMean ();

/**
 *  The getVariance method returns the variance of the distribution.
 */
double getVariance ();

/**
 *  The getStdDev method returns the standard deviation of the distribution.
 */
double getStdDev ();

/**
 *  The getSampleWithMean:withVariance: method returns a sample value drawn from a distribution with the specified mean and variance.
 */
double getSampleWithMean$withVariance (double mean, double variance);

/**
 *  The getSampleWithMean:withStdDev: method returns a sample value drawn from a distribution with the specified mean and standard deviation.
 */
double getSampleWithMean$withStdDev (double mean, double sdev);
}
