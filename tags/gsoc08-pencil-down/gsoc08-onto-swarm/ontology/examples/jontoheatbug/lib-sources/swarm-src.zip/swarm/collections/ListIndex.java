package swarm.collections;

/**
 * <strong> Index with insertion capability at any point in list.</strong>.

 The addAfter: and addBefore: messages add members at a particular point in the sequence of members maintained by a list.  The current location of an index determines the point at which a new member will be added.  The addAfter: message adds a member at the list position immediately following the current index location.  addBefore: adds a member to the immediately preceding location.  Neither message changes the current location of the index, except that an index can change from a Start or End location to a location of Between. Since an index may be positioned to any location in a list, these messages enable the construction of any desired sequence of members. Since the current index location remains unchanged, multiple members may all be inserted successively at some point in a list; previously added members are just pushed out one-by-one as new members are added. An index with a location of Start, End, or Between is just as valid a location for addAfter: or addBefore: as an index positioned at a member.  In these cases, there is no member at the current location of the index, so the new member is just inserted directly at the current index location, and the index is left positioned between the new member and the member that was previously adjacent in the opposite direction.  If the previous location was Start and the message addAfter:, or the location was End and the message addBefore:, the index location remains Start or End.
 */
public interface ListIndex extends Index, IndexS {

/**
 *  Add a member after the index.
 */
void addAfter (Object anObject);

/**
 *  Add a member before the index.
 */
void addBefore (Object anObject);
}
