package swarm.collections;

/**
 * <strong> Exactly the same as the ForEach protocol, but only for KeyedCollections.</strong>.

 Works identically to the ForEach protocol, but loops through the keys in a KeyedCollection, rather than the members.
 */
public interface ForEachKeyC  {
}
