package swarm.random;

/**
 * <strong> Binomial distribution</strong>.

 The binomial distribution gives the discrete probability  of obtaining exactly n successes out of N Bernoulli trials
 */
public interface BinomialDist extends UnsignedDistribution, UnsignedDistributionS {

/**
 *  The getNumTrials returns number of trials parameter.
 */
int getNumTrials ();

/**
 *  The getProbability returns probability parameter.
 */
double getProbability ();

/**
 *  The getIntegerSampleWithInterval returns a sample value using the distribution's  current number of trials and new probability value. Causes an error if the number  of trials has not been previously set.
 */
int getUnsignedSampleWithProbability (double aProbability);

/**
 *  The getUnsignedSampleWithOccurRate:andInterval return a sample value for the specified number of trials and probability. Does not change the the distribution's parameter values.
 */
int getUnsignedSampleWithNumTrials$withProbability (int aNumTrials, double aProbability);
}
