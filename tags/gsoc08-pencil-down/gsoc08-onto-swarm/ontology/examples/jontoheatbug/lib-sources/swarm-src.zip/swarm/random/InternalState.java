package swarm.random;

/**
 * <strong> Archiving routines for internal generator and distribution state.</strong>.

 Methods to save the internal state of an object (generator, distribution) to a memory buffer allocated by the calling program, and to set the state of an object from previously saved state data, provided in a memory buffer. NOTE: the putStateInto/setStateFrom methods are NOT portable across  architectures, since they store integers and doubles using different byte orders. A portable storage method may be provided in the next release.
 */
public interface InternalState  {

/**
 *  Specifies the minimum buffer size needed.
 */
int getStateSize ();

/**
 * 
 */
int getMagic ();
}
