package swarm.collections;

/**
 * <strong> A class to randomize the order of a given Swarm List</strong>.

 ListShuffler randomizes the order of the elements in a List;  either the whole list or the num lowest elements. The list must be supplied. An uniform distribution can be supplied, or the system- supplied uniformUnsRand is used. The algorithm is from Knuth. All these methods modify the underlying collection, so any indexes should always be regenerated. 
 */
public interface ListShufflerC extends swarm.defobj.CreateC, swarm.defobj.CreateS, swarm.defobj.DropC, swarm.defobj.DropS {

/**
 *  the setUniformRandom: method connects the supplied uniform distribution  to the Shuffler (run after createBegin:).
 */
Object setUniformRandom (Object dist);

/**
 *  The create:setUniformRandom method creates the Shuffler and connects the supplied distribution object.
 */
Object create$setUniformRandom (swarm.defobj.Zone aZone, Object dist);
}
