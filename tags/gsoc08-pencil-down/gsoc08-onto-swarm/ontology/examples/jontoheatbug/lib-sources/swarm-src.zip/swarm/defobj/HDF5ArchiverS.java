package swarm.defobj;

/**
 * <strong> Protocol for creating HDF5 instances of the Archiver</strong>.

 Protocol for creating HDF5 instances of the Archiver Default system path is ~/swarmArchiver.hdf Default application path is <swarmdatadir>/<appname>/<appname>.hdf  or the current directory.
 */
public interface HDF5ArchiverS extends ArchiverS {
}
