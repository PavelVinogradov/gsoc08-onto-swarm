package swarm.activity;

/**
 * <strong> An action that sends a message to an object.</strong>.

 A createActionTo: message specifies that the action to be performed is defined by an Objective C message selector to be performed on a receiving object plus any required arguments.  The message selector is specified by the message: argument and the receiving object is specified as the first argument, target.
 */
public interface ActionCreatingToC  {
}
