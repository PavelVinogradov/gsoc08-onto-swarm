package swarm.activity;

/**
 * <strong> State of execution within a Schedule.</strong>.

 State of execution within a Schedule.
 */
public interface ScheduleActivityS extends ActivityS {
}
