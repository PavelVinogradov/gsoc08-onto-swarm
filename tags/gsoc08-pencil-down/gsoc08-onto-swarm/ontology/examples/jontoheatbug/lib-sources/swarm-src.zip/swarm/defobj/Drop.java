package swarm.defobj;

/**
 * <strong> Deallocate an object allocated within a zone.</strong>.

 The Drop supertype defines the drop message, which is a standard message for indicating that an object no longer exists and will never again be referenced.  Any future attempt to reference a dropped object is an error.  This error may or not produce predictable effects depending on the level of debug checking and other factors.
 */
public interface Drop  {

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
void drop ();
}
