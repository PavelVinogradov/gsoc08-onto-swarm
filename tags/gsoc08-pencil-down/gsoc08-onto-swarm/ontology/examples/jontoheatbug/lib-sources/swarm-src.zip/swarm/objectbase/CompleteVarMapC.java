package swarm.objectbase;

/**
 * <strong> A subclass of ProbeMap, whose initial state contains no MessageProbes.</strong>.

 A subclass of ProbeMap, whose initial state contains no MessageProbes, but does contain all the VarProbes of the requested target class and  those of all its superclasses.
 */
public interface CompleteVarMapC extends ProbeMapC, ProbeMapS {
}
