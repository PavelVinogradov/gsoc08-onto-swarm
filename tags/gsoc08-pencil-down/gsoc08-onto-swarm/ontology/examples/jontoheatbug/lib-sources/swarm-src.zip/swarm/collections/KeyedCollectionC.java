package swarm.collections;

/**
 * <strong> Member identity definition shared by Set and Map types.</strong>.

 A keyed collection is a collection in which each member can be compared with some other value that identifies the member.  This value is referred to as the member key.  The key value may be determined either by the member value itself, which defines a Set, or by external association with the member when the member is first added, which defines a Map. The KeyedCollection type inherits all standard behavior of Collection. The KeyedCollection type is not itself creatable; it only serves as a common supertype for Set and Map collection types. The keyed collection type establishes the common behavior shared by both Set and Map.  Standard options are provided to declare ordering of members in the collection. 
 */
public interface KeyedCollectionC extends CollectionC, CollectionS, ForEachKeyC, ForEachKeyS {
}
