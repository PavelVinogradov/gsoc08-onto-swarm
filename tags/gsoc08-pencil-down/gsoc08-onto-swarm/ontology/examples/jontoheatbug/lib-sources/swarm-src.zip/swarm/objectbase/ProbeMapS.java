package swarm.objectbase;

/**
 * <strong> A container class for Probes used to specify the contents of a  ProbeDisplay.</strong>.

 A ProbeMap is a Map-type collection of Probes. They are used to gather  several Probes, who usually have a common referent, into a single bundle. For example, all the instance variables of a ModelSwarm might be  gathered into a single ProbeMap. Each ProbeMap is then installed into the global ProbeLibrary. 
 */
public interface ProbeMapS extends SwarmObjectS, ProbeConfigS {
}
