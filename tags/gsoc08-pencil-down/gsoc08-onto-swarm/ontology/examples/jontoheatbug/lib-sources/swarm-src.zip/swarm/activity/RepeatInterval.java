package swarm.activity;

/**
 * <strong> Reschedule actions after a period of time.</strong>.

 The RepeatInterval option specifies that as soon as all actions in the schedule have completed, it is to be rescheduled at a time computed as the time at which the schedule was last started, plus the value specified as the RepeatInterval argument.  This option overrides the normal default that times are considered absolute, as if the RelativeTime option had also been specified at the same time.  All scheduled times must be less than the specified repeat interval, or an error will be raised.  The RepeatInterval option can continue to be reassigned to different values after a schedule has been created, but the interval value must always be greater than the scheduled times of any actions which it contains. (.. This option is currently supported only on schedule, not swarms.)
 */
public interface RepeatInterval  {

/**
 * 
 */
int getRepeatInterval ();
}
