package swarm.defobj;

/**
 * <strong> HDF5 interface</strong>.

 HDF5 interface
 */
public interface HDF5S extends CreateS, DropS {

/**
 *  Create-time use is to name the file or group. Setting-time use is to rename component datasets that don't parent's name.
 */
Object setName (java.lang.String name);

/**
 * 
 */
Object setBaseTypeObject (Object baseTypeObject);
}
