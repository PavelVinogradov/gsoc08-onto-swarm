package swarm.objectbase;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A temporal container.</strong>.

 A Swarm is a community of agents sharing a common timescale as well as common memory pool.
 */
public class SwarmImpl extends swarm.BaseImpl implements swarm.activity.SwarmProcess, swarm.activity.SwarmProcessS, SwarmS, Swarm {


/**
 *  Needed to support probing of Swarms.
 */
public native VarProbe getProbeForVariable (java.lang.String aVariable);

/**
 *  Needed to support probing of Swarms.
 */
public native ProbeMap getCompleteProbeMap ();

/**
 *  Needed to support probing of Swarms.
 */
public native ProbeMap getProbeMap ();

/**
 *  Override this to let your Swarm build its actions.
 */
public native Object buildActions ();

/**
 *  Override this to let your Swarm create the objects that it  contains. 
 */
public native Object buildObjects ();

/**
 *  getActivity returns the activity which is currently running of subactivities within the swarm.  This activity is the same as the value returned by activateIn: when the swarm was first activated.  It returns nil if the swarm has not yet been activated.
 */
public native swarm.activity.SwarmActivity getActivity ();

/**
 *  getInternalZone returns a Zone object that is used by the swarm to hold its internal objects.  Even though the swarm itself inherits from Zone and can be used as a Zone for nearly all purposes, this message is also provided so that the zone itself can be obtained independent of all zone behavior.
 */
public native Object getInternalZone ();

/**
 * 
 */
public native Object getSynchronizationType ();

/**
 *  Generate debug id description for each member of the zone population.
 */
public native void describeForEachID (Object outputCharStream);

/**
 *  Generate debug description for each member of the zone population.
 */
public native void describeForEach (Object outputCharStream);

/**
 *  getPopulation returns a collection all objects allocated in a zone using either allocIVars: or copyIVars: and not yet freed using freeIVars:.  getObjects returns nil if the ObjectCollection option is false.  The collection returned has the type OrderedSet as defined in the collections library, with the ReadOnly option set true and the IndexSafety option set to SafeAlways.  The members of this collection may change as objects are allocated and freed, but may not added or removed directly within the collection.
 */
public native swarm.collections.List getPopulation ();

/**
 *  Returns a specially qualified version of the zone that automatically allocates all its objects with the internal component qualification, even if allocated with allocIVars: or copyIVars:.  This qualified zone may be passed as an argument to a create: or createBegin: message so that it will create the new object as an internal component object.
 */
public native Object getComponentZone ();

/**
 *  Frees the instance variable storage for an object.
 */
public native void freeIVarsComponent (Object anObject);

/**
 *  Like allocateIVarsComponent, except it copies the storage that holds the instances variables for an object.
 */
public native Object copyIVarsComponent (Object anObject);

/**
 *  These messages allocate, copy, and free This message allocates the storage that holds the instance variables for an object.  It allocates the object as an internal component of the zone that is not included in the zone population.  It is used by classes that allocate additional objects as part of the implementation of another object, and that control the mapping of this storage separately from the zone level objects.
 */
public native Object allocIVarsComponent (Class aClass);

/**
 *  freeIVars: releases storage that was previously allocated to hold the instance variable structure of an object.  The first word of the object must be a class pointer that correctly describes the size of the structure.  Storage allocated by allocIVars: or copyIVars: may be freed only by freeIVars:, and freeIVars: may be used only to free storage allocated by one of these messages.
 */
public native void freeIVars (Object anObject);

/**
 *  copyIVars: creates copies an existing instance variable structure into a new allocation made within the local zone.  The existing instance variable structure may be in any zone, but must contain a class pointer in its first word that correctly describes the size of the structure.
 */
public native Object copyIVars (Object anObject);

/**
 *  allocIVars: allocates the instance variable structure for a new object.  The initial word of this structure is set to class id passed as its argument.  The class also determines the size of the structure allocated.  All remaining contents of this structure are initialized to binary zeroes.
 */
public native Object allocIVars (Class aClass);

/**
 * 
 */
public native int getPageSize ();

/**
 *  The activateIn: message is used to initialize a process for executing the actions of an ActionType.  This process is controlled by an object called an Activity.  The activateIn message initializes an activity to run under the execution context passed as the swarmContext argument, and return the activity object just created.  If the execution context is nil, an activity is returned that allows complete execution control by the caller.  Otherwise, the execution context must be either an instance of SwarmProcess or SwarmActivity.  (These objects are always maintained in one-to-one association with each other, either one of the pair is equivalent to the other as a swarmContext argument.) If a top-level activity is created (swarmContext is nil), the created activity may be processed using activity processing commands such as run, step, etc.  If an activity is created to run under a swarm context, the swarm itself has responsibility for advancing the subactivity according to its requirements for synchronization and control among all its activities.  Activating a plan for execution under a swarm turns over control to the swarm to execute the subactivity as a more-or-less autonomous activity.
 */
public native swarm.activity.Activity activateIn (Swarm swarmContext);

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();
public SwarmImpl () {
  super ();
}

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public SwarmImpl (swarm.defobj.Zone aZone) { super (); new SwarmCImpl (this).create (aZone); }
}
