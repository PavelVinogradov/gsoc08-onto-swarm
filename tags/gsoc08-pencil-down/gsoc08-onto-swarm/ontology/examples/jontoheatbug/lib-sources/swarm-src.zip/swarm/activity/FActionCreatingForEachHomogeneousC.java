package swarm.activity;

/**
 * <strong> Invoke a FCall for every item in the target collection.  All members must be of the same type.</strong>.

 Invoke a FCall for every item in the target collection.  All members must be of the same type.
 */
public interface FActionCreatingForEachHomogeneousC  {
}
