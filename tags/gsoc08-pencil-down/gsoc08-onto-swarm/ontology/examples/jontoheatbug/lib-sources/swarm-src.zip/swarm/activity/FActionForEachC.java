package swarm.activity;

/**
 * <strong> Base protocol for FActionForEach{Homogeneous,Heterogeneous}.</strong>.

 Base protocol for FActionForEach{Homogeneous,Heterogeneous}.
 */
public interface FActionForEachC extends FActionC, FActionS, ActionTargetC, ActionTargetS, DefaultOrderC, DefaultOrderS {
}
