package swarm.random;

/**
 * <strong> Combined Tausworthe generator 1</strong>.

 Component 1 parameters: P = 31, S = 12, Q = 13 Component 2 parameters: P = 29, S = 17, Q =  2 With these parameters, this generator has a single full cycle of  length ~ 2^60.
 */
public interface C2TAUS1gen extends C2TAUSgen, C2TAUSgenS {
}
