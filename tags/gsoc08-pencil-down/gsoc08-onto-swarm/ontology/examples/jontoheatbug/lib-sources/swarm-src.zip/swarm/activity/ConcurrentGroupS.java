package swarm.activity;

/**
 * <strong> Default type used as concurrent group of a schedule.</strong>.

 Default type used as concurrent group of a schedule.
 */
public interface ConcurrentGroupS extends ActionGroupS {
}
