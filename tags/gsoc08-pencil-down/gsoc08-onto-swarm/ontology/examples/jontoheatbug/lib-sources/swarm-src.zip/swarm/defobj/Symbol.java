package swarm.defobj;

/**
 * <strong> Object defined as a distinct global id constant.</strong>.

 A Symbol is an object created with a fixed name.  It has no behavior except to get the name with which it was created.  A Symbol is typically used to define unique id values which are assigned to global constant names.  These names, capitalized according to the recommended convention for global object constants, are used by some libraries as flags or enumerated value codes in arguments or return values of messages. Ordinarily, a symbol is created with its character string name matching the global id constant to which it is assigned.  These global program constants can then provide a minimal level of self documentation as objects.  Subtypes of Symbol can extend the base of a named, global id constant to establish further components of a global, constant definition. A symbol is fully creatable using standard Create messages.  A character string name must be supplied for any new symbol; there is no default.  Symbol inherits the getName message, which returns the symbol name.
 */
public interface Symbol extends Create, CreateS, GetName, GetNameS {
}
