package swarm.collections;

/**
 * <strong> The index behavior for a Map.</strong>.

 The index behavior for a Map.
 */
public interface MapIndexC extends KeyedCollectionIndexC, KeyedCollectionIndexS {
}
