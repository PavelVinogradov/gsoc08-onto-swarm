package swarm.defobj;

/**
 * <strong> Protocol for creating Lisp instances of the Archiver</strong>.

 Protocol for creating Lisp instances of the Archiver Default system path is ~/.swarmArchiver.scm. Default application path is <swarmdatadir>/<appname>/<appname>.scm or the current directory.
 */
public interface LispArchiver extends Archiver, ArchiverS {
}
