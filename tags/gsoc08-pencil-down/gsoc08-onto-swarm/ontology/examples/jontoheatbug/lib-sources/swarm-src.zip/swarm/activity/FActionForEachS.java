package swarm.activity;

/**
 * <strong> Base protocol for FActionForEach{Homogeneous,Heterogeneous}.</strong>.

 Base protocol for FActionForEach{Homogeneous,Heterogeneous}.
 */
public interface FActionForEachS extends FActionS, ActionTargetS, DefaultOrderS {
}
