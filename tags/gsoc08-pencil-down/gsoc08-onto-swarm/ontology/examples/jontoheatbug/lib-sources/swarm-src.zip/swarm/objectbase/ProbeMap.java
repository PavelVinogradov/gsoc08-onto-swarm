package swarm.objectbase;

/**
 * <strong> A container class for Probes used to specify the contents of a  ProbeDisplay.</strong>.

 A ProbeMap is a Map-type collection of Probes. They are used to gather  several Probes, who usually have a common referent, into a single bundle. For example, all the instance variables of a ModelSwarm might be  gathered into a single ProbeMap. Each ProbeMap is then installed into the global ProbeLibrary. 
 */
public interface ProbeMap extends SwarmObject, SwarmObjectS, ProbeConfig, ProbeConfigS {

/**
 *  The getCount method returns the number of probes in the ProbeMap.
 */
int getCount ();

/**
 *  The getProbedClass method returns the class of the object that the set of  probes that constitute the probe map points at.
 */
Class getProbedClass ();

/**
 *  The addProbe: method adds a probe to the contents of the ProbeMap. The ProbeMap will always make sure that the probedClass of the Probe being added corresponds to its own probedClass.
 */
Object addProbe (Probe aProbe);

/**
 *  The addProbeMap: method is used to tailor the contents of a ProbeMap by performing "set inclusion" with another ProbeMap. The typing is verified  prior to inclusion.
 */
Object addProbeMap (ProbeMap aProbeMap);

/**
 *  The dropProbeForVariable: method is used to drop a Probe from the  ProbeMap. No class verification takes place since the probe is dropped based on its variableName, not its actual id value.
 */
void dropProbeForVariable (java.lang.String aVariable);

/**
 *  The dropProbeForMessage: method is used to drop a Probe from the ProbeMap. No class verification takes place since the probe is dropped based on its messageName, not its actual id value.
 */
void dropProbeForMessage (java.lang.String aMessage);

/**
 *  The dropProbeMap: method is used to drop a probe from a probe map. It is equivalent to callling dropProbeForVariable for each variable name present in the ProbeMap being dropped, followed by a call to dropProbeForMessage for each message name present in the ProbeMap being dropped.
 */
Object dropProbeMap (ProbeMap aProbeMap);

/**
 *  The begin: method returns an iterator (index) over the ProbeMap. This  index is used in the exact same way any Map index is used. 
 */
swarm.collections.Index begin (swarm.defobj.Zone aZone);

/**
 *  The clone: method returns a clone of the probe map. If the initial probe map created by Library Generation or by the default version of Object  generation, the probe map should be cloned prior to making changes to it  to avoid having the changes affect the other potential users of the  probe map.
 */
Object clone (swarm.defobj.Zone aZone);
}
