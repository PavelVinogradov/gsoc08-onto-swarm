package swarm.defobj;

/**
 * <strong> Object serialization protocol.</strong>.

 Object serialization protocol.
 */
public interface Serialization  {

/**
 *  Output a shallow Lisp representation of object state to a stream.
 */
void lispOutShallow (Object stream);

/**
 *  Output a deep Lisp representation of object state to a stream.
 */
void lispOutDeep (Object stream);

/**
 *  Output just key/variable pairs, where variables are serialized  deep or shallow per deepFlag.
 */
void lispOutVars$deep (Object stream, boolean deepFlag);

/**
 *  On the given stream, save a Boolean variable called "aName"  which has value "val". Explanation:  The Swarm lisp serialization approach assumes that objects have lispOutDeep: and lispOutShallow: methods which indicate which variables are supposed to be saved.  If an object is  subclassed from SwarmObject, there are default lispOutDeep:  and lispOutShallow: methods. Those methods employ on the method, lispOutVars:deep:, which is the "default" approach to try to save all variables, either deep or shallow.  Sometimes one needs to selectively list particular instance variables to be saved. This is necessary, for example, if one wants to save a Swarm itself, because the usage of lispOutVars: will result in  a variable "activity" being saved as nil, and so when the saved values are read back in, the "activity" variable will be erased and nil will appear in its place.   Here is an example of how a subclass called "BFagent"  might override lispOutDeep: to customize  the selection of variables to be saved.  Note that the same could be used to override lispOutShallow:.  The key thing to remember is that when one tries to do a deep save on a high level object, such as a Swarm, then the Swarm libraries will try to track from top to bottom, finding all collections and objects, and all objects and collections inside them, and so forth, and each will be told to execute its lispOutDeep: method.  So all objects you want to save need a lispOutDeep: method, or else the default will try to save all variables.  If you omit some objects or variables from your lispOutDeep: method, then they will not appear in the saved file, which is what you want if you want to be sure that pre-existing interited values of variables are not obliterated  by bogus saved values.
 */
void lispSaveStream$Boolean$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save a character variable called "aName" which has value "val".
 */
void lispSaveStream$Char$Value (Object stream, java.lang.String aName, char val);

/**
 *  On the given stream, save a short integer variable called "aName" which has value "val".
 */
void lispSaveStream$Short$Value (Object stream, java.lang.String aName, short val);

/**
 *  On the given stream, save an unsigned short integer variable called "aName" which has value "val".
 */
void lispSaveStream$UnsignedShort$Value (Object stream, java.lang.String aName, short val);

/**
 *  On the given stream, save an integer variable called "aName" which has value "val".
 */
void lispSaveStream$Integer$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save an unsigned integer variable called "aName" which has value "val".
 */
void lispSaveStream$Unsigned$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save a long variables called "aName" which has value "val".
 */
void lispSaveStream$Long$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save an unsigned long variable called "aName" which has value "val".
 */
void lispSaveStream$UnsignedLong$Value (Object stream, java.lang.String aName, int val);

/**
 *  On the given stream, save a long long variable called "aName" which has value "val".
 */
void lispSaveStream$LongLong$Value (Object stream, java.lang.String aName, long val);

/**
 *  On the given stream, save an unsigned long long variable called "aName" which has value "val".
 */
void lispSaveStream$UnsignedLongLong$Value (Object stream, java.lang.String aName, long val);

/**
 *  On the given stream, save a float valued variable called "aName" which has value "val".
 */
void lispSaveStream$Float$Value (Object stream, java.lang.String aName, double val);

/**
 *  On the given stream, save a double valued variable called "aName" which has value "val".
 */
void lispSaveStream$Double$Value (Object stream, java.lang.String aName, double val);

/**
 *  Output a shallow HDF5 representation of object state to a stream.
 */
void hdf5OutShallow (HDF5 hdf5obj);

/**
 *  Output a deep HDF5 representation of object state to a stream.
 */
void hdf5OutDeep (HDF5 hdf5obj);

/**
 * 
 */
void updateArchiver (Archiver archiver);
}
