package swarm.objectbase;

/**
 * <strong> A temporal container.</strong>.

 A Swarm is a community of agents sharing a common timescale as well as common memory pool.
 */
public interface SwarmS extends swarm.activity.SwarmProcessS {
}
