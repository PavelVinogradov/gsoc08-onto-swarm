package swarm.defobj;

/**
 * <strong> Class with variables and/or methods defined at runtime.</strong>.

 Class with variables and/or methods defined at runtime.
 */
public interface CreatedClassC extends CreateC, CreateS, DefinedClassC, DefinedClassS {

/**
 * 
 */
Object setName (java.lang.String name);

/**
 * 
 */
Object setClass (Class aClass);

/**
 * 
 */
Object setSuperclass (Object aClass);

/**
 * 
 */
Object setDefiningClass (Object aClass);

/**
 * 
 */
Object lispInCreate (Object expr);

/**
 * 
 */
Object hdf5InCreate (Object hdf5Obj);

/**
 * 
 */
void lispOutShallow (Object stream);

/**
 * 
 */
void hdf5OutShallow (HDF5 hdf5Obj);

/**
 * 
 */
void updateArchiver (Archiver archiver);
}
