package swarm.activity;

/**
 * <strong> An action generated when actions changes from single to concurrent.</strong>.

 An action generated when actions changes from single to concurrent.
 */
public interface ActionChangedS extends ActionS {
}
