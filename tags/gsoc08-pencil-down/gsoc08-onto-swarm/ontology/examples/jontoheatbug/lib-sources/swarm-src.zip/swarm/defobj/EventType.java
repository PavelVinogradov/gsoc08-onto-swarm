package swarm.defobj;

/**
 * <strong> A report of some condition detected during program execution.</strong>.

 A report of some condition detected during program execution.
 */
public interface EventType extends Symbol, SymbolS {

/**
 *  Raise an event noting the event symbol type.
 */
void raiseEvent ();
}
