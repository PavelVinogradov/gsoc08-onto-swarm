package swarm.activity;

/**
 * <strong> Default type used as concurrent group of a swarm.</strong>.

 Concurrent group to order merge by activation order within swarm.
 */
public interface ActivationOrder extends ActionGroup, ActionGroupS {

/**
 *  Method to sort concurrent merge actions in the order of swarm activation.
 */
void addLast (Object mergeAction);

/**
 *  Method to remove concurrent merge action from sorted group
 */
Object remove (Object mergeAction);
}
