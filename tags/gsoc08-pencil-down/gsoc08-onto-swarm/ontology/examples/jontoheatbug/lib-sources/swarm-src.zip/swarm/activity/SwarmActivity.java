package swarm.activity;

/**
 * <strong> A collection of started subactivities.</strong>.

 A collection of started subactivities.
 */
public interface SwarmActivity extends ScheduleActivity, ScheduleActivityS {

/**
 *  Return swarm object containing this swarm activity, if any.
 */
Object getSwarm ();

/**
 * 
 */
Schedule getSynchronizationSchedule ();
}
