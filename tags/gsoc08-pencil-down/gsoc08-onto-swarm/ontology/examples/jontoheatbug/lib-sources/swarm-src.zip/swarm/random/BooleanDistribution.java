package swarm.random;

/**
 * <strong> Boolean Distribution</strong>.

 A probability distribution that returns YES/NO sample values.
 */
public interface BooleanDistribution extends ProbabilityDistribution, ProbabilityDistributionS {

/**
 *  The getBooleanSample method returns a YES or NO sample value.
 */
boolean getBooleanSample ();

/**
 * 
 */
int getIntegerSample ();
}
