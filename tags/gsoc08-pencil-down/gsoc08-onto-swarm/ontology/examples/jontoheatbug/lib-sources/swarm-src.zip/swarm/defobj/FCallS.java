package swarm.defobj;

/**
 * <strong> A language independent interface to dynamic calls.</strong>.

 A language independent interface to dynamic calls.
 */
public interface FCallS extends CreateS, DropS {
}
