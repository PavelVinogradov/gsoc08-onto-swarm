package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Like ActionForEach, except that the collection must be homogeneous.</strong>.

 Like ActionForEach, except that the collection must be homogeneous.
 * @hide
 */
public class ActionForEachHomogeneousImpl extends swarm.BaseImpl implements Action, ActionS, ActionTarget, ActionTargetS, ActionSelector, ActionSelectorS, DefaultOrder, DefaultOrderS, ActionForEachHomogeneousS, ActionForEachHomogeneous {


/**
 * 
 */
public native swarm.defobj.Symbol getDefaultOrder ();

/**
 * 
 */
public native swarm.Selector getMessageSelector ();

/**
 * 
 */
public native Object getTarget ();

/**
 *  The getOwner message returns another object which is considered as the owner of an initial object.  What is considered as an owner depends on its specific object type, but might be a larger object of which the local object is a part, or an object that has exclusive control over the local object.  The principal constraint established by an ownership structure is that a given object can have only a single other object as its unambiguous owner.
 */
public native Object getOwner ();

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();

/**
 * 
 */
public native Object setDefaultOrder (swarm.defobj.Symbol aSymbol);

/**
 * 
 */
public native void setMessageSelector (swarm.Selector aSel);
public ActionForEachHomogeneousImpl () {
  super ();
}
}
