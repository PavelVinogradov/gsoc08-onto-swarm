package swarm.random;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Gamma distribution</strong>.

 A well-known continuous probability distribution returning doubles
 */
public class GammaDistCImpl extends swarm.PhaseCImpl implements DoubleDistributionC, DoubleDistributionS, GammaDistS, GammaDistC {

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
public native Object create$setGenerator$setVirtualGenerator$setAlpha$setBeta (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double alpha, double beta);

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
public native Object create$setGenerator$setAlpha$setBeta (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double alpha, double beta);

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
public native Object create$setGenerator (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator);

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
public native Object create$setGenerator$setVirtualGenerator (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen);

/**
 *  The createWithDefaults method creates a distribution object with a  default set of seeds and parameters, and its own private generator.
 */
public native Object createWithDefaults (swarm.defobj.Zone aZone);

/**
 *  The createEnd message completes the process of specifying available options for an object being created.  Typically it validates that requested options are valid and consistent with one another, and raises an error if they are not.  The standard, predefined error InvalidCombination may be raised by createEnd to indicate an invalid combination of requests, or other, more specific forms of error handling may be used. If all requests received since the initial createBegin: are valid, both individually and in combination with each other, then createEnd determines a finalized form of object that satisfies all requests received and then returns this object.  Any additional storage required for the finalized object is taken from the same zone originally passed to createBegin.  The object may have whatever implementation is selected to best satisfy a particular request. Different requests may result in entirely different implementations being returned.  The only guarantee is that a returned object supports the messages defined for further use of the finalized object.  If a type was defined by a @protocol declaration, these messages are those appearing in either the SETTING or USING sections. On return from createEnd, the id of the interim object returned by createBegin: is no longer guaranteed to be valid for further use, and should no longer be referenced.  A variable which holds this such an id can be reassigned the new id returned by createEnd, so that the same variable holds successive versions of the object being created.
 */
public native Object createEnd ();

/**
 *  createBegin: returns an interim object intended only for receiving create-time messages.  If a type was defined by a @protocol declaration, these messages are those appearing in either the CREATING or SETTING sections.  Otherwise, the messages valid as create-time messages are defined by the type without any specific syntactic marker.
 */
public native Object createBegin (swarm.defobj.Zone aZone);

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public native Object create (swarm.defobj.Zone aZone);

/**
 *  The customizeCopy: message creates a new copy of the interim object returned by customizeBegin: which may be used for further customizations that do not affect the customization already in progress.  It may be used to branch off a path of a customization in progress to create an alternate final customization.  customizeCopy may be used only on an interim object returned by customizeBegin: and not yet finalized by customizeEnd.  The new version of the interim object being customized may be allocated in the same or different zone as the original version, using the zone argument required by customizeCopy:
 */
public native Object customizeCopy (Object aZone);

/**
 *  Returns the new, customized version of the original type.
 */
public native Object customizeEnd ();

/**
 *  Returns an interim value for receiving create-time messages much like createBegin:. The zone passed to customizeBegin: is the same zone from which storage for the new, finalized type object will be taken.  This zone need not be the same as any instance later created from that type, since a new zone argument is still passed in any subsequent create message on that type.
 */
public native Object customizeBegin (Object aZone);

/**
 *  The setAlpha:setBeta: method sets the alpha and beta values for the gamma distribution.
 */
public native Object setAlpha$setBeta (double alpha, double beta);

/**
 *  The reset method resets the currentCount and other state data.
 */
public native Object reset ();

/**
 *  Use this message if the generator to be attached is a Simple one:
 */
public native Object setGenerator (SimpleRandomGenerator simpleGenerator);

/**
 *  Use this message if the generator to be attached is a Split one:
 */
public native Object setGenerator$setVirtualGenerator (SplitRandomGenerator splitGenerator, int vGen);
public GammaDistCImpl (GammaDist nextPhase) { super (); this.nextPhase = nextPhase; }
public GammaDistCImpl () {super ();}
}
