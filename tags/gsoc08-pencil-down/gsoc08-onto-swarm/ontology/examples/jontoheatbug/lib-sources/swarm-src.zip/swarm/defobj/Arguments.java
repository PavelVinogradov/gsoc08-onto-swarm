package swarm.defobj;

/**
 * <strong> A class that provides customizable command line argument parsing support</strong>.

 A class that provides customizable command line argument parsing support
 */
public interface Arguments extends Create, CreateS, Drop, DropS {

/**
 * 
 */
boolean getBatchModeFlag ();

/**
 * 
 */
boolean getVarySeedFlag ();

/**
 * 
 */
boolean getFixedSeedFlag ();

/**
 * 
 */
int getFixedSeed ();

/**
 * 
 */
boolean getVerboseFlag ();

/**
 * 
 */
java.lang.String getAppName ();

/**
 * 
 */
java.lang.String getAppModeString ();

/**
 * 
 */
int getArgc ();

/**
 * 
 */
int getLastArgIndex ();

/**
 * 
 */
java.lang.String getExecutablePath ();

/**
 * 
 */
java.lang.String getSwarmHome ();

/**
 * 
 */
java.lang.String getConfigPath ();

/**
 * 
 */
java.lang.String getDataPath ();

/**
 *  A path where application-specific data files can be expected to be found.
 */
java.lang.String getAppDataPath ();

/**
 *  A path where application-specific configuration files can be expected to be found.
 */
java.lang.String getAppConfigPath ();

/**
 * 
 */
boolean getShowCurrentTimeFlag ();

/**
 * 
 */
boolean getInhibitArchiverLoadFlag ();
}
