package swarm.defobj;

/**
 * <strong> Modular unit of storage allocation.</strong>.

 A zone is a source of storage for objects or other allocated data. Whenever a new object is created, a zone must be identified from which the storage for its instance variables, or other internal data, is obtained.  A program may establish multiple zones to ensure that objects with similar lifetime or storage needs are allocated together, and in general to optimize allocation and reuse of storage. Zones also maintain a collection of all objects allocated within the zone.  This collection, referred to as the "population" of a zone, is a set of all objects which have been created but not yet dropped within the zone.  Collections maintained automatically by zones can eliminate a need for other, separately maintained collections in applications that need to keep track of entire populations of objects. Collections of allocated objects can provide support for object query, external object storage, and automatic storage reclamation. A zone may be used to obtain storage not only for objects, but also for raw storage blocks like those provided by the C malloc function. All objects and storage blocks allocated in a zone remain local to that zone.  This means that allocation of storage in other zones does not affect the efficiency of storage allocation within a particular zone.  For most zone types, individual allocations may still be freed within a zone, and total storage of a zone may grow and shrink according to aggregate needs.  In addition to freeing individual allocations, an entire zone may also dropped.  Dropping a zone automatically frees all object allocations made within it, including final drop processing on any allocated objects that need it.  Release of an entire zone can be much faster than individual release of each object within it. The Zone type is a fully implemented type that provides default storage management support for objects and other allocated storage. It is also a supertype for other zones that implement alternative policies for use in specialized situations. A zone is created using standard create messages just like other objects.  This means that a zone must identify another zone from which it obtains its storage.  Storage is typically obtained from this other zone in large units called pages, which are then managed by the local zone to support internal allocations.  The getZone message of the DefinedObject type returns the zone which provides these base pages. Since a new zone always requires that an existing zone be identified, no new zones could be created unless there were some zones that already existed.  Two such zones are predefined as part of the defobj library: globalZone and scratchZone.
 */
public class ZoneImpl extends swarm.BaseImpl implements Create, CreateS, Drop, DropS, ZoneS, Zone {


/**
 *  Generate debug id description for each member of the zone population.
 */
public native void describeForEachID (Object outputCharStream);

/**
 *  Generate debug description for each member of the zone population.
 */
public native void describeForEach (Object outputCharStream);

/**
 *  getPopulation returns a collection all objects allocated in a zone using either allocIVars: or copyIVars: and not yet freed using freeIVars:.  getObjects returns nil if the ObjectCollection option is false.  The collection returned has the type OrderedSet as defined in the collections library, with the ReadOnly option set true and the IndexSafety option set to SafeAlways.  The members of this collection may change as objects are allocated and freed, but may not added or removed directly within the collection.
 */
public native swarm.collections.List getPopulation ();

/**
 *  Returns a specially qualified version of the zone that automatically allocates all its objects with the internal component qualification, even if allocated with allocIVars: or copyIVars:.  This qualified zone may be passed as an argument to a create: or createBegin: message so that it will create the new object as an internal component object.
 */
public native Object getComponentZone ();

/**
 *  Frees the instance variable storage for an object.
 */
public native void freeIVarsComponent (Object anObject);

/**
 *  Like allocateIVarsComponent, except it copies the storage that holds the instances variables for an object.
 */
public native Object copyIVarsComponent (Object anObject);

/**
 *  These messages allocate, copy, and free This message allocates the storage that holds the instance variables for an object.  It allocates the object as an internal component of the zone that is not included in the zone population.  It is used by classes that allocate additional objects as part of the implementation of another object, and that control the mapping of this storage separately from the zone level objects.
 */
public native Object allocIVarsComponent (Class aClass);

/**
 *  freeIVars: releases storage that was previously allocated to hold the instance variable structure of an object.  The first word of the object must be a class pointer that correctly describes the size of the structure.  Storage allocated by allocIVars: or copyIVars: may be freed only by freeIVars:, and freeIVars: may be used only to free storage allocated by one of these messages.
 */
public native void freeIVars (Object anObject);

/**
 *  copyIVars: creates copies an existing instance variable structure into a new allocation made within the local zone.  The existing instance variable structure may be in any zone, but must contain a class pointer in its first word that correctly describes the size of the structure.
 */
public native Object copyIVars (Object anObject);

/**
 *  allocIVars: allocates the instance variable structure for a new object.  The initial word of this structure is set to class id passed as its argument.  The class also determines the size of the structure allocated.  All remaining contents of this structure are initialized to binary zeroes.
 */
public native Object allocIVars (Class aClass);

/**
 * 
 */
public native int getPageSize ();

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();
public ZoneImpl () {
  super ();
}

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public ZoneImpl (Zone aZone) { super (); new ZoneCImpl (this).create (aZone); }
}
