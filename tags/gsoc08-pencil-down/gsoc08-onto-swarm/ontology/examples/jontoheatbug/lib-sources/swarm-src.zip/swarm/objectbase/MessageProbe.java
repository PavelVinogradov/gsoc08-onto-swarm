package swarm.objectbase;

/**
 * <strong> A class that allows the user to call a given message on any candidate that is an instance of, or inherits from, a given class.</strong>.

 This is a specialized subclass of the abstract class Probe. It completes the specification of a probe that refers to a message element of an object. 
 */
public interface MessageProbe extends Probe, ProbeS {

/**
 *  The isResultId method returns 1 if the return value of the message is of type object, and returns 0 otherwise.
 */
boolean isResultId ();

/**
 *  The isArgumentId: method returns 1 if a given argument of the message is of type object, and returns 0 otherwise.
 */
boolean isArgumentId (int which);

/**
 *  The getProbedMessage method returns the string matching the identifier of the message being probed.
 */
java.lang.String getProbedMessage ();

/**
 * 
 */
int getArgCount ();

/**
 *  The getArgName: method returns a string representation of the argument key with the given index.
 */
java.lang.String getArgName (int which);

/**
 *  The getHideResult method returns 1 if the result field is "hidden".
 */
boolean getHideResult ();

/**
 *  The setArg:ToString: method sets the nth argument of the message.  The argument must be provided in string form.
 */
Object setArg$ToString (int which, java.lang.String what);

/**
 *  The setArg:ToUnsigned: method sets the nth argument of the message  used by the probe to an unsigned integer value.  The user is  responsible for matching the unsigned integer type of this  argument with the argument type of the method being probed.
 */
Object setArg$ToUnsigned (int which, int x);

/**
 *  The doubleDynamicCallOn: method generates a dynamic message call on the  target object. This method assumes the user knows the type to be numeric and would like a direct translation into type double.
 */
double doubleDynamicCallOn (Object target);

/**
 *  The longDynamicCallOn: method generates a dynamic message call on the  target object. This method assumes the user knows the return  type to be numeric and would like a direct translation into type logn.
 */
int longDynamicCallOn (Object target);

/**
 *  The stringDynamicCallOn: method generates a dynamic message call on the  target object. This method assumes the user knows the return type to be  const char *.
 */
java.lang.String stringDynamicCallOn (Object target);

/**
 *  The objectDynamicCallOn: method generates a dynamic message call on the  target object. This method assumes the user knows the return type to be  id.
 */
Object objectDynamicCallOn (Object target);
}
