package swarm.activity;

/**
 * <strong> Declare an internal method for getCurrentAction().</strong>.

 Declare an internal method for getCurrentAction().
 */
public interface GetSubactivityAction  {
}
