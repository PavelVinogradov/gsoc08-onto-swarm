package swarm.collections;

/**
 * <strong>  Collection of members in an externally assigned linear sequence.</strong>.

 A list is a collection of members that are all maintained at some externally assigned position in a linear sequence of all members.  The sequence is established by the position at which members are added: members can be added at the start of list, at the end, or at any point in the middle. A list is also one of the most dynamic of basic collections, in that the cost of adding and removing members is very low.  Members can be removed from any position just as easily as they can be added.  A list automatically grows and shrinks to reflect the number of members at any one time, and there is no fixed capacity which limits the size to which a list may grow. The List type is supports all messages of Collection.  If created with default options, it provides no special speedup of accesses by integer offset.
 */
public interface ListS extends CollectionS, swarm.defobj.SerializationS {
}
