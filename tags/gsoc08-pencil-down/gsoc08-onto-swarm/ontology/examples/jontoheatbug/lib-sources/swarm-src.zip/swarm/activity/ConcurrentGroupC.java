package swarm.activity;

/**
 * <strong> Default type used as concurrent group of a schedule.</strong>.

 Default type used as concurrent group of a schedule.
 */
public interface ConcurrentGroupC extends ActionGroupC, ActionGroupS {
}
