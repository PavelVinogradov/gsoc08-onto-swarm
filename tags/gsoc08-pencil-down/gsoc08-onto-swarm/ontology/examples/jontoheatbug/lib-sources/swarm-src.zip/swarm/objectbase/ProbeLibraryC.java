package swarm.objectbase;

/**
 * <strong> A (singleton) Class, whose instance is used as a container for a global mapping between classnames and their 'default' ProbeMaps. These defaults can be changed by the user, thus allowing him/her to customize the default contents of the ProbeDisplays generated when probing objects.</strong>.

 The normal Swarm simulation will probably only ever contain one instance  of this class, namely the probeLibrary object. This object is used for Library Generation of Probes and ProbeMaps: its role is to cache one  unique "official" ProbeMap for every Class ever probed during a run of Swarm. These ProbeMaps are generated as they are requested. 
 */
public interface ProbeLibraryC extends swarm.defobj.CreateC, swarm.defobj.CreateS, swarm.defobj.DropC, swarm.defobj.DropS, ProbeConfigC, ProbeConfigS {
}
