package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A collection of started subactivities.</strong>.

 A collection of started subactivities.
 * @hide
 */
public class SwarmActivityCImpl extends swarm.PhaseCImpl implements ScheduleActivityC, ScheduleActivityS, SwarmActivityS, SwarmActivityC {
}
