package swarm.defobj;

/**
 * <strong> Object serialization protocol.</strong>.

 Object serialization protocol.
 */
public interface SerializationC  {

/**
 *  Process keyword parameters in expression in order to get  create-time parameters.
 */
Object lispInCreate (Object expr);

/**
 *  Process HDF5 object to set create-time parameters.
 */
Object hdf5InCreate (HDF5 hdf5Obj);
}
