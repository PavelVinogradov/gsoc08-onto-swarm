package swarm.objectbase;

/**
 * <strong> A superclass of most objects in a Swarm simulation that provides support for probing.</strong>.

 A SwarmObject is an object that is intended to be a member of a Swarm.  It's behavior will be perpetuated by messages sent from the schedule  of events defined in the context of  Swarm object.  The SwarmObject is where the models of all the agents of a simulation will reside. Hence, most of the burden on defining the messages that can be sent to any agent lies with the user. SwarmObject inherits its basic functionality from the Create and Drop object types defined in the defobj library. 
 */
public interface SwarmObjectC extends swarm.defobj.CreateC, swarm.defobj.CreateS, swarm.defobj.DropC, swarm.defobj.DropS {
}
