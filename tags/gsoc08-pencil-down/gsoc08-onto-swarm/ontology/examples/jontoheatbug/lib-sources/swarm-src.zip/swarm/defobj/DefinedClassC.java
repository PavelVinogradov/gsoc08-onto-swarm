package swarm.defobj;

/**
 * <strong> Class which implements an interface of a type.</strong>.

 Class which implements an interface of a type.
 */
public interface DefinedClassC extends DefinedObjectC, DefinedObjectS {
}
