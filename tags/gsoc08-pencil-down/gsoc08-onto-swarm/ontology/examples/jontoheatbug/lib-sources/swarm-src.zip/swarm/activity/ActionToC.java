package swarm.activity;

/**
 * <strong> An action defined by sending an Objective C message.</strong>.

 An action defined by sending an Objective C message.
 */
public interface ActionToC extends ActionC, ActionS, ActionTargetC, ActionTargetS, ActionSelectorC, ActionSelectorS, ActionArgsC, ActionArgsS {
}
