package swarm.defobj;

/**
 * <strong> A condition of possible concern to a program developer.</strong>.

 A condition of possible concern to a program developer.
 */
public interface Warning extends EventType, EventTypeS {

/**
 *  Associate a message string with this warning.
 */
void setMessageString (java.lang.String messageString);

/**
 *  Return the message associated with this warning.
 */
java.lang.String getMessageString ();
}
