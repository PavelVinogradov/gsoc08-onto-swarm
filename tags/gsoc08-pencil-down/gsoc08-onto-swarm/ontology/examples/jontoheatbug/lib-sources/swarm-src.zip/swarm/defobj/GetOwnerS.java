package swarm.defobj;

/**
 * <strong> Get object on which existence of object depends.</strong>.

 Ownership hierarchies arrange themselves in a strict, single-rooted tree.  The top-level node of an ownership hierarchy typically returns nil as its owner.  If an object is regarded merely as one part of another object defined as its owner, then copying or dropping the owner object should copy or drop the member object as well.  Owner and member are neutral terms for a generic relationship sometimes called parent vs.  child, but it is up to a particular object type to define specifically what it means by a getOwner relationship.
 */
public interface GetOwnerS  {
}
