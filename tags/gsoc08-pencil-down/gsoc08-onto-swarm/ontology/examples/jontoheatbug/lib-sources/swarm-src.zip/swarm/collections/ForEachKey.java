package swarm.collections;

/**
 * <strong> Exactly the same as the ForEach protocol, but only for KeyedCollections.</strong>.

 Works identically to the ForEach protocol, but loops through the keys in a KeyedCollection, rather than the members.
 */
public interface ForEachKey  {

/**
 * 
 */
void forEachKey (swarm.Selector aSelector);

/**
 * 
 */
void forEachKey (swarm.Selector aSelector, Object arg1);

/**
 * 
 */
void forEachKey (swarm.Selector aSelector, Object arg1, Object arg2);

/**
 * 
 */
void forEachKey (swarm.Selector aSelector, Object arg1, Object arg2, Object arg3);
}
