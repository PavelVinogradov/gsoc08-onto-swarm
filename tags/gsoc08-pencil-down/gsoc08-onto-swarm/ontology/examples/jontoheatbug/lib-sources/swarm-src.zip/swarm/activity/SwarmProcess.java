package swarm.activity;

/**
 * <strong> An object that holds a collection of concurrent subprocesses.</strong>.

 SwarmProcess inherits the messages of both ActionType and Zone. Inheritance of zone behavior means that a swarm can be used as the argument of a create: or createBegin: message, for creation of an object within the internal zone of a swarm. Unlike other action types, swarms and swarm activities always exist in a one-to-one relationship, provided that the swarm has been activated. This restriction to a single activity enables the swarm to do double-duty as a custom object that provides its own interface to the activities running within the swarm.
 */
public interface SwarmProcess extends ActionType, ActionTypeS, swarm.defobj.Zone, swarm.defobj.ZoneS, SynchronizationType, SynchronizationTypeS {

/**
 *  getInternalZone returns a Zone object that is used by the swarm to hold its internal objects.  Even though the swarm itself inherits from Zone and can be used as a Zone for nearly all purposes, this message is also provided so that the zone itself can be obtained independent of all zone behavior.
 */
Object getInternalZone ();

/**
 *  getActivity returns the activity which is currently running of subactivities within the swarm.  This activity is the same as the value returned by activateIn: when the swarm was first activated.  It returns nil if the swarm has not yet been activated.
 */
SwarmActivity getActivity ();
}
