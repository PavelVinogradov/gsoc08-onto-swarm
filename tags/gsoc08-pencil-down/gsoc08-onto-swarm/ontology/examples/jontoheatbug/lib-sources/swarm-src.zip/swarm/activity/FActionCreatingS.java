package swarm.activity;

/**
 * <strong> An action that calls a FCall.</strong>.

 The createFAction: message creates an action that runs a FCall closure.
 */
public interface FActionCreatingS  {
}
