package swarm.activity;

/**
 * <strong> An action defined by sending a message to every member of a collection.</strong>.

 An action defined by sending a message to every member of a collection.
 */
public interface ActionForEachC extends ActionToC, ActionToS, DefaultOrderC, DefaultOrderS {
}
