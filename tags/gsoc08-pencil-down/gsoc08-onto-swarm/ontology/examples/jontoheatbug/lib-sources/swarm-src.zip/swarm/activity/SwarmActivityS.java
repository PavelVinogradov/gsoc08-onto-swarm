package swarm.activity;

/**
 * <strong> A collection of started subactivities.</strong>.

 A collection of started subactivities.
 */
public interface SwarmActivityS extends ScheduleActivityS {
}
