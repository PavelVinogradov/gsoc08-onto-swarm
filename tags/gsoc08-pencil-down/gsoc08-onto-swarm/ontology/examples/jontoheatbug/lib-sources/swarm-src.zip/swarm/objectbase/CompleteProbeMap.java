package swarm.objectbase;

/**
 * <strong> A subclass of ProbeMap whose initial state contains the VarProbes and MessageProbes of the requested target class but also those of all its subclasses.</strong>.

 Upon creation, this subclass of the ProbeMap will contain all the  variables and all the messages of a given class (including the inherited ones). 
 */
public interface CompleteProbeMap extends ProbeMap, ProbeMapS {
}
