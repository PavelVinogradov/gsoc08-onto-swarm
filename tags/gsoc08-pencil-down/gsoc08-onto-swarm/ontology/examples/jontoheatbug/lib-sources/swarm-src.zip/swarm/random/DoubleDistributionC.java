package swarm.random;

/**
 * <strong> Double Distribution </strong>.

 A probability distribution that returns an approximation of continuous values as represented by double-precision floating point values.
 */
public interface DoubleDistributionC extends ProbabilityDistributionC, ProbabilityDistributionS {
}
