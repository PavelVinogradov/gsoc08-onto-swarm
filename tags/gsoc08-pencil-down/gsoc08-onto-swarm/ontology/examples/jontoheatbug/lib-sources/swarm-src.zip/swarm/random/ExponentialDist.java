package swarm.random;

/**
 * <strong> Exponential distribuiton </strong>.

 A well-known continuous probability distribution returning doubles.
 */
public interface ExponentialDist extends DoubleDistribution, DoubleDistributionS {

/**
 *  The getMean method returns the mean of the distribution.
 */
double getMean ();

/**
 *  The getSampleWithMean: method returns a sample value from a distribution with the specified mean.
 */
double getSampleWithMean (double mean);
}
