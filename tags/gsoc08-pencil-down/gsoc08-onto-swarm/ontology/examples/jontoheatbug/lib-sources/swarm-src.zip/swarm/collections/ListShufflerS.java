package swarm.collections;

/**
 * <strong> A class to randomize the order of a given Swarm List</strong>.

 ListShuffler randomizes the order of the elements in a List;  either the whole list or the num lowest elements. The list must be supplied. An uniform distribution can be supplied, or the system- supplied uniformUnsRand is used. The algorithm is from Knuth. All these methods modify the underlying collection, so any indexes should always be regenerated. 
 */
public interface ListShufflerS extends swarm.defobj.CreateS, swarm.defobj.DropS {
}
