package swarm.activity;

/**
 * <strong> State of execution within a ForEach action.</strong>.

 State of execution within a ForEach action.
 */
public interface ForEachActivityS extends ActivityS {
}
