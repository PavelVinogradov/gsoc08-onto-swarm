package swarm.objectbase;

/**
 * <strong> A class that provides an object interface to an activity.</strong>.

 The ActivityControl class specifies an object that can be attached to  an activity (regardless of how or where that activity is created) for the purpose of explicitly controlling the execution of actions on that  activity's action plan. There is nothing that available through this  class that is not already available through the variables or messages  available via the activity itself. However, it packages up the main  control messages and makes them available to other objects that may need  control over an activity, thereby shielding the activity from directly receiving messages from outside objects and saving the user from having  to parse the more complex interface to the activity. 
 */
public interface ActivityControlC extends SwarmObjectC, SwarmObjectS {
}
