package swarm;

/**
 * <strong> Container object for Swarm globals</strong>.

 Container object for Swarm globals
 */
public interface SwarmEnvironmentS  {
}
