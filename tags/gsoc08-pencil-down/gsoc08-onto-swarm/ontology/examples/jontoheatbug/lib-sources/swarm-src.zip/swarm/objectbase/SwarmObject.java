package swarm.objectbase;

/**
 * <strong> A superclass of most objects in a Swarm simulation that provides support for probing.</strong>.

 A SwarmObject is an object that is intended to be a member of a Swarm.  It's behavior will be perpetuated by messages sent from the schedule  of events defined in the context of  Swarm object.  The SwarmObject is where the models of all the agents of a simulation will reside. Hence, most of the burden on defining the messages that can be sent to any agent lies with the user. SwarmObject inherits its basic functionality from the Create and Drop object types defined in the defobj library. 
 */
public interface SwarmObject extends swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.Drop, swarm.defobj.DropS {

/**
 *  The getProbeMap method returns a pointer to the ProbeMap for the object if there has been one creaded for that object's class. If it hasn't been created, then it creates a default ProbeMap.
 */
ProbeMap getProbeMap ();

/**
 *  The getCompleteProbeMap method returns a newly created CompleteProbeMap for an object. 
 */
ProbeMap getCompleteProbeMap ();

/**
 *  The getProbeForVariable: method returns the VarProbe indexed in the ProbeMap by the string aVariable.
 */
VarProbe getProbeForVariable (java.lang.String aVariable);

/**
 *  The getProbeForMessage: method returns the MessageProbe indexed in the ProbeMap by the string aMessage.
 */
MessageProbe getProbeForMessage (java.lang.String aMessage);
}
