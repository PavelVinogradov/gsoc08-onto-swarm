package swarm.activity;

/**
 * <strong> Handle actions scheduled at same time value.</strong>.

 The ConcurrentGroupType option is used to control handling of multiple actions which end up being scheduled at the same time value.  As far the schedule representation is concerned, these actions are assumed by default to be concurrently executable, and the processing machinery is free to process them as such if no ConcurrentGroupType option is specified. If a different interpretation of actions at the same time step is needed, the ConcurrentGroupType option may be specified.  The argument of this option must be an object that when given a standard create: message will return an object having all the structure of a standard ActionGroup object. In addition to overriding the standard ActionGroup type, the concurrent group type may be implemented by a custom subclass of the ActionGroup implementation which you supply yourself.  A custom subclass is free to implement custom rules for how to combine all the actions which happen to arrive at the same time value.  For example, it could decide that some actions are not to be executed at all, or it could create entirely new actions to be executed instead of or in addition to those which were originally scheduled. (.. Specific rules for writing a custom ActionGroup subclass will be documented at a future time, but all the apparatus to do so is present today.  A concurrent action group is currently used to maintain the proper order of execution among subswarms of an owner swarm.)
 */
public interface ConcurrentGroupType  {

/**
 * 
 */
Object getConcurrentGroupType ();
}
