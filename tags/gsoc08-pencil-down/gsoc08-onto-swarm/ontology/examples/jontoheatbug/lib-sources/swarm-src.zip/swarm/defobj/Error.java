package swarm.defobj;

/**
 * <strong> A condition which prevents further execution.</strong>.

 A condition which prevents further execution.
 */
public interface Error extends Warning, WarningS {
}
