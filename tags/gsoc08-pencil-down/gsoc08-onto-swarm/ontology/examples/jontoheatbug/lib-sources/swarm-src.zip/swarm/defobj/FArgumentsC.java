package swarm.defobj;

/**
 * <strong> A language independent interface to dynamic call argument construction.</strong>.

 A language independent interface to dynamic call argument construction.
 */
public interface FArgumentsC extends CreateC, CreateS, DropC, DropS {

/**
 * 
 */
Object setLanguage (Symbol languageType);

/**
 *  The selector is used to set argument types.  Some languages won't have any, and so for those languages this need not be called.
 */
Object setSelector (swarm.Selector aSel);

/**
 * 
 */
Object setJavaSignature (java.lang.String javaSignature);

/**
 * 
 */
Object create$setSelector (Zone aZone, swarm.Selector aSel);

/**
 * 
 */
Object addChar (char value);

/**
 * 
 */
Object addBoolean (boolean value);

/**
 * 
 */
Object addUnsignedChar (byte value);

/**
 * 
 */
Object addShort (short value);

/**
 * 
 */
Object addUnsignedShort (short value);

/**
 * 
 */
Object addInt (int value);

/**
 * 
 */
Object addUnsigned (int value);

/**
 * 
 */
Object addLong (int value);

/**
 * 
 */
Object addUnsignedLong (int value);

/**
 * 
 */
Object addLongLong (long value);

/**
 * 
 */
Object addUnsignedLongLong (long value);

/**
 * 
 */
Object addFloat (float value);

/**
 * 
 */
Object addDouble (double value);

/**
 * 
 */
Object addString (java.lang.String value);

/**
 * 
 */
void addObject (Object obj);

/**
 * 
 */
Object addSelector (swarm.Selector aSel);

/**
 * 
 */
Object addJavaObject (Object obj);

/**
 * 
 */
Object setObjCReturnType (char type);

/**
 * 
 */
Object setBooleanReturnType ();
}
