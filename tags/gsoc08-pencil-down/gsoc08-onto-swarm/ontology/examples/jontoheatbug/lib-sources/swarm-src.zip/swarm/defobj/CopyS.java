package swarm.defobj;

/**
 * <strong> Copy all state defined as part of object.</strong>.

 An object type that supplies the copy operation defines what it includes as the contents of an object copied.  There is no global rule for what is considered "inside" a copied object vs. merely referenced by it.  (There is no fixed notion of "shallow" vs. "deep" copy found in some object libraries.)  After copying, the new object may still contain some references to other elements also referenced by the starting object, but in general the new object minimizes any dependencies shared with the starting object.  Any object type supplying the copy message should also supply documentation on its rules for copied objects.
 */
public interface CopyS  {
}
