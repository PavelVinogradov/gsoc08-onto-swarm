package swarm.activity;

/**
 * <strong> An action generated when two or more actions co-occur.</strong>.

 An action generated when two or more actions co-occur.
 */
public interface ActionConcurrent extends Action, ActionS {

/**
 * 
 */
ActionGroup getConcurrentGroup ();
}
