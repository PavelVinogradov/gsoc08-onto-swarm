package swarm.objectbase;

/**
 * <strong> An abstract superclass of both VarProbe and MessageProbe.</strong>.

 A Probe is simply an object that contains pointers to an element  (instance variable or message description) of another object. The Probe contains instance variables that describe the referent's class and type.  It's actually an abstract class that is further subdivided into VarProbe and MessageProbe, which represent the two basic types of  elements of any object. The Probes are collected into a ProbeMap and subsequently installed in the ProbeLibrary. 
 */
public interface ProbeC extends SwarmObjectC, SwarmObjectS, ProbeConfigC, ProbeConfigS {

/**
 *  The setProbedClass: method sets the class of the object the probe points at and must be called at create time.
 */
Object setProbedClass (Class class_);

/**
 * 
 */
Object setProbedObject (Object object);
}
