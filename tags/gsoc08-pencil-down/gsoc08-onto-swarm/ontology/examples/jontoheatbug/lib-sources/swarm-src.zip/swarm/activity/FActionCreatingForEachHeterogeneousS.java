package swarm.activity;

/**
 * <strong> Invoke a FCall for every item in the target collection, which can include objects of various types.</strong>.

 Invoke a FCall for every item in the target collection, which can include objects of various types.
 */
public interface FActionCreatingForEachHeterogeneousS  {
}
