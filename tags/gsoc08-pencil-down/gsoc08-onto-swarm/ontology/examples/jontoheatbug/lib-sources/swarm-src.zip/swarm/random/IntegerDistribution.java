package swarm.random;

/**
 * <strong> Integer Distribution </strong>.

 A probability distribution that returns integer sample values.
 */
public interface IntegerDistribution extends ProbabilityDistribution, ProbabilityDistributionS {

/**
 *  The getIntegerSample method returns an integer sample value.
 */
int getIntegerSample ();
}
