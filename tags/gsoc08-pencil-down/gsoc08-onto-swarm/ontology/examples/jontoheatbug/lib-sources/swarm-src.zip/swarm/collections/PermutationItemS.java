package swarm.collections;

/**
 * <strong> An element of a Permutation</strong>.

 An element of a Permutation
 */
public interface PermutationItemS extends swarm.defobj.CreateS {
}
