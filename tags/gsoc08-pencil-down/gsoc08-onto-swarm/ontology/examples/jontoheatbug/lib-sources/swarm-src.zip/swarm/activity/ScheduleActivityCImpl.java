package swarm.activity;
import swarm.defobj.ZoneImpl;
/**
 * <strong> State of execution within a Schedule.</strong>.

 State of execution within a Schedule.
 * @hide
 */
public class ScheduleActivityCImpl extends swarm.PhaseCImpl implements ActivityC, ActivityS, ScheduleActivityS, ScheduleActivityC {
}
