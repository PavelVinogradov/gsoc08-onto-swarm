package swarm.random;

/**
 * <strong> Boolean Distribution</strong>.

 A probability distribution that returns YES/NO sample values.
 */
public interface BooleanDistributionC extends ProbabilityDistributionC, ProbabilityDistributionS {
}
