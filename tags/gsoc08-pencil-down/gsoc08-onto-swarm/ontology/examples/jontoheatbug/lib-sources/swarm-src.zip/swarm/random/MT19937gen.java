package swarm.random;

/**
 * <strong> 'Mersenne Twister' Twisted GFSR generator</strong>.

  This generator has a single cycle of length 2^19937-1.
 */
public interface MT19937gen extends SimpleRandomGenerator, SimpleRandomGeneratorS {
}
