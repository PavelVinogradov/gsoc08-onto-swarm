package swarm.defobj;

/**
 * <strong> HDF5 interface</strong>.

 HDF5 interface
 */
public interface HDF5 extends Create, CreateS, Drop, DropS {

/**
 * 
 */
boolean getDatasetFlag ();

/**
 * 
 */
boolean getWriteFlag ();

/**
 * 
 */
int getDatasetRank ();

/**
 * 
 */
int getDatasetDimension (int dimNumber);

/**
 * 
 */
int getCount ();

/**
 * 
 */
java.lang.String getHDF5Name ();

/**
 * 
 */
Object getCompoundType ();

/**
 * 
 */
void assignIvar (Object obj);

/**
 * 
 */
boolean checkName (java.lang.String name);

/**
 * 
 */
boolean checkDatasetName (java.lang.String datasetName);

/**
 * 
 */
void addDoubleToVector (double val);

/**
 * 
 */
void storeTypeName (java.lang.String typeName);

/**
 * 
 */
void storeComponentTypeName (java.lang.String typeName);

/**
 * 
 */
void shallowLoadObject (Object obj);

/**
 * 
 */
void shallowStoreObject (Object obj);

/**
 * 
 */
void nameRecord$name (int recordNumber, java.lang.String recordName);

/**
 * 
 */
void numberRecord (int recordNumber);

/**
 * 
 */
void selectRecord (int recordNumber);

/**
 * 
 */
void writeRowNames ();

/**
 * 
 */
void writeLevels ();

/**
 * 
 */
void storeAttribute$value (java.lang.String attributeName, java.lang.String valueString);

/**
 * 
 */
java.lang.String getAttribute (java.lang.String attributeName);

/**
 * 
 */
void flush ();
}
