package swarm.random;

/**
 * <strong> Internal</strong>.


 */
public interface CommonGeneratorS  {

/**
 *  The setStateFromSeed method initializes the seed dependent part of the  state from a single seed value.
 */
Object setStateFromSeed (int seed);

/**
 *  The setAntithetic method turns on or off antithetic output (default=off). Antithetic output is (unsignedMax - u) or (1.0 - d).
 */
Object setAntithetic (boolean antiT);
}
