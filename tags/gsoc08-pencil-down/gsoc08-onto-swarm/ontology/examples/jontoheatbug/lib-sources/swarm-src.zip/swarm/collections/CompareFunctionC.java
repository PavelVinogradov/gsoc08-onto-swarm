package swarm.collections;

/**
 * <strong> Interface for defining the compare function to use when comparing to members in a collection.</strong>.

 The function given will be called whenever one key value needs to be compared with another.  Multiple calls to the function typically occur whenever members are added or removed from the collection, until the correct member for insertion or removal is determined. The compare function is called repeatedly by the collection to compare two key values.  The function should return zero if the key values are equal, -1 for the first key argument less than the second, and +1 for the first greater than the second.  If a keyed collection is not sorted, either -1 or +1 may be returned for unequal keys, regardless of whether one might be taken as greater or less than the other.
 */
public interface CompareFunctionC  {

/**
 * 
 */
Object setCompareCStrings ();

/**
 * 
 */
Object setCompareIDs ();

/**
 * 
 */
Object setCompareIntegers ();

/**
 * 
 */
Object setCompareUnsignedIntegers ();
}
