package swarm.objectbase;

/**
 * <strong> A class that allows the user to inspect a given variable in any candidate that is an instance of, or inherits from, a given class.</strong>.

 This is a specialized subclass of the abstract class Probe. It completes the specification of a probe that refers to an instance variable element of an object. 
 */
public interface VarProbeS extends ProbeS {

/**
 *  The setNonInteractive method sets a VarProbe to be non-interactive. This ensures that the user will not be able to change the value of a probe, only observe it.  Setting the VarProbe to be non-interactive will not interfere with the drag and drop capability of the objects into the VarProbe field.
 */
Object setNonInteractive ();

/**
 *  The setStringReturnType: method sets the format that will be used to print the variable.  When the probedVariable is of type unsigned char or char, the method probeAsString will, by default, return a string of the format: "'%c' %d".  This is meant to reflect the commonplace use of an unsigned char as a small int.
 */
Object setStringReturnType (Object returnType);

/**
 *  The setFloatFormat: method sets the floating-point format of a GUI display widget when given a sprintf-style formatting string.
 */
Object setFloatFormat (java.lang.String format);
}
