package swarm.random;

/**
 * <strong> Bernoulli Distribution </strong>.

 A distribution returning YES with a given probability.
 */
public interface BernoulliDistC extends BooleanDistributionC, BooleanDistributionS {

/**
 *  Use this create message if the generator to be attached is a Simple one:
 */
Object create$setGenerator$setProbability (swarm.defobj.Zone aZone, SimpleRandomGenerator simpleGenerator, double p);

/**
 *  Use this create message if the generator to be attached is a Split one:
 */
Object create$setGenerator$setVirtualGenerator$setProbability (swarm.defobj.Zone aZone, SplitRandomGenerator splitGenerator, int vGen, double p);
}
