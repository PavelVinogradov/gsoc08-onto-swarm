package swarm.random;

/**
 * <strong> Combined Tausworthe generator </strong>.

 This generator is based on 2 component generators of periods 2^31-1 and  2^29-1.
 */
public interface C2TAUSgenS extends SimpleRandomGeneratorS {
}
