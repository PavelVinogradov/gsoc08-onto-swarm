package swarm.defobj;

/**
 * <strong> Class with variables and/or methods defined at runtime.</strong>.

 Class with variables and/or methods defined at runtime.
 */
public interface CreatedClassS extends CreateS, DefinedClassS {
}
