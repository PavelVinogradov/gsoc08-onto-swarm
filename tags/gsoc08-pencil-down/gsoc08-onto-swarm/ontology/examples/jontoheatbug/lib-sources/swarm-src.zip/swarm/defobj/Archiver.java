package swarm.defobj;

/**
 * <strong> High level abstract serialization interface.</strong>.

 High level abstract serialization interface.
 */
public interface Archiver extends Create, CreateS, Drop, DropS {

/**
 * 
 */
void registerClient (Object client);

/**
 * 
 */
void unregisterClient (Object client);

/**
 *  Register with the Archiver a deep serialization of the object (serialization only occurs when Archiver is saved)
 */
void putDeep$object (java.lang.String key, Object object);

/**
 *  As per -putDeep, but only make a shallow version
 */
void putShallow$object (java.lang.String key, Object object);

/**
 *  Create the object with `key' using the Archiver's own Zone
 */
Object getObject (java.lang.String key);

/**
 *  Create the object with `key' in the specified Zone
 */
Object getWithZone$key (Zone aZone, java.lang.String key);

/**
 *  Ensure that that all registered  the requested backend
 */
void sync ();
}
