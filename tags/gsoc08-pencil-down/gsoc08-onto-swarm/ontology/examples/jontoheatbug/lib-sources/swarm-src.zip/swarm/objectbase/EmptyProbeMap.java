package swarm.objectbase;

/**
 * <strong> A CustomProbeMap to be used for building up ProbeMaps from scratch.</strong>.

 A CustomProbeMap to be used for building up ProbeMaps from scratch.
 */
public interface EmptyProbeMap extends CustomProbeMap, CustomProbeMapS {
}
