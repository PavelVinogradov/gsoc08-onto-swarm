package swarm.objectbase;
import swarm.defobj.ZoneImpl;
/**
 * <strong> A (singleton) Class, whose instance is used as a container for a global mapping between classnames and their 'default' ProbeMaps. These defaults can be changed by the user, thus allowing him/her to customize the default contents of the ProbeDisplays generated when probing objects.</strong>.

 The normal Swarm simulation will probably only ever contain one instance  of this class, namely the probeLibrary object. This object is used for Library Generation of Probes and ProbeMaps: its role is to cache one  unique "official" ProbeMap for every Class ever probed during a run of Swarm. These ProbeMaps are generated as they are requested. 
 */
public class ProbeLibraryImpl extends swarm.BaseImpl implements swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.Drop, swarm.defobj.DropS, ProbeConfig, ProbeConfigS, ProbeLibraryS, ProbeLibrary {


/**
 * 
 */
public native Object setProbeMap$ForObject (ProbeMap aMap, Object anObject);

/**
 *  The setProbeMap:For: method sets the standard probe map as the probe map. The returned Probe will be cached as though it was produced by the library itself.
 */
public native Object setProbeMap$For (ProbeMap aMap, Class aClass);

/**
 * 
 */
public native MessageProbe getProbeForMessage$inObject (java.lang.String aMessage, Object anObject);

/**
 *  The getProbeForMessage:inClass: method returns a probe that has been  "checked out" from the appropriate Probes in the probe library.  Note: The returned probe will be cached so to avoid affecting the results        of future requests for the same probes, clone the probe prior to        making modifications to the probe.
 */
public native MessageProbe getProbeForMessage$inClass (java.lang.String aMessage, Class aClass);

/**
 * 
 */
public native VarProbe getProbeForVariable$inObject (java.lang.String aVar, Object anObject);

/**
 *  The getProbeForVariable:inClass: method returns a probe that has been  "checked out" from the appropriate Probes in the probe library.  Note: The returned probe will be cached so to avoid affecting the results        of future requests for the same probes, clone the probe prior to        making modifications to the probe.
 */
public native VarProbe getProbeForVariable$inClass (java.lang.String aVar, Class aClass);

/**
 * 
 */
public native ProbeMap getCompleteVarMapForObject (Object anObject);

/**
 *  The getCompleteVarMapFor: method returns a ProbeMap containing Probes for  all the instance variables of the given Class (including inherited  variables) but does not include any MessageProbes. 
 */
public native ProbeMap getCompleteVarMapFor (Class aClass);

/**
 * 
 */
public native ProbeMap getCompleteProbeMapForObject (Object anObject);

/**
 *  The getCompleteProbeMapFor: method returns a ProbeMap containing Probes  for all the instance variables and messages of the given Class (including  inherited variables and messages). The current implementation of  ProbeLibrary does not cache CompleteProbeMaps. 
 */
public native ProbeMap getCompleteProbeMapFor (Class aClass);

/**
 * 
 */
public native ProbeMap getProbeMapForObject (Object anObject);

/**
 *  The getProbeMapFor: method returns a ProbeMap for the aClass class. If a  specific ProbeMap has been designed and installed in the ProbeLibrary for  that class, then that specific ProbeMap is returned. If a custom ProbeMap  was not designed and installed, then a CompleteProbeMap is created and  returned.
 */
public native ProbeMap getProbeMapFor (Class aClass);

/**
 * 
 */
public native boolean isProbeMapDefinedForObject (Object anObject);

/**
 *  The isProbeMapDefinedFor: method returns True if there is a non-nil value  in the ProbeLibrary for that class and False otherwise.
 */
public native boolean isProbeMapDefinedFor (Class aClass);

/**
 *  The getSavedPrecision method gets the current saved precision set in the  ProbeLibrary instance.
 */
public native int getSavedPrecision ();

/**
 *  The setSavedPrecision: method sets the number of significant digits saved  for floating-point and double floating-point numbers through ObjectSaver.  This function sets the global default precision for all floating point  numbers, including double floating point numbers. This floating point  precision affects all numbers saved via the ObjectSaver class. There is  currently no way to override this global default for an individual probe. 
 */
public native Object setSavedPrecision (int nSigSaved);

/**
 *  The getDisplayPrecision method gets the current display precision set in  the ProbeLibrary instance.
 */
public native int getDisplayPrecision ();

/**
 *  The setDisplayPrecision: method sets the number of significant digits for  floating point and double floating point numbers displayed on GUI widgets. This method is currently only implemented for VarProbes. It has not been  implemented for MessageProbes yet.  The setDisplayPrecision method allows all probes checked out from the  global ProbeLibrary instance to access this displayed precision. However,  individual probes can vary from this global default, by using the  setFloatFormat method on a exisiting probe. 
 */
public native Object setDisplayPrecision (int nSigDisplay);

/**
 * 
 */
public native Object getObjectToNotify ();

/**
 * 
 */
public native Object setObjectToNotify (Object anObject);

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();
public ProbeLibraryImpl () {
  super ();
}

/**
 *  The create: message creates a new instance of a type with default options.  The zone argument specifies the source of storage for the new object.  The receiving object of this message is a previously defined type object.  The message is declared as a class message (with a + declaration tag) to indicate that the message is accepted only by the type object itself rather than an already created instance of the type (which a - declaration tag otherwise defines). The create: message returns the new object just created.  This object is an instance of some class selected to implement the type.  The class which a type selects to implement an object may be obtained by the getClass message, but is not otherwise visible to the calling program. A caller never refers to any class name when creating objects using these messages, only to type names, which are automatically published as global constants from any @protocol declaration. 
 */
public ProbeLibraryImpl (swarm.defobj.Zone aZone) { super (); new ProbeLibraryCImpl (this).create (aZone); }
}
