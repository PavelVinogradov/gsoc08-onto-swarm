package swarm.defobj;

/**
 * <strong> High level abstract serialization interface.</strong>.

 High level abstract serialization interface.
 */
public interface ArchiverS extends CreateS, DropS {
}
