package swarm.random;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Combined Tausworthe generator 2</strong>.

 Component 1 parameters: P = 31, S = 21, Q =  3 Component 2 parameters: P = 29, S = 17, Q =  2 With these parameters, this generator has a single full cycle of  length ~ 2^60.
 */
public class C2TAUS2genImpl extends swarm.BaseImpl implements C2TAUSgen, C2TAUSgenS, C2TAUS2genS, C2TAUS2gen {


/**
 *  The getCurrentCount method returns the count of variates generated.
 */
public native long getCurrentCount ();

/**
 *  The getDoubleSample method returns a random floating point number of size double, uniformly distributed in the range [0.0, 1.0). It uses 2 calls to -getUnsignedSample to fill the mantissa.
 */
public native double getDoubleSample ();

/**
 *  The getThinDoubleSample method returns a random floating point number of size double, uniformly distributed in the range [0.0, 1.0). It uses 1 call to -getUnsignedSample to fill the mantissa.
 */
public native double getThinDoubleSample ();

/**
 *  The getFloatSample method returns a random floating point number of size float, uniformly distributed in the range [0.0, 1.0). It uses 1 call to -getUnsignedSample to fill the mantissa.
 */
public native float getFloatSample ();

/**
 *  The getUnsignedSample method returns a random unsigned integer  uniformly distributed over [0,unsignedMax].
 */
public native int getUnsignedSample ();

/**
 *  The getUnsignedMax method returns the highest value that will ever  be returned by -getUnsignedSample (the lowest is 0).
 */
public native int getUnsignedMax ();

/**
 *  The -reset method sets the generator back to the state it had at start or at the last use of -setStateFromSeed(s). CurrentCount is zeroed.
 */
public native Object reset ();

/**
 *  The lengthOfSeedVector method returns the number of seeds required if you wish to set the state directly.
 */
public native int lengthOfSeedVector ();

/**
 *  The getInitialSeed method returns the value of the generator's  starting seed.
 */
public native int getInitialSeed ();

/**
 *  The getMaxSeedValue method returns the upper limit on the seed value that can be supplied.
 */
public native int getMaxSeedValue ();

/**
 *  The getAntithetic method returns the current values of the parameter.
 */
public native boolean getAntithetic ();

/**
 * 
 */
public native int getMagic ();

/**
 *  Specifies the minimum buffer size needed.
 */
public native int getStateSize ();

/**
 *  The getProbeForMessage: method returns the MessageProbe indexed in the ProbeMap by the string aMessage.
 */
public native swarm.objectbase.MessageProbe getProbeForMessage (java.lang.String aMessage);

/**
 *  The getProbeForVariable: method returns the VarProbe indexed in the ProbeMap by the string aVariable.
 */
public native swarm.objectbase.VarProbe getProbeForVariable (java.lang.String aVariable);

/**
 *  The getCompleteProbeMap method returns a newly created CompleteProbeMap for an object. 
 */
public native swarm.objectbase.ProbeMap getCompleteProbeMap ();

/**
 *  The getProbeMap method returns a pointer to the ProbeMap for the object if there has been one creaded for that object's class. If it hasn't been created, then it creates a default ProbeMap.
 */
public native swarm.objectbase.ProbeMap getProbeMap ();

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();

/**
 *  The setAntithetic method turns on or off antithetic output (default=off). Antithetic output is (unsignedMax - u) or (1.0 - d).
 */
public native Object setAntithetic (boolean antiT);

/**
 *  The setStateFromSeed method initializes the seed dependent part of the  state from a single seed value.
 */
public native Object setStateFromSeed (int seed);
public C2TAUS2genImpl () {
  super ();
}

/**
 * 
 */
public C2TAUS2genImpl (swarm.defobj.Zone aZone, int seed) { super (); new C2TAUS2genCImpl (this).create$setStateFromSeed (aZone, seed); }

/**
 * 
 */
public C2TAUS2genImpl (swarm.defobj.Zone aZone) { super (); new C2TAUS2genCImpl (this).createWithDefaults (aZone); }
}
