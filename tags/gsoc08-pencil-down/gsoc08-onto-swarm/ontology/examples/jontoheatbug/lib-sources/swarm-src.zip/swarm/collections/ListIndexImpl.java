package swarm.collections;
import swarm.defobj.ZoneImpl;
/**
 * <strong> Index with insertion capability at any point in list.</strong>.

 The addAfter: and addBefore: messages add members at a particular point in the sequence of members maintained by a list.  The current location of an index determines the point at which a new member will be added.  The addAfter: message adds a member at the list position immediately following the current index location.  addBefore: adds a member to the immediately preceding location.  Neither message changes the current location of the index, except that an index can change from a Start or End location to a location of Between. Since an index may be positioned to any location in a list, these messages enable the construction of any desired sequence of members. Since the current index location remains unchanged, multiple members may all be inserted successively at some point in a list; previously added members are just pushed out one-by-one as new members are added. An index with a location of Start, End, or Between is just as valid a location for addAfter: or addBefore: as an index positioned at a member.  In these cases, there is no member at the current location of the index, so the new member is just inserted directly at the current index location, and the index is left positioned between the new member and the member that was previously adjacent in the opposite direction.  If the previous location was Start and the message addAfter:, or the location was End and the message addBefore:, the index location remains Start or End.
 * @hide
 */
public class ListIndexImpl extends swarm.BaseImpl implements Index, IndexS, ListIndexS, ListIndex {


/**
 *  Add a member before the index.
 */
public native void addBefore (Object anObject);

/**
 *  Add a member after the index.
 */
public native void addAfter (Object anObject);

/**
 *  Using the setOffset: message, an index may be positioned directly to a member using the offset of the member within its enumeration sequence. The speed of this operation depends on the specific type of the collection, just as noted for the atOffset: message on Collection.  In the worst case, this operation is linear in the magnitude of the offset.
 */
public native Object setOffset (int offset);

/**
 *  Provided there is no major computational cost, an index also maintains the integer offset of its current member within the enumeration sequence of the collection.  These integer offset values have the same definition as in the atOffset: messages of Collection.  The getOffset message returns this current offset value.  If the index is current positioned at the Start or End location, getOffset returns -1.  If the index is positioned at a Between location, getOffset returns the offset of the immediately preceding member.  If the offset is not currently available from the index, getOffset returns the special value UnknownOffset.  This value is defined by a macro as the maximally negative value of a 32-bit, 2's-complement integer. An offset is always available from an index if its current position has been reached by repeated operations from an initial Start or End position, and there has been no other modification to the underlying collection.  Some forms of direct member access operations supported by some index types, however, may result in an integer offset not being available.  These restrictions are noted with the individual index type.
 */
public native int getOffset ();

/**
 *  The setLoc: message may be used to reset the current location of an index to either Start or End.  It may be used to reprocess a collection using an existing index after some other location has already been reached.  It may also be used to position an index at the end of all members prior to traversing members in reverse order using prev. Besides Start and End, setLoc: accepts the special argument values of BetweenAfter and BetweenBefore, which are also defined symbols.  These argument values are only valid if the index is positioned at a current member.  They reposition the index to the special location between the current member and its immediately following or preceding member.
 */
public native void setLoc (swarm.defobj.Symbol locSymbol);

/**
 *  The getLoc message returns a symbol constant which indicates the type of location at which an index is currently positioned.  This index location symbol has one of the following values: Start, End,  and Member. The Start symbol indicates the special position preceding all members in the enumeration sequence for the collection.  This is the location at which an index is positioned when it is first created.  The End symbol indicates the special position following all members in the collection.  This is the location at which an index is positioned just after a next message has returned nil, as a result of moving beyond the last member.   The Member symbol indicates that the index is positioned at some current member in the enumeration sequence of a collection. The getLoc message is needed to traverse a collection which could contain nil values for its members.  Without getLoc, there would be no way to distinguish a nil value returned by next as either a valid member value or the special value returned at the end of members. With getLoc, a loop that traverses a collection can test specifically for the end (or start) of members.
 */
public native swarm.defobj.Symbol getLoc ();

/**
 *  The remove message removes the member at the current location of an index, and returns the member value removed.  The index position is set to a special position between the members which previously preceded and followed the removed member.  If there is no preceding or following member, the index is set to the special location before the start or after the end of all members.  After a current member is removed, there is no member at the current index location, but a subsequent next or prev message will continue with the same member that would have been accessed had the current member not been removed. An InvalidIndexLoc error is raised if the index is not positioned at a current member.
 */
public native Object remove ();

/**
 *  The put: message replaces the member value at the current index position with its argument.  An InvalidIndexLoc error is raised if the index is not positioned at a current member.
 */
public native Object put (Object anObject);

/**
 *  get returns the member value at which the index is currently positioned, or nil if the index is not positioned at a member. The get message provides an alternate way to obtain the current member value in a loop that traverses a collection; its return value is the same as next or prev would return when first positioning to a new member.
 */
public native Object get ();

/**
 *  findPrev: repeatedly performs prev until the member value of the index matches the argument.  nil is returned if the index reaches the end of valid members without matching the argument. 
 */
public native Object findPrev (Object anObject);

/**
 *  findNext: repeatedly performs next until the member value of the index matches the argument.  nil is returned if the index reaches the end of valid members without matching the argument.  
 */
public native Object findNext (Object anObject);

/**
 *  The prev message works similarly, but positions to a valid member preceding the current position, or to a special position preceding all valid members. 
 */
public native Object prev ();

/**
 *  The next message positions the index to the next valid member after its current position, or to a special position after the end of all valid members.  In addition to repositioning the index, both messages return the new member value to which they are positioned, or nil if there is no such member.
 */
public native Object next ();

/**
 *  getCollection returns the collection referred to by an index.  This collection never changes during the lifetime of the index.
 */
public native Object getCollection ();

/**
 *  Immediate effects of the drop message depends on the subtype of Zone used to provide storage for the object.  For some zone types, the drop message immediately deallocates storage for the object and makes the freed storage available for other use.  Subsequent use could include the allocation of a new object at precisely the same location, resulting in a new object id identical to a previously dropped one. The Drop type may be inherited by any type that provides drop support for its instances.  In addition to freeing the storage and invalidating the object, a drop message may release other resources acquired or held within the object.  Not every object which can be created can also be dropped, and some objects can be dropped which are not directly creatable.  Some objects may be created as a side effect of other operations and still be droppable, and some objects may be created with links to other objects and not droppable on their own.  A type independently inherits Create or Drop types, or both, to indicate its support of these standard interfaces to define the endpoints of an object lifecycle.
 */
public native void drop ();

/**
 *  The getZone message returns the zone in which the object was created.
 */
public native swarm.defobj.Zone getZone ();

/**
 *  print id for each member of a collection on debug output stream
 */
public native void xfprintid ();

/**
 *  print description for each member of a collection on debug output stream
 */
public native void xfprint ();

/**
 *  Like describeID:, but output goes to standard output.
 */
public native void xprintid ();

/**
 *  Like describe:, but output goes to standard output.
 */
public native void xprint ();

/**
 *  Prints a one-line describe string, consisting of the built-in default to outputCharStream.
 */
public native void describeID (Object outputCharStream);

/**
 *  The describe: message prints a brief description of the object for debug purposes to the object passed as its argument.  The object passed as the outputCharStream argument must accept a catC: message as defined in String and OutputStream in the collections library. Particular object types may generate object description strings with additional information beyond the built-in default, which is just to print the hex value of the object id pointer along with the name of its class, and the display name of the object, if any.
 */
public native void describe (Object outputCharStream);

/**
 *  Return a string that identifies an object for external display purposes, either from a previously assigned string or an identification string default     
 */
public native java.lang.String getDisplayName ();

/**
 *  Assigns a character string as a name that identifies an object for display or debug purposes.
 */
public native void setDisplayName (java.lang.String displayName);

/**
 *  A local implementation of an Object method.
 */
public native Object perform (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with (swarm.Selector aSel, Object anObject1);

/**
 *  A local implementation of an Object method.
 */
public native Object perform$with$with (swarm.Selector aSel, Object anObject1, Object anObj2);

/**
 *  Perform a selector with three object arguments.
 */
public native Object perform$with$with$with (swarm.Selector aSel, Object anObject1, Object anObj2, Object anObj3);

/**
 *  getTypeName returns the name of the originating type of this object.
 */
public native java.lang.String getTypeName ();

/**
 *  The respondsTo: message returns true if the object implements the message identified by the selector argument.  To implement a message means only that some method will receive control if the message is sent to the object.  (The method could still raise an error.)  The respondsTo: message is implemented by direct lookup in a method dispatch table, so is just as fast as a normal message send.  It provides a quick way to test whether the type of an object includes a particular message.
 */
public native boolean respondsTo (swarm.Selector aSel);

/**
 *  A local implementation of an Object method.
 */
public native int compare (Object anObject);

/**
 *  The getName message returns a null-terminated character string that identifies an object in some context of use.  This message is commonly used for objects that are created once in some fixed context where they are also assigned a unique name.  Constant objects defined as part of a program or library are examples.  This message is intended only for returning a name associated with an object throughout its lifetime.  It does not return any data that ever changes.
 */
public native java.lang.String getName ();
public ListIndexImpl () {
  super ();
}
}
