package swarm.activity;

/**
 * <strong> Messages for actions involving a selector.</strong>.

 Messages for actions involving a selector.
 */
public interface ActionSelector  {

/**
 * 
 */
swarm.Selector getMessageSelector ();
}
