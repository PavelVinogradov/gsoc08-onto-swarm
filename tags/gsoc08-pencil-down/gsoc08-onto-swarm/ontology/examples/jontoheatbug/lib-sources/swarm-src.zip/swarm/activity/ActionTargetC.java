package swarm.activity;

/**
 * <strong> Messages common to actions that are sent to an object.</strong>.

 Messages common to actions that are sent to an object.
 */
public interface ActionTargetC  {

/**
 * 
 */
void setTarget (Object target);
}
