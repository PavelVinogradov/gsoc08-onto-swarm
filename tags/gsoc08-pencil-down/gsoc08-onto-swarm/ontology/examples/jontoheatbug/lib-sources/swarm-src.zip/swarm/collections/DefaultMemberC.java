package swarm.collections;

/**
 * <strong> Methods for setting and getting the default member in a collection.</strong>.

 When this option is set, the initial value of all new members will be set to the member value given (otherwise the default is nil).  This option gives a convenient way to distinguish members which have never been set from any other valid member value, which could include nil. This option may be reset after array creation only if some setting for the option was given at create time.  (The initial, explicitly set value can still be the default nil, but a value must be set explicitly for the option to be resettable later).  The get message for this option always retrieves the current setting, but this value has no effect except when the count of an array is increased, so that new members need to be initialized.
 */
public interface DefaultMemberC  {
}
