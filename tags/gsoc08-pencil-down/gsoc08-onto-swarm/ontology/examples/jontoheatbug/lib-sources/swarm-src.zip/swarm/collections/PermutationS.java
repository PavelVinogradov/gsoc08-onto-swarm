package swarm.collections;

/**
 * <strong> A class that represents a permutation of elements of a collection</strong>.

 Permutation is used to generate a permutation of elements of a a collection and store them in an array for fast access.  Permutation only mirrors the original collection. Updates of contents of Permutation will not reflect on the original collection.
 */
public interface PermutationS extends CollectionS, swarm.defobj.CreateS, ArrayS {
}
