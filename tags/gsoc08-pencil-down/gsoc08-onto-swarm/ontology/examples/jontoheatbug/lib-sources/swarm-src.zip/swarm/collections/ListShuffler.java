package swarm.collections;

/**
 * <strong> A class to randomize the order of a given Swarm List</strong>.

 ListShuffler randomizes the order of the elements in a List;  either the whole list or the num lowest elements. The list must be supplied. An uniform distribution can be supplied, or the system- supplied uniformUnsRand is used. The algorithm is from Knuth. All these methods modify the underlying collection, so any indexes should always be regenerated. 
 */
public interface ListShuffler extends swarm.defobj.Create, swarm.defobj.CreateS, swarm.defobj.Drop, swarm.defobj.DropS {

/**
 *  the shuffleWholeList method randomizes the whole list.
 */
Object shuffleWholeList (Object list);

/**
 *  the shufflePartialList:Num method randomizes the order of the 'num' lowest elements of the list, or the whole list if (num > size of list).
 */
Object shufflePartialList$Num (Object list, int num);
}
